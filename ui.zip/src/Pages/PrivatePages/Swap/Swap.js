import React from "react";
import { Row, Col, Form, Card } from "react-bootstrap";
import MainCard from "../../../components/common/MainCard/MainCard";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import CurrencyInput from "../../../components/common/CurrencyInput/CurrencyInput";
import DobCustom from "../../../components/common/DobCustom/DobCustom";
import ChartImage from "../../../theme/images/chart_img.png";
import SwapTransaction from "./SwapTransaction";
import CountryPicker from "../../../components/common/CountryPicker/CountryPicker";
import "./Swap.scss";
import CustomSearch from "../../../components/common/CustomSearch/CustomSearch";
import SelectPair from "../../../components/common/SelectPair/SelectPair";

function Swap() {
  return (
    <>
      <Row className="swapRow_Style mx-0">
        <Col xs={12} md={12} lg={12} xl={7} className="swapChart_Col p-0">
          <MainCard>
            <img src={ChartImage} />
          </MainCard>
        </Col>
        <Col xs={12} md={12} lg={12} xl={5} className="swapCrypto_Col p-0">
          <MainCard title="Swap Crypto" className="mr-0">
            <Row className="swapCurrency_Row">
              <Col xs={12}>
                <Form.Label className="d-flex justify-content-between">
                  I have Polkadot
                  <span className="balanceTxt">
                    Balance: <span>0.00 DOT</span>
                  </span>
                </Form.Label>
                <CurrencyInput
                  className="internalInput mb-0"
                  placeholder="Amount"
                />
              </Col>
              <Col xs={12} lg={12} className="amount_range">
                <button>25%</button>
                <button className="active">50%</button>
                <button>75%</button>
                <button>100%</button>
              </Col>
              <Col xs={12}>
                <Form.Label>I want Bitcoin</Form.Label>
                <CurrencyInput
                  className="internalInput mb-2"
                  placeholder="Amount"
                />
                <p className="text-center convertedCurrency">
                  1 Dot = 0.00053599 BTC
                </p>
              </Col>
              <Col xs={12}>
                <ButtonPrimary
                  buttontext="SWAP"
                  className="internalComn_btn mb-0"
                />
              </Col>
            </Row>
          </MainCard>
        </Col>
        <Col xs={12} md={12} lg={12} xl={12} className="p-0">
          <MainCard className="mb-0">
            <div className="swapTable_headrow">
              <p>Swapping History</p>
              <div className="filterInput_div">
                <div className="d-flex align-items-center justify-content-between dateSelect_div">
                  <DobCustom
                    placeholderText="21-09-2020"
                    className="selectDate"
                  />
                  <span>to</span>
                  <DobCustom
                    placeholderText="21-09-2021"
                    className="selectDate"
                  />
                </div>
                <SelectPair placeholder="Pair" />
                <CustomSearch placeholder="Search" />
                <ButtonPrimary buttontext="Reset" className="internalComn_btn"/>
              </div>
            </div>
            <div className="tableOuter_Div deposit_Table">
              <SwapTransaction />
            </div>
          </MainCard>
        </Col>
      </Row>
    </>
  );
}

export default Swap;

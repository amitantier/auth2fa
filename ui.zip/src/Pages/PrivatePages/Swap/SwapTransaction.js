import React from "react";
import { Table } from "react-bootstrap";
import PerfectScrollbar from "react-perfect-scrollbar";
import "react-perfect-scrollbar/dist/css/styles.css";
import "../../../components/common/CustomTable/CustomTable.scss";

function SwapTransaction(props) {
  return (
    <PerfectScrollbar
      onScrollY={(container) =>
        console.log(`scrolled to: ${container.scrollTop}.`)
      }
    >
      <Table className={`customTable ${props.className}`}>
        <thead>
          <tr>
            <th>Date</th>
            <th>Type</th>
            <th>Pair</th>
            <th>Sell</th>
            <th>Amount</th>
            <th>Buy</th>
            <th>Amount</th>
            <th>Price</th>
            <th>Fee</th>
            <th>Status</th>
          </tr>
        </thead>
        {/* <tbody>
          <tr>
            <td>Bitcoin</td>
            <td>$38,135.00</td>
            <td>0.221746 BTC</td>
            <td>$38,135.00</td>
            <td>Uniswap</td>
            <td>$38,135.00</td>
            <td>0.221746 BTC</td>
            <td>$38,135.00</td>
            <td>0.221746 BTC</td>
            <td>$38,135.00</td>
          </tr>
        </tbody> */}
        {/* NO RECORD FOUND */}
        <tbody>
          <tr>
            <td colSpan="10" className="text-center noTransaction_found">
              No Transactions Found
            </td>
          </tr>
        </tbody>
      </Table>
    </PerfectScrollbar>
  );
}

export default SwapTransaction;

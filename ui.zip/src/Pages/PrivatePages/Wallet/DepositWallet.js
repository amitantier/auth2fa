import React from "react";
import { Row, Col, Tabs, Tab, Form, Table, Card } from "react-bootstrap";
import Select from "react-select";
import MainCard from "../../../components/common/MainCard/MainCard";
import CustomInput from "../../../components/common/CustomInput/CustomInput";
import CopyIcon from "../../../theme/images/copy_icon.svg";
import QrCode from "../../../theme/images/qr_code.svg";
import QrCodeBlack from "../../../theme/images/qr_image_light.svg";
import BitcoinIcon from "../../../theme/images/bitcoin.svg";
import UniswapIcon from "../../../theme/images/uniswap.svg";
import DotIcon from "../../../theme/images/dot.svg";
import TronIcon from "../../../theme/images/tron.svg";
import BnbIcon from "../../../theme/images/bnb.svg";
import InputQrIcon from "../../../theme/images/input_qr.svg";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import "./Wallet.scss";
import ChartImage from "../../../theme/images/chart_img.png";
import CustomTable from "../../../components/common/CustomTable/CustomTable";
import TransactionTable from "../../../components/common/CustomTable/TransactionTable";

const options = [
  {
    value: "BTC",
    label: (
      <div>
        <img src={BitcoinIcon} className="optionIcon" />
        BTC
      </div>
    ),
  },
  {
    value: "TRON",
    label: (
      <div>
        <img src={TronIcon} className="optionIcon" />
        TRON
      </div>
    ),
  },
  {
    value: "DOT",
    label: (
      <div>
        <img src={DotIcon} className="optionIcon" />
        DOT
      </div>
    ),
  },
  {
    value: "UNISWAP",
    label: (
      <div>
        <img src={UniswapIcon} className="optionIcon" />
        UNI
      </div>
    ),
  },
  {
    value: "BNB",
    label: (
      <div>
        <img src={BnbIcon} className="optionIcon" />
        BNB
      </div>
    ),
  },
];

const networkoptions = [
  {
    value: "btc",
    label: "Bitcoin",
  },
  {
    value: "trx",
    label: "Tron",
  },
  {
    value: "eth",
    label: "Ethereum",
  },
  {
    value: "uni",
    label: "Uniswap",
  },
];
function DepositWallet() {
  return (
    <>
      <Row className="walletRow_Style m-0">
        <Col xs={12} md={12} lg={12} xl={5} className="tabSide_Col p-0">
          <MainCard>
            <Tabs
              defaultActiveKey="Deposit"
              id="uncontrolled-tab-example"
              className="customTab_style"
            >
              <Tab eventKey="Deposit" title="Deposit">
                <Row>
                  <Col xs={12} md={6} className="tokenSelect_col">
                    <Form.Label>Select Token</Form.Label>
                    <Select
                      options={options}
                      defaultValue={options[0]}
                      classNamePrefix="react-select"
                      placeholder="btc"
                      label="deposit"
                    />
                    <Form.Label>Deposit Network</Form.Label>
                    <Select
                      options={networkoptions}
                      defaultValue={networkoptions[0]}
                      classNamePrefix="react-select"
                      placeholder="btc"
                      label="deposit"
                    />
                  </Col>
                  <Col xs={12} md={6} className="qrCode_col">
                    <Form.Label className="text-center d-block">
                      BTC Address
                    </Form.Label>
                    <img src={QrCode} className="qrImg_style qrLight" />
                    <img src={QrCodeBlack} className="qrImg_style qrBlack" />
                    <CustomInput
                      className="internalInput depositAddress_field"
                      placeholder="btrpfazltor3h52wjrrnfvsmkrnge525shju"
                    >
                      <a className="showPassword">
                        <img src={CopyIcon} />
                      </a>
                    </CustomInput>
                  </Col>
                  <ul className="detailMessage">
                    <li>
                      Please send only BTC tokens to this address. Sending other
                      tokens will result in their permanent loss.
                    </li>
                    <li>Minimum Deposit: 1$ worth of BTC</li>
                    <li>
                      Minimum Network Confirmations: 2 (Usually takes ~30 mins)
                    </li>
                  </ul>
                </Row>
              </Tab>
              <Tab eventKey="Withdraw" title="Withdraw">
                <div className="withdrawAmount_Col">
                  <Row>
                    <Col xs={12} sm={12} md={6} lg={6} xl={6}>
                      <Form.Label>Select Token</Form.Label>
                      <Select
                        options={options}
                        defaultValue={options[0]}
                        classNamePrefix="react-select"
                        placeholder="btc"
                        label="deposit"
                      />
                    </Col>
                    <Col xs={12} sm={12} md={6} lg={6} xl={6}>
                      <Form.Label className="d-flex justify-content-between align-items-end">
                        Amount
                        <span className="balanceTxt">
                          Balance: <span>0.00 BTC</span>
                        </span>
                      </Form.Label>
                      <CustomInput
                        className="internalInput"
                        placeholder="Enter Amount"
                      ></CustomInput>
                      <div className="amount_range">
                        <button>25%</button>
                        <button>50%</button>
                        <button>75%</button>
                        <button>100%</button>
                      </div>
                    </Col>
                    <Col xs={12} lg={12}>
                      <Form.Label>Withdraw Address</Form.Label>
                      <CustomInput
                        className="internalInput"
                        placeholder="btrpfazltor3h52wjrrnfvsmkrnge525shju"
                      >
                        <a className="showPassword currencySelected_style qrIcon_small">
                          <img src={InputQrIcon} />
                        </a>
                      </CustomInput>
                    </Col>

                    <Col xs={12} lg={12}>
                      <ButtonPrimary
                        buttontext="Withdraw"
                        className="internalComn_btn withdrawBtn_Style"
                      />
                    </Col>
                  </Row>
                </div>
              </Tab>
            </Tabs>
          </MainCard>
        </Col>
        <Col
          xs={12}
          md={12}
          lg={12}
          xl={7}
          className="chartCol depositChart_Col p-0"
        >
          <MainCard>
            <img src={ChartImage} />
          </MainCard>
        </Col>
        <Col xs={12} className="tableCol_Style p-0">
          <MainCard>
            <Card.Title className="table_maintitle d-flex">
              <p>Transactions</p>
            </Card.Title>
            <Tabs
              defaultActiveKey="home"
              transition={true}
              className="tableTab_style"
            >
              <Tab eventKey="home" title="All">
                <div className="tableOuter_Div deposit_Table">
                  <CustomTable />
                </div>
              </Tab>
              <Tab eventKey="profile" title="Deposit">
                <TransactionTable />
              </Tab>
              <Tab eventKey="contact" title="Withdraw">
                <TransactionTable />
              </Tab>
            </Tabs>
          </MainCard>
        </Col>
      </Row>
    </>
  );
}

export default DepositWallet;

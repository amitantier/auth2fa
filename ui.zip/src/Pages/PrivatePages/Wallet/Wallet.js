import React, { useState } from "react";
import { Row, Col, Card, Form, FormControl } from "react-bootstrap";
import CoinCard from "../../../components/common/CoinCard/CoinCard";
import MainCard from "../../../components/common/MainCard/MainCard";
import BitcoinIcon from "../../../theme/images/bitcoin.svg";
import UniswapIcon from "../../../theme/images/uniswap.svg";
import DotIcon from "../../../theme/images/dot.svg";
import TronIcon from "../../../theme/images/tron.svg";
import BnbIcon from "../../../theme/images/bnb.svg";
import GraphIcon from "../../../theme/images/graph.svg";
import MenuIcon from "../../../theme/images/menu_icon.svg";
import MenuGrid from "../../../theme/images/grid_menu.svg";
import CustomTable from "../../../components/common/CustomTable/CustomTable";
import ChartImage from "../../../theme/images/chart_img.png";
import ChartImageLite from "../../../theme/images/chart_img_lite.png";
import CircularGraph from "../../../theme/images/circular_graph.png";
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import "./Wallet.scss";
import CustomSearch from "../../../components/common/CustomSearch/CustomSearch";

const responsive = {
  desktop: {
    breakpoint: { max: 3000, min: 1280 },
    items: 4,
  },
  tablet: {
    breakpoint: { max: 1280, min: 464 },
    items: 3,
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 1,
  },
};

function Wallet() {
  const [isActive, setActive] = useState("false");
  const handleToggle = () => {
    setActive(!isActive);
  };
  return (
    <>
      <Row className="walletRow_Style m-0">
        <Col xs={12} md={12} lg={12} xl={7} className="chartCol p-0">
          <MainCard>
            <img src={ChartImage} />
          </MainCard>
        </Col>
        <Col xs={12} md={12} lg={12} xl={5} className="fundAlloction_Col p-0">
          <MainCard title="Funds Allocation">
            <Row className="fundsAllocation_Row m-0">
              <Col xs={12} sm={8} md={8} className="fundsAllocation_graph p-0">
                <img src={CircularGraph} />
              </Col>
              <Col xs={12} sm={4} md={4} className="fundsAllocation_List">
                <ul>
                  <li>
                    <h2>35%</h2>
                    <p>Bitcoin BTC</p>
                  </li>
                  <li>
                    <h2>20%</h2>
                    <p>Polka Dot</p>
                  </li>
                  <li>
                    <h2>20%</h2>
                    <p>Tron</p>
                  </li>
                  <li>
                    <h2>12%</h2>
                    <p>Uniswap</p>
                  </li>
                  <li>
                    <h2>13%</h2>
                    <p>BNB</p>
                  </li>
                </ul>
              </Col>
            </Row>
          </MainCard>
        </Col>
      </Row>
      <Row className="m-0">
        <Col xs={12} className="p-0">
          <MainCard className="walletCoin_wrap">
            <Card.Title
              className={`maintitle ${isActive ? "" : "maintitle_bg"}`}
            >
              Active Assets
              <Form className="d-flex align-items-center">
                <CustomSearch className={isActive ? "" : "searchInput_bg"}  placeholder="Search Token"/>
                <a className="menuIcon" onClick={handleToggle}>
                  <img src={MenuIcon} className={isActive ? "show" : "hide"} />
                  <img src={MenuGrid} className={isActive ? "hide" : "show"} />
                </a>
              </Form>
            </Card.Title>
            <Row className={`walletCoin_row ${isActive ? "show" : "hide"}`}>
              <Carousel
                responsive={responsive}
                swipeable={true}
                draggable={true}
                showDots={false}
                arrows={false}
                infinite={true}
                autoPlay={true}
                customTransition="all 10s linear"
              >
                <CoinCard
                  icon={BitcoinIcon}
                  name="Bitcoin"
                  price="0.221746"
                  symbol="BTC"
                  graph={GraphIcon}
                  date="12:40, 12 July 2020"
                  lastchange="+1.045 BTC"
                  text="1PRj85hu9RXPZTzxtko9stfs6nRo1vyrQB"
                />
                <CoinCard
                  icon={UniswapIcon}
                  name="Uniswap"
                  price="0.221746"
                  symbol="UNI"
                  graph={GraphIcon}
                  date="12:40, 12 July 2020"
                  lastchange="+1.045 Uni"
                  text="1PRj85hu9RXPZTzxtko9stfs6nRo1vyrQB"
                />
                <CoinCard
                  icon={DotIcon}
                  name="Dot"
                  price="0.226"
                  symbol="Dot"
                  graph={GraphIcon}
                  date="12:40, 12 July 2020"
                  lastchange="+1.045 Dot"
                  text="1PRj85hu9RXPZTzxtko9stfs6nRo1vyrQB"
                />
                <CoinCard
                  icon={TronIcon}
                  name="Tron"
                  price="0.221746"
                  symbol="TRX"
                  graph={GraphIcon}
                  date="12:40, 12 July 2020"
                  lastchange="+1.045 Link"
                  text="1PRj85hu9RXPZTzxtko9stfs6nRo1vyrQB"
                />
                <CoinCard
                  icon={BnbIcon}
                  name="BNB"
                  price="0.221746"
                  symbol="BNB"
                  graph={GraphIcon}
                  date="12:40, 12 July 2020"
                  lastchange="+1.045 Link"
                  text="1PRj85hu9RXPZTzxtko9stfs6nRo1vyrQB"
                />
              </Carousel>
            </Row>
            <div className={`tableOuter_Div ${isActive ? "hide" : "show"}`}>
              <CustomTable />
            </div>
          </MainCard>
        </Col>
      </Row>
    </>
  );
}

export default Wallet;

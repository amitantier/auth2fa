import React from "react";
import { Row, Col, Card } from "react-bootstrap";
import { useHistory } from "react-router-dom";
import SettingIcon from "../../../theme/images/device_setting.svg";
import LockIcon from "../../../theme/images/lock_icon.svg";
import KycIcon from "../../../theme/images/kyc_icon.svg";
import MainCard from "../../../components/common/MainCard/MainCard";
import SecurityIcon from "../../../theme/images/security_icon.svg";
import SecurityIconLite from "../../../theme/images/security_icon_lite.svg";
import SettingCard from "../../../components/common/SettingCard/SettingCard";
import "./Setting.scss";

function Setting() {
  let history = useHistory();
  return (
    <>
      <div className="settingCommon_Style">
        <MainCard>
          <Card.Title className="cardTitle_Padding">Settings</Card.Title>
          <div className="settingWrap_style">
            <Row className="m-0 settingRow_comn">
              <SettingCard
                icon={KycIcon}
                title="KYC Detail"
                text="We recommend changing your password freqently for enhanced
                    security of your account"
                alt="kyc icon"
                onClick={() => {
                  history.push("/auth/kycnotsubmit");
                }}
              />
              <SettingCard
                className="mr-0"
                icon={LockIcon}
                title="Password Reset"
                text="We recommend changing your password freqently for enhanced
                  security of your account"
                alt="lock icon"
                onClick={() => {
                  history.push("/auth/password-reset");
                }}
              />
            </Row>
            <Row className="m-0 settingRow_comn">
              <SettingCard
                icon={LockIcon}
                title="2-Factor Authentication"
                text="We strongly recommend you enable your 2-Factor
                  Authentication (2FA) to protect your account from potential
                  attackers."
                alt="lock icon"
                iconsecond={SecurityIcon}
                iconsecondLite={SecurityIconLite}
                onClick={() => {
                  history.push("/auth/authentication");
                }}
              />

              <SettingCard
                className="mr-0"
                icon={SettingIcon}
                title="Device Management"
                alt="lock icon"
                onClick={() => {
                  history.push("/auth/device-management");
                }}
              >
                <p>
                  Improve security by logging in only using your trusted
                  devices. Currently active on <a href="#"> 1 Trusted</a> and
                  <a href="#"> 0 untrusted devices</a>
                </p>
              </SettingCard>
            </Row>
          </div>
        </MainCard>
      </div>
    </>
  );
}

export default Setting;

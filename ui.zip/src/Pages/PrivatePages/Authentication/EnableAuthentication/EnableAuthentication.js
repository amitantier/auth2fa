import React,{useEffect} from "react";
import { useHistory } from "react-router-dom";
import { Row, Col, Card } from "react-bootstrap";
import ButtonPrimary from "../../../../components/common/ButtonPrimary/ButtonPrimary";
import MainCard from "../../../../components/common/MainCard/MainCard";
import ButtonOutline from "../../../../components/common/ButtonOutline/ButtonOutline";
import QrCode from "../../../../theme/images/qr_code.svg";
import QrCodeBlack from "../../../../theme/images/qr_image_light.svg";
import AppleIcon from "../../../../theme/images/apple_icon.svg";
import PlaystoreIcon from "../../../../theme/images/playstore_icon.svg";
import "../Authentication.scss";
import { connect } from "react-redux";
import {get2FaImage} from "../../../../redux/actions/SecurityActions"



function EnableAuthentication(props) {
  let history = useHistory();
  const handleClick = () => {
    history.push("/auth/authentication-code");
  };

  useEffect(()=>{
    props.get2FaImage({ "issuer":""}).then((res)=>{
      
    })
 },[])

  return (
    <>
      {/* <Col xs={12} lg={12} xl={7} className="mx-auto"> */}
        <MainCard className="mainCard_padding googleAuth_Main authCard_style">
          <Card.Title className="cardTitle_Padding">
            2-Factor Authentication
          </Card.Title>
          <Row className="googleAuth_Row">
            <h3>
              Using the Google Authenticator app, Scan the <br />
              QR code below
            </h3>
            <Col className="qr_col" md={6} xs={12}>
            <img src={props.qrImgUrl} />

              {/* <img src={QrCode} className="qrLight" />
              <img src={QrCodeBlack} className="qrBlack" /> */}
            </Col>
            <Col className="appstore_col" md={6} xs={12}>
              <p>Don’t have an Authenticator app? </p>
              <ButtonOutline
                icon={AppleIcon}
                store="App Store"
                className="mb-2 mt-5 internalOutline_btn"
              />
              <ButtonOutline
                icon={PlaystoreIcon}
                store="Google Play"
                className="internalOutline_btn"
              />
            </Col>
            <Col>
              <ButtonPrimary
                onClick={handleClick}
                buttontext="Continue"
                className="internalComn_btn continue_btn mb-0"
              />
            </Col>
          </Row>
        </MainCard>
      {/* </Col> */}
    </>
  );
}


const mapStateToProps = state => {
  console.log("***********",state)
  return {
      isUserFirstTimeLogin:state.persist.isUserFirstTimeLogin,
      secret: state.security.secret,
      qrImgUrl:state.security.qrImgUrl

  };
};

const mapDispatchToProps = dispatch => {
  return {
    get2FaImage:(data)=>dispatch(get2FaImage(data))

  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(EnableAuthentication);
import React from "react";
import { useHistory } from "react-router-dom";
import { Row, Col, Card } from "react-bootstrap";
import ReactCodeInput from "react-code-input";
import ButtonPrimary from "../../../../components/common/ButtonPrimary/ButtonPrimary";
import MainCard from "../../../../components/common/MainCard/MainCard";
import CustomInput from "../../../../components/common/CustomInput/CustomInput";
import CopyIcon from "../../../../theme/images/copy_icon.svg";
import "../../../PublicPages/AuthenticationCode/AuthenticationCode.scss";
import "../Authentication.scss";
function AuthCode() {
  let history = useHistory();
  const handleClick = () => {
    history.push("/auth/disable-authentication");
  };
  return (
    <>
      {/* <Col xs={12} lg={7} className="mx-auto commonCol_width"> */}
        <MainCard className="mainCard_padding googleAuth_Main authCard_style">
          <Card.Title className="cardTitle_Padding">
            2-Factor Authentication
          </Card.Title>
          <Row className="googleAuth_Row authCont_Style">
            <h3>
              Keep a physical or digital copy of your backup <br />
              code to stay secure.
            </h3>
            <Col xs={12} md={12} lg={12}>
              <CustomInput
                placeholder="btrpfazltor3h52wjrrnfvsmkrnge525shju"
                className="internalInput"
              >
                <a className="showPassword">
                  <img src={CopyIcon} />
                </a>
              </CustomInput>
            </Col>
            <Col xs={12} md={12} lg={12}>
              <p className="info_msg">
                We do not recommend sharing or publishing the backup code
                anywhere or with anyone.
              </p>
              <h3>6 digit code displayed by your app</h3>
            </Col>
            <Col xs={12} md={12} lg={12} className="d-flex justify-content-center">
              <ReactCodeInput type="number" fields={6} />
            </Col>
            <Col xs={12} md={12} lg={12}>
              <ButtonPrimary buttontext="Continue" className="internalComn_btn" onClick={handleClick} />
            </Col>
          </Row>
        </MainCard>
      {/* </Col> */}
    </>
  );
}

export default AuthCode;

import React from "react";
import { useHistory } from "react-router-dom";
import { Row, Col, Card } from "react-bootstrap";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import MainCard from "../../../components/common/MainCard/MainCard";
import WarningIcon from "../../../theme/images/warning_icon.svg";
import "./Authentication.scss";

function Authentication() {
  let history = useHistory();
  const handleClick = () => {
    history.push("/auth/enable-authentication");
  };
  return (
    <>
      {/* <Col xs={12} lg={6} xl={6} className="mx-auto"> */}
        <MainCard className="mainCard_padding authCard_style enableAuth_style">
          <Card.Title className="cardTitle_Padding">
            2-Factor Authentication
          </Card.Title>
          <Col className="text-center authenticationCol_style">
            <div className="warningIcon">
              <img src={WarningIcon} />
            </div>
            <p className="warningTxt_style">
              We strongly recommend turning on MFA as an added layer of security
              Enabling MFA helps keep your account safe from hackers.
            </p>
            <ButtonPrimary
              buttontext="Turn ON 2FA"
              className="internalComn_btn mb-0 authenticationBtn"
              onClick={handleClick}
            />
            {/* for disbale 2fa */}
            {/* <p className="warningTxt_style">
              Enabling 2FA helps keep your account safe.
              <br />
              We strongly recommend you keep 2FA turned on.
            </p>
            <ButtonPrimary
              buttontext="Turn OFF 2FA"
              className="internalComn_btn mb-0 authenticationBtn"
              onClick={handleClick}
            /> */}
          </Col>
        </MainCard>
      {/* </Col> */}
    </>
  );
}

export default Authentication;

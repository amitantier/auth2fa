import React from "react";
import { useHistory } from "react-router-dom";
import { Row, Col, Card } from "react-bootstrap";
import ReactCodeInput from "react-code-input";
import ButtonPrimary from "../../../../components/common/ButtonPrimary/ButtonPrimary";
import MainCard from "../../../../components/common/MainCard/MainCard";
import "../../../PublicPages/AuthenticationCode/AuthenticationCode.scss";
import "../Authentication.scss";

function DisableAuthentication() {
  return (
    <>
      <Col xs={12} lg={7} className="mx-auto commonCol_width">
        <MainCard className="mainCard_padding googleAuth_Main">
          <Card.Title className="cardTitle_Padding">
            2-Factor Authentication
          </Card.Title>
          <Row className="googleAuth_Row authCont_Style">
            <h3>Enter 2FA code from your Authenticator app.</h3>
            <Col xs={12} md={12} lg={12} className="d-flex align-items-center flex-column">
              <ReactCodeInput type="number" fields={6} />
              <h3 className="authnticationApp_txt">
                Issues with Authenticator app?
              </h3>
              <p className="sendOtp_Msg">Send OTP to email ID</p>
            </Col>
            <Col xs={12} md={12} lg={12}>
              <ButtonPrimary
                buttontext="Submit"
                className="internalComn_btn submit_Btn"
              />
            </Col>
          </Row>
        </MainCard>
      </Col>
    </>
  );
}

export default DisableAuthentication;

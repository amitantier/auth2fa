import React, { useState,useEffect } from "react";
import { Row, Col, Card } from "react-bootstrap";
import { useHistory } from "react-router-dom";
import CustomInput from "../../../components/common/CustomInput/CustomInput";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import MainCard from "../../../components/common/MainCard/MainCard";
import CountryPicker from "../../../components/common/CountryPicker/CountryPicker";
import PhoneInput from "../../../components/common/PhoneInput/PhoneInput";
import DobCustom from "../../../components/common/DobCustom/DobCustom";
import { getFormatedCountries } from "../../../Helpers/Normailize";
import { getData } from "country-list";
import {
  getCountries,
  getCountryCallingCode,
} from "react-phone-number-input/input";
import axios from "axios";
import {
  getUserKycDetails,
  clearKycFormData,
  saveKycFormData,
  uploadRawFile,
  updateUserKyc,
} from "../../../redux/actions/SecurityActions";
import {connect} from "react-redux";

import DatePicker from "react-datepicker";

import "./Kyc.scss";
import {PASSPORT_BACK,PASSPORT_FRONT,LICENSE_BACK,LICENSE_FRONT,NATIONAL_ID,KYC_APPROVED,KYC_DECLINED,KYC_RE_SUBMITTED,KYC_SUBMITTED} from "../../../constant"


function KycDetail(props) {
  const [phone_code, setPhoneCode] = React.useState("");
  const [phoneNumberMin, setPhoneNumberMin] = React.useState(false);
  const [phoneNumberMax, setPhoneNumberMax] = React.useState(false);
  const [formData, setFormData] = useState([]);
  const [kycGetDetails, setKycGetDetails] = useState({});
  const [isKycRes, setIsKycRes] = useState(false);


  const [startDate, setStartDate] = useState(
    props?.kycGetDetails?.dob ? new Date(props?.kycGetDetails?.dob) : ""
  );
  let history = useHistory();


  const options = () => {
    const optionsList = [];
    getCountries().forEach((country, index) => {
      const value = `${getCountryCallingCode(country)}`;
      optionsList.push({
        // key: `${index}_${value}`,
        value: `+${value}`,
        label: `+${value}`,
      });
    });
    return optionsList;
  };

  const getCountryCode = () => {
    axios.get('https://ipapi.co/json/').then(response => {
      let data = response.data;
      let c_code = data.country_calling_code;
      console.log('phone_code', c_code)
      setPhoneCode(c_code)

    });
  };
  const CountryName = getFormatedCountries(getData());
  console.log("CountryName", CountryName);
  const handleClick = () => {
    history.push("/auth/kycnotsubmit");
  };
  const saveDetail = () => {
    history.push({
      pathname:"/auth/kyc-upload",
      state: formData
    });
  };
  const handleChange = (e,type) => {
    let value;
    if(type === "dob"){
      value = e;
    }else if(type === "mobileNumber"){
      value =  Math.abs(e.target.value)
    }else if(type === "mobileCode"){
      value =  e.value
    }else{
      value = e.target.value;
    }
    let data = {}
    if (formData && formData?.data) {
      data = { ...formData?.data }
    }
      data[type] = value;
  
    setFormData({...formData,data})
  }


 useEffect(()=>{
         getCountryCode();
         getUserKycDetails();
         return () => {
        props.clearKycFormData()
         };
    },[]);

    const getUserKycDetails = ()=>{
      props.getUserKycDetails().then(async(res)=>{
          await setKycGetDetails(res.data.data);
          setFormData({ ...formData, data: res.data.data })
          if(res.data.data.status==KYC_APPROVED){
              //setVerificationApproved(true);
          }
          if(res.data.data.status==KYC_DECLINED){
              // setVerificationFailed(true);
          }
          console.log("kycGetDetails11",res.data.data);
      }).catch((error)=>{
          setIsKycRes(true);

      })
  }

  const checkMobileNo = (e) => {
    console.log('checkMobileNo',e.target.value,e.target.value.toString().includes("-")  )
    if (e.target.value.toString().length < 10) {
      setPhoneNumberMin(true)
    } else {
      setPhoneNumberMin(false)
    }
    if (e.target.value.toString().length > 10) {
      setPhoneNumberMax(true)
    } else {
      setPhoneNumberMax(false)
    }
  }
  return (
    <>
      <MainCard className="kycCard_Style mainCard_padding">
        <Card.Title className="cardTitle_Padding">KYC</Card.Title>
          {console.log('kycGetDetails',formData)}
        <Col className="kycDetail_Row">
          <Row>
            <Col xs={12} lg={4}>
              {console.log()}
              <CustomInput
                value={formData?.data?.firstname ? formData?.data?.firstname : ''}
                  handleChange={handleChange}
                name="firstname"
                label="First Name"
                className="internalInput"
                placeholder="First Name"
              ></CustomInput>
            </Col>

            <Col xs={12} lg={4}>
              <CustomInput
               value={formData?.data?.lastname ? formData?.data?.lastname : ''}
                name="lastname"
                handleChange={handleChange}
                label="Last Name"
                className="internalInput"
                placeholder="Last Name"
              ></CustomInput>
            </Col>
            <Col xs={12} lg={4}>
              <DobCustom
              value={formData?.data?.dob ? formData?.data?.dob : ''}
                label="Date Of Birth"
                className="internalInput"
                placeholderText="Date Of Birth"
                name="dob"
                handleChange={handleChange}
                startDate={formData?.data?.dob ? formData?.data?.dob : ''}
              ></DobCustom>
            </Col>
            {/* <Col xs={12} lg={4}>
              <CustomInput
                handleChange={handleChange}
                label="Email ID"
                name="email"
                placeholder="Email Id"
                className="internalInput"
              ></CustomInput>
            </Col> */}
            <Col xs={12} lg={4}>
              <CountryPicker
                value={formData?.data?.country_code ? formData?.data?.country_code : ''}
                countryName={CountryName}
                defaultValue={
                  kycGetDetails.country_id
                    ? kycGetDetails.country_id
                    : ""
                }
                handleChange={handleChange}
                label="Country*"
                placeholder="Select Country"
                className="internalInput"
                name="country_id"
              ></CountryPicker>
            </Col>
            <Col xs={12} lg={4}>
              <PhoneInput 
              name="mobileNumber"
              checkMobileNo={checkMobileNo}
              value={formData?.data?.mobileNumber ? formData?.data?.mobileNumber : ''}
              defaultValue={formData?.data?.mobileCode ? formData?.data?.mobileCode : phone_code}
              options={options()}
              handleChange={handleChange}
              className="internalInput" label="Phone Number*">
                 {phoneNumberMin && <p style={{ color: 'red' }}>Phone No. is too short</p>}
                  {phoneNumberMax && <p style={{ color: 'red' }}>Phone No. is too long</p>}
              </PhoneInput>
            </Col>
          </Row>
          <Row>
            <Col xs={12} lg={4} className="kycBtn_col">
              <ButtonPrimary
                buttontext="CANCEL"
                className="cancel_btn mb-0"
                onClick={handleClick}
              />
              <ButtonPrimary
              disabled={phoneNumberMin || phoneNumberMax}
                buttontext="PROCEED"
                className="internalComn_btn mb-0"
                onClick={saveDetail}
              />
            </Col>
          </Row>
        </Col>
      </MainCard>
    </>
  );
}

const mapStateToProps = (state) => {
  console.log("*****KYC FORM****", state);
  return {
    doc_type: state.security.doc_type,
    doc_front: state.security.doc_front,
    doc_back: state.security.doc_back,
    national_id: state.security.national_id,
    selfie: state.security.selfie,

    kyc_selfie_path: state.security.kyc_selfie_path,
    kyc_doc_path_front: state.security.kyc_doc_path_front,
    kyc_doc_path_back: state.security.kyc_doc_path_back,
    kyc_national_doc_path: state.security.kyc_national_doc_path,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    updateUserKyc: (data) => dispatch(updateUserKyc(data)),
    getUserKycDetails:()=>dispatch(getUserKycDetails()),
    clearKycFormData: () => dispatch(clearKycFormData()),
    saveKycFormData: (data) => dispatch(saveKycFormData(data)),
  };
};
export default (connect(
  mapStateToProps,
  mapDispatchToProps
)(KycDetail));
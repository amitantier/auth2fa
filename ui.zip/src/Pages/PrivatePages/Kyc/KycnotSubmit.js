import React from "react";
import MainCard from "../../../components/common/MainCard/MainCard";
import { useHistory } from "react-router-dom";
import KycDoc from "../../../theme/images/kyc_doc.svg";
import { Row, Col, Card } from "react-bootstrap";
import KycDocLite from "../../../theme/images/kyc_doc_lite.svg";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import "./Kyc.scss";

function KycnotSubmit() {
  let history = useHistory();
  const handleClick = () => {
    history.push("/auth/kycdetail");
  };
  return (
    <>
      <MainCard className="mainCard_padding">
        <Card.Title className="cardTitle_Padding">KYC</Card.Title>
        <Col md={6} sm={12} xs={12} className="mx-auto kycnot_submit">
          <img src={KycDoc} className="kycdoc_img" />
          <img src={KycDocLite} className="kycdocLite_img" />
          <h3>KYC Not submitted</h3>
          <p>
            Complete your KYC to get the restriction free access of the platform
          </p>
          <ButtonPrimary
            buttontext="Submit KYC Now"
            className="submitKyc_btn"
            onClick={handleClick}
          />
        </Col>
      </MainCard>
    </>
  );
}

export default KycnotSubmit;

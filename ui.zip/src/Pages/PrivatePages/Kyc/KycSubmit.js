import React from "react";
import { Row, Col, Card } from "react-bootstrap";
import CustomInput from "../../../components/common/CustomInput/CustomInput";
import MainCard from "../../../components/common/MainCard/MainCard";
import "./Kyc.scss";

function KycSubmit() {
  return (
    <>
      <MainCard className="kycCard_Style mainCard_padding">
        <Card.Title className="cardTitle_Padding">KYC</Card.Title>
        <Col className="kycDetail_Row">
          <Row>
            <Col xs={12} lg={4}>
              <CustomInput
                label="First Name"
                className="internalInput"
                placeholder="Mark"
                disabled
              ></CustomInput>
            </Col>

            <Col xs={12} lg={4}>
              <CustomInput
                label="Last Name"
                className="internalInput"
                placeholder="William"
                disabled
              ></CustomInput>
            </Col>
            <Col xs={12} lg={4}>
              <CustomInput
                label="Email ID"
                placeholder="emailaddress@gmail.com"
                className="internalInput"
                disabled
              ></CustomInput>
            </Col>
            <Col xs={12} lg={4}>
              <CustomInput
                label="Country"
                className="internalInput"
                placeholder="India"
                disabled
              ></CustomInput>
            </Col>
            <Col xs={12} lg={4}>
              <CustomInput
                label="Phone Number"
                className="internalInput"
                placeholder="+91 986 7456 321"
                disabled
              ></CustomInput>
            </Col>
            <Col xs={12} lg={4}>
              <CustomInput
                label="Document Type Submitted"
                className="internalInput"
                placeholder="Aadhar Card"
                disabled
              ></CustomInput>
            </Col>
            <Col xs={12} lg={4}>
              <CustomInput
                label="Document Type Submitted"
                className="internalInput"
                placeholder="Aadhar Card"
                disabled
              ></CustomInput>
            </Col>
          </Row>
        </Col>
      </MainCard>
    </>
  );
}

export default KycSubmit;

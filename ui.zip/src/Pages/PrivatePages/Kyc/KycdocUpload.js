import React, { useState } from "react";
import { Row, Col, Card } from "react-bootstrap";
import { useHistory } from "react-router-dom";
import CustomInput from "../../../components/common/CustomInput/CustomInput";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import MainCard from "../../../components/common/MainCard/MainCard";
import CountryPicker from "../../../components/common/CountryPicker/CountryPicker";
import UploadDocumentInput from "../../../components/common/UploadDocumentInput/UploadDocumentInput";
import { connect } from 'react-redux';
import {
  saveKycFormData,
  uploadRawFile,
  updateUserKyc
} from '../../../redux/actions/SecurityActions';

import { withRouter } from 'react-router';
import "./Kyc.scss";
import TakeSelfie from "../../../components/common/UploadDocumentInput/TakeSelfie";
import Selfie from "../../../theme/images/selfie.svg";
import SelfieLite from "../../../theme/images/selfie_lite.svg";
import Selfie2 from "../../../components/common/UploadDocumentInput/Selfie2";


function KycdocUpload(props) {

  const [formData, setFormData] = useState(props?.location?.state);
  const documentType = [
    { key: 1, value: '', label: 'Select Document' },
    { key: 2, value: 'Passport', label: 'Passport' },
    { key: 3, value: 'License', label: 'License' },
  ];

  const [checkSelfiImg,setCheckSelfiImg] = useState(true)

  // console.log('KycdocUpload', props?.location)

  let history = useHistory();
  const handleClick = () => {

    history.push("/auth/kycsubmited");
  };
  const backTodetail = () => {
    history.push("/auth/kycdetail");
  };


  const saveDocFile = (e, type, temp) => {
    //props.showProcessing(true);
    let file = e.target.files[0];
    // let fileSize = file.size / 1024 / 1024;
    const formData = new FormData();
    formData.append('upload_file', file);
    // props.showProcessing(true);
    props
      .uploadRawFile(formData)
      .then((res) => {
        //props.showProcessing(false);

        let fileId = res.data.data.fileId;
        let path = res.data.data.fullS3FilePath;
        console.log(res.data.data.fullS3FilePath);
        props.saveKycFormData({ prop: type, value: fileId });
        props.saveKycFormData({ prop: temp, value: path });
      })
      .catch((error) => {
        //  props.showProcessing(false);
      });
  };

  const handleChange = (e,type) => {
    let data = {}
    if (formData && formData?.data) {
      data = { ...formData?.data }
    }
    data[type] = e.target.value
    setFormData({...formData,data:data})
  }

  const onSubmitForm = (e,type) => {
    let data = {}
    if (formData && formData?.data) {
      data = { ...formData?.data }
    }
    data[type] = e.target.value
    setFormData({...formData,data:data})
  }

  return (
    <>
      <MainCard className="kycCard_Style mainCard_padding">
        {console.log('kycupload',formData)}
        <Card.Title className="cardTitle_Padding">KYC</Card.Title>
        <form onSubmit={onSubmitForm}>
        <Col className="kycDetail_Row">
          <Row>
            <Col xs={12} lg={4}>
              <CountryPicker
                label="Document Type*"
                placeholder="Passport"
                className="internalInput"
                countryName={documentType}
                handleChange={handleChange}
                name={'doc_type'}
              ></CountryPicker>
            </Col>
            <Col xs={12} lg={4}>
              <CustomInput
                handleChange={handleChange}
                label="Document Number*"
                placeholder=""
                className="internalInput"
                value={formData?.data?.documentNo}
                name={'doc_number'}

              ></CustomInput>
            </Col>
          </Row>
          <Row className="uploadDoc_wrap">
            <Col xs={12} md={6} lg={6} xl={4} className="uploadDoc_col">
              <UploadDocumentInput
                label={`${props.doc_type} Front*`}
                onChange={(e) => saveDocFile(e, 'doc_front', 'kyc_doc_path_front')}
                isDoc={props.doc_front}
                type="doc_front"
              />
            </Col>
            <Col xs={12} md={6} lg={6} xl={4} className="uploadDoc_col">
              <UploadDocumentInput
                label={`${props.doc_type} Back*`}
                onChange={(e) => saveDocFile(e, 'doc_back', 'kyc_doc_path_back')}
                isDoc={props.doc_back}
                type="doc_back"
              />
            </Col>
            <Col xs={12} md={6} lg={6} xl={4} className="uploadDoc_col">
              <Selfie2
                setCheckSelfiImg={setCheckSelfiImg}
                label="Selfie with ID"
                icon={Selfie}
                iconLight={SelfieLite}
                isDoc={props.national_id}
                type="national_id"
              />
            </Col>
            {/* <Col xs={12} md={6} lg={6} xl={4} className="uploadDoc_col">
              <TakeSelfie
                label="Selfie with ID"
                icon={Selfie}
                iconLight={SelfieLite}
              />
            </Col> */}
          </Row>
          <Row>
            <Col xs={12} md={6} lg={6} xl={4} className="kycBtn_col">
              <ButtonPrimary
                buttontext="BACK"
                className="cancel_btn mb-0"
                onClick={backTodetail}
              />
              <ButtonPrimary
              disabled={checkSelfiImg}
                buttontext="COMPLETE KYC"
                className="internalComn_btn mb-0"
                // onClick={handleClick}
              />
            </Col>
          </Row>
        </Col>
        </form>
      </MainCard>
    </>
  );
}

// export default KycdocUpload;
const mapStateToProps = (state) => {
  console.log('*****KYC FORM****', state);
  return {
    doc_type: state.security.doc_type,
    doc_front: state.security.doc_front,
    doc_back: state.security.doc_back,
    national_id: state.security.national_id,

    selfie: state.security.selfie,

    kyc_selfie_path: state.security.kyc_selfie_path,
    kyc_doc_path_front: state.security.kyc_doc_path_front,
    kyc_doc_path_back: state.security.kyc_doc_path_back,
    kyc_national_doc_path: state.security.kyc_national_doc_path,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    saveKycFormData: (data) => dispatch(saveKycFormData(data)),
    uploadRawFile: (data) => dispatch(uploadRawFile(data)),
    updateUserKyc: (data) => dispatch(updateUserKyc(data)),

  };
};
export default withRouter(
  connect(mapStateToProps, mapDispatchToProps)(KycdocUpload)
);

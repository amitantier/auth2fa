import React, { useState, useEffect, useCallback } from "react";
import MainCard from "../../../components/common/MainCard/MainCard";
import { useHistory } from "react-router-dom";
import KycDoc from "../../../theme/images/kyc_doc.svg";
import { Row, Col, Card } from "react-bootstrap";
import KycDocLite from "../../../theme/images/kyc_doc_lite.svg";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import "./Kyc.scss";
// import CardKyc from '../../../Components/CardKyc/CardKyc';
// import Processing from './Processing';
// import VerificationFailed from './VerificationFailed';
// import UploadDocuments  from './UploadDocuments';
// import TakeSelfie  from './TakeSelfie';
// import ConfirmYourDetails from './ConfirmYourDetails';
// import SettingsWrap from '../../../components/Sidebar/SettingsWrap';
import { toast } from "../../../components/Toast/Toast";
import { connect } from "react-redux";
import { getUserKycDetails, clearKycFormData, saveKycFormData } from "../../../redux/actions/SecurityActions";
import { PASSPORT_BACK, PASSPORT_FRONT, LICENSE_BACK, LICENSE_FRONT, NATIONAL_ID, KYC_APPROVED, KYC_DECLINED, KYC_RE_SUBMITTED, KYC_SUBMITTED } from "../../../constant"
import KycCompletedSuccessfully from "./KycCompletedSuccessfully"
import KycnotSubmit from "./KycnotSubmit";
import KycDetail from "./KycDetail";
import axios from 'axios';



const KycProcess = props => {
    const [isKycRes, setIsKycRes] = useState(false);

    const [processing, setProcessing] = useState(false);
    const [verificationFailed, setVerificationFailed] = useState(false);
    const [verificationApproved, setVerificationApproved] = useState(false);

    const [kycGetDetails, setKycGetDetails] = useState({});
    const [step, setStep] = useState(1);
    const history = useHistory();
    const handleOnClick = useCallback(() => history.push(`/auth/kyc`), [history]);

    useEffect(() => {
        getUserKycDetails();
        return () => {
            props.clearKycFormData()
        };
    }, []);

    useEffect(() => {
        if (kycGetDetails.documents != undefined) {

            setInitialValueStepFirst(kycGetDetails);
            setInitialValueStepSec(kycGetDetails);

        }
    }, [kycGetDetails]);


    const getUserKycDetails = () => {
        props.getUserKycDetails().then(async (res) => {
            await setKycGetDetails(res.data.data);
            if (res.data.data.status == KYC_APPROVED) {
                setVerificationApproved(true);
            }

            console.log('getUserKycDetails', res?.data?.data?.documents.length)
            if (res.data.data.status == KYC_DECLINED) {
                // setVerificationFailed(true);

            }

            console.log("kycGetDetails11", res.data.data);


        }).catch((error) => {
            setIsKycRes(true);

        })
    }


    const setInitialValueStepFirst = (kyc) => {
        console.log("DOC", kyc.documents);

        if (kyc.documents !== undefined) {
            kyc.documents.forEach(element => {

                if (element.type == PASSPORT_FRONT || element.type == LICENSE_FRONT) {
                    if (element.type == PASSPORT_FRONT) {
                        props.saveKycFormData({ prop: "doc_type", value: "Passport" })

                    }
                    if (element.type == LICENSE_FRONT) {
                        props.saveKycFormData({ prop: "doc_type", value: "License" })

                    }
                    props.saveKycFormData({ prop: "doc_front", value: element.file_id });
                    props.saveKycFormData({ prop: "kyc_doc_path_front", value: kyc.s3_base_path + element.s3_path });
                }
                if (element.type == PASSPORT_BACK || element.type == LICENSE_BACK) {
                    props.saveKycFormData({ prop: "doc_back", value: element.file_id });
                    props.saveKycFormData({ prop: "kyc_doc_path_back", value: kyc.s3_base_path + element.s3_path });
                }

                if (element.type == NATIONAL_ID) {
                    props.saveKycFormData({ prop: "national_id", value: element.file_id });
                    props.saveKycFormData({ prop: "kyc_doc_path_back", value: kyc.s3_base_path + element.s3_path });
                }


            });
        }
    }
    const setInitialValueStepSec = (kyc) => {
        if (kyc.selfie_id != null && kyc.selfie_id != undefined && kyc.selfie_id !== "") {
            props.saveKycFormData({ prop: 'selfie', value: kyc.selfie_id });
            props.saveKycFormData({ prop: 'kyc_selfie_path', value: kyc.s3_base_path + kyc.selfiePath });

        }

    }


    const moveToStep = (step) => {
        // stepDocument: step 1
        //stepSelfi :step 2
        //stepConfirmDetails: step 3
        setStep(step)
    }
    const checkStepFirstCompleted = () => {
        let { doc_type, doc_back, doc_front, national_id } = props
        if (doc_type == "" || doc_back == "" || doc_front == "" || national_id == "") {
            toast.error("All fields marked with * are mendatory")


        } else {
            moveToStep(2)
        }

    }
    const checkStepSecCompleted = () => {
        let { selfie } = props;
        if (selfie == "") {
            toast.error("Selfie is required");



        } else {
            moveToStep(3);
        }

    }



    return (
        <>
            {verificationApproved && <KycCompletedSuccessfully />}
            {!verificationApproved && (
                kycGetDetails && kycGetDetails > 0 ?
                    <KycDetail />
                    :
                    <KycnotSubmit />
            )}

        </>
    )

}


const mapStateToProps = state => {
    console.log("*****KYC FORM****", state)
    return {
        doc_type: state.security.doc_type,
        doc_front: state.security.doc_front,
        doc_back: state.security.doc_back,
        national_id: state.security.national_id,
        selfie: state.security.selfie,
        loading: state.loading.loading
    };
};

const mapDispatchToProps = dispatch => {
    return {
        getUserKycDetails: () => dispatch(getUserKycDetails()),
        clearKycFormData: () => dispatch(clearKycFormData()),
        getUserKycDetails: () => dispatch(getUserKycDetails()),
        saveKycFormData: (data) => dispatch(saveKycFormData(data)),



    };
};
export default (connect(
    mapStateToProps,
    mapDispatchToProps
)(KycProcess));


import React, { useState } from "react";
import { Row, Col, Card, Form } from "react-bootstrap";
import CustomInput from "../../../components/common/CustomInput/CustomInput";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import MainCard from "../../../components/common/MainCard/MainCard";
import "./Profile.scss";
import { resetUserPassword } from "../../../redux/actions/SecurityActions";
import { connect } from "react-redux";


function PasswordReset(props) {
  const [formData, setFormData] = useState([]);
  const [matchPass, setMatchPass] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [showPassMin, setShowPassMin] = useState(false);
  const [showPassSpecial, setShowPassSpecial] = useState(false);
  const [showPassUpperCase, setShowPassUpperCase] = useState(false);
  const [showPassLowerCase, setShowPassLowerCase] = useState(false);
  const [showPassNumber, setShowPassNumber] = useState(false);
  const [uniquePass, setUniquePass] = useState(false);

  

  const handleChange = (e, type) => {
    let value = e.target.value;
    let data = {}
console.log('handleChange',value,type)
    if (type === 'confirmPassword') {
      if (formData?.data?.new_password) {
        if (formData?.data?.new_password === value) {
          setMatchPass(false)
          setShowPass(false)
        } else {
          setShowPass(true)
          setMatchPass(true)
        }
      }
    }

    if (type === 'new_password') {
      if (formData?.data?.confirmPassword) {
        if (formData?.data?.confirmPassword === value) {
          setMatchPass(false)
          setShowPass(false)
        } else {
          setShowPass(true)
          setMatchPass(true)
        }
      }
    }

    if (type === 'old_password') {
      if (formData?.data?.new_password) {
        if (formData?.data?.new_password === value) {
          setShowPass(true)
          setMatchPass(true)
        } else {
          setMatchPass(false)
          setShowPass(false)
        }
      }
    }

    if (formData && formData?.data) {
      data = { ...formData?.data }
    }
    data[type] = value;
    setFormData({ ...formData, data })
  }

  const onFormSubmit = e => {
    e.preventDefault()
    delete formData.data['confirmPassword'];

    props.resetUserPassword(formData?.data).then((res) => {
    props.history.push('/auth/setting');
    }).catch((eror) => {
    })
  }

  const checkPassword = (e) => {
    console.log('checkPassword', (/[A-Z]/).test(e.target.value), e)

    if (!(/[A-Z]/).test(e.target.value)) {
      setShowPass(true)
      setShowPassUpperCase(true)
      setUniquePass(false)
      setShowPassMin(false)
      setShowPassLowerCase(false)
      setShowPassNumber(false)
      setShowPassSpecial(false)
    } else if (!(/[a-z]/).test(e.target.value)) {
      setShowPass(true)
      setShowPassLowerCase(true)
      setUniquePass(false)
      setShowPassMin(false)
      setShowPassUpperCase(false)
      setShowPassNumber(false)
      setShowPassSpecial(false)
    } else if(!(/[0-9]/).test(e.target.value)) {
      setShowPass(true)
      setShowPassNumber(true)
      setUniquePass(false)
      setShowPassMin(false)
      setShowPassUpperCase(false)
      setShowPassLowerCase(false)
      setShowPassSpecial(false)
    }  else if(!(/[^a-zA-Z0-9]/).test(e.target.value)) {
      setShowPass(true)
      setShowPassSpecial(true)
      setUniquePass(false)
      setShowPassNumber(false)
      setShowPassMin(false)
      setShowPassUpperCase(false)
      setShowPassLowerCase(false)
    }  else if (e.target.value.toString().length < 8) {
      setShowPass(true)
      setShowPassMin(true)
      setUniquePass(false)
      setShowPassNumber(false)
      setShowPassUpperCase(false)
      setShowPassLowerCase(false)
      setShowPassSpecial(false)
    } else if (e.target.value === formData?.data?.old_password) {
      setShowPass(true)
      setUniquePass(true)
      setShowPassMin(false)
      setShowPassNumber(false)
      setShowPassUpperCase(false)
      setShowPassLowerCase(false)
      setShowPassSpecial(false)
    } else {
      setUniquePass(false)
      setShowPass(false)
      setShowPassMin(false)
      setShowPassUpperCase(false)
      setShowPassLowerCase(false)
      setShowPassNumber(false)
      setShowPassSpecial(false)
    }

  }

  return (
    <>
      <Col xs={12} lg={8} className="mx-auto">
        <MainCard className="mainCard_padding">
          <Card.Title className="cardTitle_Padding">Password Reset</Card.Title>
          <Form onSubmit={onFormSubmit}>
            <Row className="m-0 profileDetail_Row passwordReset_Row">
              <Col xs={12} lg={6}>
                <CustomInput
                  handleChange={handleChange}
                  label="Old Password*"
                  className="internalInput"
                  type="password"
                  name="old_password"
                ></CustomInput>
              </Col>
              <Col xs={12} lg={6}>
                <CustomInput
                  handleChange={handleChange}
                  label="New Password*"
                  className="internalInput"
                  type="password"
                  checkPassword={checkPassword}
                  name="new_password"
                >
                  {/* {showPassMin && <p>Password cannot be empty</p>} */}
                  {showPassUpperCase && <p style={{ color: 'red' }}>One uppercase character</p>}
                  {showPassLowerCase && <p style={{ color: 'red' }}>One lowercase character</p>}
                  {showPassNumber && <p style={{ color: 'red' }}>One number</p>}
                  {showPassSpecial && <p style={{ color: 'red' }}>One special character</p>}
                  {showPassMin && <p style={{ color: 'red' }}>8 characters minimum</p>}
                  {uniquePass && <p style={{ color: 'red' }}>New password should be unique</p>}

                </CustomInput>
              </Col>
              <Col xs={12} lg={6}>
                <CustomInput
                  name="confirmPassword"
                  handleChange={handleChange}
                  label="Confirm Password*"
                  className="internalInput"
                  type="password"
                >
                 {matchPass && <p style={{color:'red'}}>Confirm passwords must match</p>}
                </CustomInput>
              </Col>
              <Col xs={12} lg={6}>
                <ButtonPrimary
                disabled={showPass || uniquePass}
                  buttontext="Save Password"
                  className="internalComn_btn passwordSave_Btn"
                />
              </Col>
            </Row>
          </Form>
        </MainCard>
      </Col>
    </>
  );
}

const mapStateToProps = state => {
  console.log("***********", state)
  return {

  };
};

const mapDispatchToProps = dispatch => {
  return {
    resetUserPassword: (data) => dispatch(resetUserPassword(data))

  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(PasswordReset);
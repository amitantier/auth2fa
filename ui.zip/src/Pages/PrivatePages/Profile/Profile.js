import React, { useEffect, useState } from "react";
import { Row, Col, Card, Form } from "react-bootstrap";
import CustomInput from "../../../components/common/CustomInput/CustomInput";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import MainCard from "../../../components/common/MainCard/MainCard";
import CountryPicker from "../../../components/common/CountryPicker/CountryPicker";
import PhoneInput from "../../../components/common/PhoneInput/PhoneInput";
import "./Profile.scss";
import { connect } from "react-redux";
import { getFormatedCountries } from "../../../Helpers/Normailize";
import { getData } from "country-list";
import { getUserProfile } from "../../../redux/actions/SecurityActions"
import { updateUserProfile } from "../../../redux/actions/SecurityActions"
import * as Yup from "yup";
import axios from 'axios';
import TimezoneSelect from 'react-timezone-select';

import {
  getCountries,
  getCountryCallingCode,
} from "react-phone-number-input/input";

const currencyType = [
  { key: 1, value: "INR", label: "INR" },
  { key: 2, value: "USDT", label: "USDT" }];

const genderType = [
  { key: 1, value: "M", label: "Male" },
  { key: 2, value: "F", label: "Female" }];

function Profile(props) {

  useEffect(() => {
    getCountryCode();
    getUserProfileData()
    return () => {

    };
  }, [])
  const [phone_code, setPhoneCode] = React.useState("");
  const [phoneNumberMin, setPhoneNumberMin] = React.useState(false);
  const [phoneNumberMax, setPhoneNumberMax] = React.useState(false);

  const [profiles, setProfiles] = React.useState([]);
  const [selectedTimezone, setSelectedTimezone] = React.useState('')
  const [formData, setFormData] = useState([]);

  // Getting and setting all countries data for dropdown options
  const CountryName = getFormatedCountries(getData());
  

  const options = () => {
    const optionsList = [];
    getCountries().forEach((country, index) => {
      const value = `${getCountryCallingCode(country)}`;
      optionsList.push({
        // key: `${index}_${value}`,
        value: `+${value}`,
        label: `+${value}`,
      });
    });
    return optionsList;
  };

  // Getting country phone-code for default code in mobile field
  const getCountryCode = () => {
    axios.get('https://ipapi.co/json/').then(response => {
      let data = response.data;
      let c_code = data.country_calling_code;
      console.log('phone_code', c_code)
      setPhoneCode(c_code)

    });
  };

  const getUserProfileData = (data) => {
    props.getUserProfile().then((res) => {
      console.log("((", res.data.data[0])
      setProfiles(res.data.data);
      //  let data = {data:res.data.data};

      setFormData({ ...formData, data: res.data.data[0] })

      setPhoneCode('+' + res.data.data[0].mobileCode)
      setSelectedTimezone((res.data.data[0].timezonePreferences))
    }).catch((error) => {

    })
  }

  const handleChange = (e, type) => {
    console.log('handleChange', e)
    let value = {};
    let data = {}

    if (formData && formData?.data) {
      data = { ...formData?.data }
    }
    if (type === "timezonePreferences") {
      data["timezoneName"] = e.altName;
      data["timezonelabel"] = e.label;
      data["timezoneoffset"] = e.offset;
      data["timezoneabbrev"] = e.abbrev;
      data["timezoneValue"] = e.value;
    } else {
      if (type === "mobileCode") {
        value = e.value
      } else {
        value = e.target.value
      }
      data[type] = value;
    }
    setFormData({ ...formData, data })
  }

  const onFormSubmit = e => {
    e.preventDefault()
    props.updateUserProfile(formData?.data).then((res) => {
      props.getUserProfile();
    }).catch((err) => {
    })
  }

  const checkMobileNo = (e) => {
    if (e.target.value.toString().length < 10) {
      setPhoneNumberMin(true)
    } else {
      setPhoneNumberMin(false)
    }
    if (e.target.value.toString().length > 10) {
      setPhoneNumberMax(true)
    } else {
      setPhoneNumberMax(false)
    }
  }

  return (
    <div>
      {console.log('profiles', formData)}
      <MainCard className="mainCard_padding">
        <Card.Title className="cardTitle_Padding"> Profile</Card.Title>
        <Form onSubmit={onFormSubmit} className="">

          <Col className="profileDetail_Row">
            <Row>
              <Col xs={12} lg={4}>
                <CustomInput
                  value={formData?.data?.first_name ? formData?.data?.first_name : ''}
                  label="First Name"
                  className="internalInput"
                  placeholder="First Name"
                  handleChange={handleChange}
                  name="first_name"
                >
                  <p>This is required field</p>
                </CustomInput>
              </Col>

              <Col xs={12} lg={4}>
                <CustomInput
                  value={formData?.data?.last_name ? formData?.data?.last_name : ''}
                  label="Last Name"
                  className="internalInput"
                  placeholder="Last Name"
                  handleChange={handleChange}
                  name="last_name"
                ></CustomInput>
              </Col>
              <Col xs={12} lg={4}>
                <CustomInput
                  value={formData?.data?.email ? formData?.data?.email : profiles[0]?.email}
                  label="Email ID"
                  placeholder="Email Id"
                  className="internalInput"
                  disabled
                ></CustomInput>
              </Col>
              <Col xs={12} lg={4}>
                <CountryPicker

                  defaultValue={profiles[0]?.country ? profiles[0]?.country : ""}
                  countryName={CountryName}
                  label="Country*"
                  placeholder="Select Country"
                  className="internalInput"
                  name="country"
                  handleChange={handleChange}
                ></CountryPicker>
              </Col>
              <Col xs={12} lg={4}>
                <CountryPicker
                  defaultValue={profiles[0]?.currencyPreferences ? profiles[0]?.currencyPreferences : ""}
                  countryName={currencyType}
                  label="Currency Preference"
                  placeholder="USD"
                  name="currencyPreferences"
                  className="internalInput"
                  handleChange={handleChange}
                ></CountryPicker>
              </Col>
              <Col xs={12} lg={4}>
                <div className="customSelect">
              <label class="form-label">Timezone Preference*</label>
                <TimezoneSelect
                  label="Time Zone"
                  value={selectedTimezone}
                  classNamePrefix="react-select"
                  //onBlur={() => setFieldTouched("timezonePreferences", true)}
                  onChange={(value) => {
                    console.log(value)
                    handleChange(value, 'timezonePreferences')
                    setSelectedTimezone(value)
                    //setFieldValue("timezonePreferences", value)
                  }}
                >

                </TimezoneSelect>
                </div>
              </Col>
              <Col xs={12} lg={4}>
                <PhoneInput
                  checkMobileNo={checkMobileNo}
                  value={formData?.data?.mobileNumber ? formData?.data?.mobileNumber : ''}
                  options={options()}
                  name="mobileNumber"
                  handleChange={handleChange}
                  defaultValue={formData?.data?.mobileCode ? formData?.data?.mobileCode : phone_code}
                  className="internalInput" label="Phone Number*" >
                  {phoneNumberMin && <p style={{ color: 'red' }}>Phone No. is too short</p>}
                  {phoneNumberMax && <p style={{ color: 'red' }}>Phone No. is too long</p>}
                </PhoneInput>
              </Col>
              <Col xs={12} lg={4} lg={{ span: 4, offset: 4 }}>
                <ButtonPrimary
                  disabled={phoneNumberMin || phoneNumberMax ? true : false}
                  buttontext="SAVE"
                  className="internalComn_btn mb-0 profileSave_Btn"
                />
              </Col>
            </Row>
          </Col>
        </Form>
      </MainCard>
    </div>
  );
}


const mapStateToProps = state => {
  console.log("****Profile****", state)
  return {

  };
};

const mapDispatchToProps = dispatch => {
  return {
    getUserProfile: () => dispatch(getUserProfile()),
    updateUserProfile: (data) => dispatch(updateUserProfile(data))

  };
};
export default (connect(
  mapStateToProps,
  mapDispatchToProps
)(Profile));

import React from "react";
import { Row, Col } from "react-bootstrap";
import DeviceIcon from "../../../theme/images/device_icon.svg";
import MainCard from "../../../components/common/MainCard/MainCard";
import DotIcon from "../../../theme/images/dot_icon.svg";
import DotIconLite from "../../../theme/images/dot_icon_lite.svg";
import DeviceCard from "../../../components/common/DeviceCard/DeviceCard";
import "../Setting/Setting.scss";
import "./DeviceManagement.scss";

function DeviceManagement() {
  return (
    <>
      {/* <Row className="settingRow_style">
        <Col lg={10} md={10} className="deviceCol_style"> */}
          <MainCard title="Device Management" className="mainCard_padding deviceCol_style">
            <div className="deviceWrap_style">
              <Row className="m-0 deviceRow_style">
                <DeviceCard
                  icon={DeviceIcon}
                  device="Windows"
                  ip="42.109.228.10"
                  location="India"
                  alt="kyc icon"
                  browser="Mozilla"
                  status="Active Now"
                  iconsecond={DotIcon}
                  iconsecondLite={DotIconLite}
                />

                <DeviceCard
                  icon={DeviceIcon}
                  device="Windows"
                  ip="42.109.228.10"
                  location="India"
                  alt="kyc icon"
                  browser="Mozilla"
                  status="Active Now"
                  iconsecond={DotIcon}
                  iconsecondLite={DotIconLite}
                />
                <DeviceCard
                  icon={DeviceIcon}
                  device="Windows"
                  ip="42.109.228.10"
                  location="India"
                  alt="kyc icon"
                  browser="Mozilla"
                  status="Active Now"
                  iconsecond={DotIcon}
                  iconsecondLite={DotIconLite}
                />
              </Row>
            </div>
          </MainCard>
        {/* </Col>
      </Row> */}
    </>
  );
}

export default DeviceManagement;

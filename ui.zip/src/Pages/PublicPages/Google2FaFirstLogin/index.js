import React ,{useEffect}from 'react'
import { Container, Row, Col, Form } from 'react-bootstrap';
import {Link} from 'react-router-dom'

import { connect } from "react-redux";
import   Authenticator from "../Authenticator";
import AuthenticatorCode from "../AuthenticatorCode"
import {get2FaImage} from "../../../redux/actions/SecurityActions"



const Google2FaFirstLgin = (props) => {

  useEffect(()=>{
     props.get2FaImage({ "issuer":""}).then((res)=>{
       
     })
  },[])
    const [step, setStep] = React.useState(1);
    const onChangeStep =(step)=>{
        setStep(step);
    }

    return(
        <>
        {step ==1 ?
       <Authenticator changeStep={onChangeStep}/>
       :
       <AuthenticatorCode changeStep={onChangeStep}/>
       
        }
        </>
    )

}


const mapStateToProps = state => {
    console.log("***********",state)
    return {
        isUserFirstTimeLogin:state.persist.isUserFirstTimeLogin,
        secret: state.security.secret,
        qrImgUrl:state.security.qrImgUrl

    };
  };
  
  const mapDispatchToProps = dispatch => {
    return {
      get2FaImage:(data)=>dispatch(get2FaImage(data))

    };
  };
  export default connect(
    mapStateToProps,
    mapDispatchToProps
  )(Google2FaFirstLgin);
  


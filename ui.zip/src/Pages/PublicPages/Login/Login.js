import React,{useState,useEffect} from "react";
import { Form } from "react-bootstrap";
import { Link } from "react-router-dom";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import CustomInput from "../../../components/common/CustomInput/CustomInput";
import CommonCont from "../../../components/CommonCont/CommonCont";
import PassworHide from "../../../theme/images/eye_slash.svg";
import PassworShow from "../../../theme/images/eye_open.svg";
import {
  userLogin,getUserIpAddress,getUserInfoAfterLoginOnly
} from "../../../redux/actions/AuthActions";
import {
  updateFirstTimeLoginState
} from "../../../redux/actions/PersistActions";
import "./Login.scss";
import {connect} from 'react-redux';
import ReCAPTCHA from "react-google-recaptcha";
import { CAPTCHA_KEY,AUTH_TOKEN_KEY } from "../../../constant";
import { setToken } from "../../../Helpers/storageHelper";


function Login(props) {
  const [checkEmail, setCheckEmail] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [formData, setFormData] = useState([]);
  const [setCaptchaValue, setMyCaptchaValue] = useState("");
  const [ip, setIp] = useState("");
  const [loginTempToken, setLoginTempToken] = useState("");

  const capthaKey = CAPTCHA_KEY;

  const getUserIpAddress = () => {
    props.getUserIpAddress().then((res) => {
      setIp(res.data.ip);
    });
  };
  const showHide = (e, value) => {
    e.preventDefault();
      setShowPass(!showPass)
  }

  const handleChange = (e, type) => {
    console.log('handleChange',ip)

    let value = e.target.value;
    let data = {
      // capReq: '1',
        ip : ip,
      // device_type: '3',
     
    }
    if (formData && formData?.data) {
      data = { ...formData.data }
    }
    data[type] = value;
    setFormData({ ...formData, data })
  }

  const onFormSubmit = e => {
    e.preventDefault()
    props.userLogin(formData.data)
    .then(async (resp) => {
      //  let isUserLogin = res.isFirstLogin;
      let isUserLogin = resp.data.isFirstLogin;
      console.log('isUserLogin',isUserLogin,resp)
      await props.updateFirstTimeLoginState(isUserLogin);
      await setLoginTempToken(resp.data.JwtToken);
      props
        .getUserInfoAfterLoginOnly(resp.data.JwtToken)
        .then(async (res) => {
          let user_info = res.data.data;
          setLoginTempToken(resp.data.JwtToken);
         // setShowOption2fa(false);
          await setToken(
            AUTH_TOKEN_KEY,
            resp.data.JwtToken,
            1
          ); // 6 hrs
          props.history.push(`/auth/dashboard`);
        });
    })
    .catch((error) => {
      console.log("errrrrrr");
      resetCaptcha();
    });
  // actions.setSubmitting(false);
  }

  const handleChangeRecaptcha = value => {
    setMyCaptchaValue(value);
    let data = {}
    if (formData && formData?.data) {
      data = { ...formData?.data }
    }
    data['ip'] = ip;
    // data['captchatext'] = value;
    setFormData({ ...formData, data })
  };

  const resetCaptcha = () => {
    window["grecaptcha"].reset();
    setMyCaptchaValue("")
  };

  const checkEmailValidity = (email) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
  }

  const checkEmailExist = () => {
    console.log('checkEmailExist', formData?.data?.email)
    if (checkEmailValidity(formData?.data?.email)) {
      setCheckEmail(false)
    } else {
      setCheckEmail(true)
    }

  }

  useEffect(() => {
    getUserIpAddress();
  }, []);

  const checkPassword = (e) => {}
  

  return (
    <>
      <CommonCont
        heading="Sign In"
        subheading="Welcome back! Log In with your Email, Phone number or QR code"
        className="loginCont_Style"
      >
        <Form onSubmit={onFormSubmit} className="commonForm_style">
          <CustomInput name="email" handleChange={handleChange}  placeholder="Email" 
           checkEmailExist={checkEmailExist}
           >            {checkEmail && <p style={{ marginTop: '10px', color: 'red' }}>Email has to be valid</p>}
        </CustomInput>
          <CustomInput checkPassword={checkPassword} name="password" handleChange={handleChange} type={showPass ? `text` : `password`}  placeholder="Password">
            <a onClick={(e) => { showHide(e, 'password') }} className="showPassword">
              {showPass ? <img src={PassworShow} /> : <img src={PassworHide} />}
            </a>
          </CustomInput>
          <a className="forgotLink">Forgot <br/> Password?</a>

          {/* <ReCAPTCHA
            theme="light"
            sitekey={capthaKey}
            onExpired={() => resetCaptcha()}
            onChange={handleChangeRecaptcha}
          /> */}
          <ButtonPrimary
          style={{marginTop: '10px'}}
          //  disabled={setCaptchaValue == ""} 
           
           buttontext="Login" />
        </Form>


        <p>
          New User? <Link to="/signup">Sign Up</Link>
        </p>
      </CommonCont>
    </>
  );
}

const mapStateToProps = (state) => {
  console.log("LOGIN", state);
  return {};
};

const mapDispatchToProps = (dispatch) => {
  return {
    userLogin: (data) => dispatch(userLogin(data)),
    getUserIpAddress: () => dispatch(getUserIpAddress()),
    updateFirstTimeLoginState: (data) =>
      dispatch(updateFirstTimeLoginState(data)),
    getUserInfoAfterLoginOnly: (token) =>
      dispatch(getUserInfoAfterLoginOnly(token)),
    // send2faEmailVerification: (token) =>
    //   dispatch(send2faEmailVerification(token)),
    // token_verification_email: (data) => dispatch(token_verification(data)),
    // token_verification_google: (data) =>
    //   dispatch(token_verification_google(data)),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Login);

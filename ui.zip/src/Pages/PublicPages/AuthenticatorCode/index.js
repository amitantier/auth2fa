import React, { Component } from 'react';
import CardSquare from '../../../components/CardSquare/CardSquare'
// import '././AuthenticatorCodeStyle.scss'
import {Link} from 'react-router-dom'
import { Container, Row, Col } from 'react-bootstrap';
// import Header from '../../../Components/Header/Header'
import ButtonCustom from '../../../components/ButtonCustom/ButtonCustom'
import InputCustom from '../../../components/InputCustom/InputCustom'
import copy_icon  from '../../../assets/images/copy_icon.png'
import ReactCodeInput from 'react-code-input';
import { connect } from "react-redux";
import {google2faValidate} from "../../../redux/actions/SecurityActions";
import {CopyToClipboard} from 'react-copy-to-clipboard';
import {updateFirstTimeLoginState} from "../../../redux/actions/PersistActions";
import { withRouter } from "react-router";

const AuthenticatorCode = (props) =>{
    const [token, setToken] = React.useState("");
    const [copied, setCopied] = React.useState(false);

     const enableUserGoogleAuth = ()=>{
         let data = {
          acceptTerms: true,
          secret: props.secret,
          token: token
         }
         props.google2faValidate(data).then((res)=>{
            goTokyc();

         }).catch((error)=>{
         })
     }

     const goTokyc = async()=>{
        await props.updateFirstTimeLoginState(1);
        props.history.push(`/auth/kyc-process`);

    }

    return(
        <>
        {/* <Header /> */}
        <Container fluid className="containerFullWidth">
            <CardSquare className="auth_cardCode">
                <Col className="auth_card__header">
                    <h1>Confirm Authenticator Code</h1>
                    <p>Make a physical or e-copy of your bakup code to secure your account </p>
                </Col>
                <Col className="wrap_input">

                    <InputCustom 
                     
                        type="email"
                        value={props.secret.slice(0,44)}
                        disabled="true"
                      
                    />
                <CopyToClipboard text={props.secret} onCopy={() => setCopied(true)}>
                
                    <span className="is_verified">
                        <img src={copy_icon} />
                    </span>
                    
                    </CopyToClipboard>
                    {copied ? <span  className="isCopied" style={{color: 'red'}}>Copied.</span> : null}


                </Col>
                <Col className="auth_cardCode__info">
                    <p>
                        In any scenario, we do not recommend sharing or publishing the backup 
                        code with any part or anywhere or anywhere on private or public domain
                    </p>
                   
                </Col>  
                <Col className="auth_cardCode__pinHlder">
                <h2>6 digit code displayed by your app</h2>
                <ReactCodeInput type='number' fields={6} value={token} onChange={(code)=>setToken(code)}/>
                </Col>             
                <Col className="auth_card__btnCustom">
                    <ButtonCustom
                        className="auth_card__continue" 
                        type="button"
                        disabled={token.length!==6}
                        buttontext="Continue"
                        onClick={()=>enableUserGoogleAuth()}
                    />
                    <Link className="auth_card__skipBtns" onClick={()=>goTokyc()}>Skip For Now</Link>
                </Col>
               
            </CardSquare>
        </Container>
        </>
    )
}


const mapStateToProps = state => {
    console.log("***********",state)
    return {
        isUserFirstTimeLogin:state.persist.isUserFirstTimeLogin,
        secret: state.security.secret,
        qrImgUrl:state.security.qrImgUrl

    };
  };
  
  const mapDispatchToProps = dispatch => {
    return {
        google2faValidate:(data)=>dispatch(google2faValidate(data)),
        updateFirstTimeLoginState:(data)=>dispatch(updateFirstTimeLoginState(data)),

    };
  };
  export default withRouter(connect(
    mapStateToProps,
    mapDispatchToProps
  )(AuthenticatorCode));
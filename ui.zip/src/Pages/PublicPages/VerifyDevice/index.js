import React , {useEffect} from 'react'
import { useParams } from "react-router";
import { connect } from "react-redux";

import {verifyUserDevice} from "../../../redux/actions/AuthActions"


const VerifyDevice = (props) =>{
    const { hashCode } = useParams();

    useEffect(()=>{
        let data = {
            hash:hashCode
        }
       props.verifyUserDevice(data).then((res)=>{
        props.history.push(`/login`)
    },(err)=>{
           props.history.push(`/login`)

       })

      },[])
    
    return(
        <>
      
       
        </>
    )
}



const mapStateToProps = state => {
    return {
      email:state.register.email
    };
  };
  
  const mapDispatchToProps = dispatch => {
    return {
        verifyUserDevice:(data)=>dispatch(verifyUserDevice(data))

    };
  };
  export default connect(
    mapStateToProps,
    mapDispatchToProps
  )(VerifyDevice);
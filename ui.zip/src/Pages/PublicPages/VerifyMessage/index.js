import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import {Link} from 'react-router-dom'
import 'react-multi-carousel/lib/styles.css';
// import SettingsWrap from '../../../Components/Sidebar/SettingsWrap'
// import './index.scss';
import CardSquare  from '../../../components/CardSquare/CardSquare'
// import Header from '../../../Components/Header/Header'
import VerifyBlock from '../../../components/VerifyBlock/VerifyBlock'
import verifyMessage from '../../../assets/images/verify_your_account.png'
// import ButtonCustom from '../../../Components/ButtonCustom/ButtonCustom'
import {resendVerificationMail} from "../../../redux/actions/AuthActions"
import { connect } from "react-redux";

const VerifyMessage = props => {
    const resendVerifyEmail =()=>{
        let data = {
            email:props.email
        }
        props.resendVerificationMail(data).then((res)=>{
            
        })
    }
    return(
        <>
        {/* <Header /> */}
        <Container fluid className="verify_style_outer">
            <CardSquare className="verify_style">
                <VerifyBlock 
                onClick={()=> props.history.push(`/signin`)
            }
                icon={verifyMessage}
                title="Verify Your Account"
                subTitle="Please check your email to verify your Account"
                >
                 <Row>
                     <Col>
                        <Link className="btn themeButton link_signIn" to={`/signin`}>Sign in</Link>
                     </Col>
                     <Col>
                        <Link className="link_resend" onClick={()=>resendVerifyEmail()}>Resend</Link>
                     </Col>
                 </Row>
                </VerifyBlock>
            </CardSquare>
        </Container>
        </>
        
    )

}
const mapStateToProps = state => {
    return {
        email: state.register.email,

    };
};

const mapDispatchToProps = dispatch => {
    return {
        resendVerificationMail: (data) => dispatch(resendVerificationMail(data)),
      

    };
};
export default connect(
    mapStateToProps,
    mapDispatchToProps
)(VerifyMessage);

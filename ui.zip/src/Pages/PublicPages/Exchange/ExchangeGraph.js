import React from "react";
import TradingViewWidget, { Themes } from "react-tradingview-widget";
import { pairSwap } from "../../../Helpers/Normailize";

export default function ExchangeGraph(props) {
  return (
    <TradingViewWidget
      symbol={pairSwap(props.pair)}
      theme={Themes.DARK}
      locale="en"
      autosize
    />
  );
}

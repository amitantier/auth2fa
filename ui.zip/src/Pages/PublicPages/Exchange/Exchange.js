import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import BuySell from "./BuySell";
import HeaderExchange from "../../../components/HeaderExchange/HeaderExchange";
import Leftside from "./Leftside";
import Trades from "./Trades";
import History from "./History";
import Order from "./Order";
import Assets from "./Assets";
import Tradebar from "../../../Components/Tradebar/Tradebar";
import ExchangeGraph from "./ExchangeGraph";
import socket from "../../../socket/index";
import { getToken } from "../../../Helpers/storageHelper";
import { AUTH_TOKEN_KEY } from "../../../constant";
import { saveStatData, getPairList, savePairList } from "../../../redux/actions/ExchangeActions";
import { connect } from "react-redux";
// import "./ExchangeStyle.scss";

const Exchange = (props) => {
  const params = useParams();
  const [base, setBase] = useState("");
  const [other, setOther] = useState("");
  const [headerData, setHeaderData] = useState({});
  const [pairlist, setPairlist] = useState([]);

  const [allPairsArray, setallPairsArray] = useState([]);


  const [selectedPair, setSelectedPair] = useState("");



  const [TRADE_DATA, setTRADE_DATA] = useState([{ price: 0, amount: "", date: "", fUser: "", tUser: "", side: "" }]);
  const [TRADE_DATA_SINGLE, setTRADE_DATA_SINGLE] = useState([{ price: 0, amount: "", date: "", fUser: "", tUser: "", side: "" }]);




  useEffect(() => {
    //socket listner function for stat data
    getStatData();
    getPairList();
    return () => {
    };
  }, []);

  useEffect(() => {
    connectSocketOnPageLoad();
    setCurrency();
    getPairList(); // temo

  }, [params.pair]);

  const connectSocketOnPageLoad = () => {
    //ngOnit data
    localStorage.setItem("lastPriceStatus", "0");

    let selectedPair = params.pair;
    setSelectedPair(selectedPair);

    let pairs = selectedPair.split("_"); // pair (i.e btc_eth)

    props.saveStatData({ prop: "seletedPair", value: selectedPair }); // pair  (i.e btc_eth)
    props.saveStatData({ prop: "pair1", value: pairs[0] }); // pair 1  (i.e btc)
    props.saveStatData({ prop: "pair2", value: pairs[1] }); // pair 2 (i.e eth)
    localStorage.setItem("marketTab", pairs[0]);


    socket.emit("currentPair", {
      pair: selectedPair,
      member: getToken(AUTH_TOKEN_KEY),
      accessToken: getToken(AUTH_TOKEN_KEY),
    });


  };

  const getPairList = () => {
    let PAIRELEMENT_DATA = [{ pairs: "", price: 0, change: "", pair_key: "" }];

    props.getPairList().then((res) => {
      console.log("ORIGINAL", res.data.data)
      setPairlist(res.data.data);

      let pairsListings = res.data.data
      if (PAIRELEMENT_DATA.length > 0) {

        PAIRELEMENT_DATA = [];
      }

      pairsListings.forEach((element) => {
        let allArrayPair = [...allPairsArray];
        allArrayPair.push(element.pair_key);
        setallPairsArray(allArrayPair);


        if (element.pair_key == selectedPair) {
          props.saveStatData({ prop: "mintradefee", value: element.minimum_trade });

          // min trade
          props.saveStatData({ prop: "tradebuyfee", value: element.trade_fee_buy });

          // trade buy fee

          props.saveStatData({ prop: "tradesellfee", value: element.trade_fee_sell });

          // trade sell fee

          props.saveStatData({ prop: "lastPrice", value: element.last_price });

          // last price
          props.saveStatData({ prop: "lastPriceSingle", value: element.last_price });

          // last price
        }


        if (element.is_active == 1) {
          let data = {
            pairs: element.pair_name,
            price: 0, //for temperary only
            change: element.last_price + "%",
            pair_key: element.pair_key,
          }

          let orginalData = [...PAIRELEMENT_DATA];
          orginalData.push(data)
          PAIRELEMENT_DATA = orginalData;
        }
      });

      let pairdataSource = [];

      for (var i = 0; i < PAIRELEMENT_DATA.length; i++) {
        pairdataSource = [...pairdataSource, PAIRELEMENT_DATA[i]];
      }

      console.log("pairdataSource", pairdataSource)
      props.savePairList(pairdataSource);
    }).catch((error) => {
      PAIRELEMENT_DATA = []
    })



  }



  const getStatData = () => {

    //1st socket

    let currentStat = "stat_" + params.pair;
    socket.on(currentStat, (statData) => {
      console.log("Called")
      console.log("pair", params.pair);
      console.log(`stat_${params.pair}`);
      console.log("header data", JSON.parse(statData));

      let stat_Data = JSON.parse(statData);
      if (stat_Data != false) {
        //SAVING 24H Volume in redux
        props.saveStatData({ prop: "statVolume", value: stat_Data["v"] != null ? stat_Data["v"] : 0 });
        //SAVING 24H High 
        props.saveStatData({ prop: "statHigh", value: stat_Data["h"] != null ? stat_Data["h"] : 0 });
        //SAVING 24H Low
        props.saveStatData({ prop: "statLow", value: stat_Data["l"] != null ? stat_Data["l"] : 0 });
        //SAVING stat open
        props.saveStatData({ prop: "statOpen", value: stat_Data["o"] != null ? stat_Data["o"] : 0 })

        // Calculating percentage change
        let percentage_chage =
          ((stat_Data["l"] - stat_Data["h"]) / stat_Data["l"]) * 100;

        if (!isFinite(percentage_chage)) {
          percentage_chage = 0;
        }
        // SAVING 24H Change
        props.saveStatData({ prop: "statChange", value: percentage_chage });
        //SAVING 24H Change percetage
        props.saveStatData({ prop: "statChangeprcent", value: stat_Data["h"] - stat_Data["l"] });
        // SAVING Last Price
        props.saveStatData({ prop: "lastPrice", value: stat_Data["p"] });

      }
    });


    //2nd socket 
    //Looks unused data
    socket.on('order_response', (data) => {
      console.log('order_response', data)

      props.saveStatData({ prop: "orderresponse", value: data });
      props.saveStatData({ prop: "orderresponse", value: "" });

    });

    // 3rd socket
    //---------------------ALL PAIRS--------------------------------
    socket.on("allStat", (data) => {
      let stat_Data1 = JSON.parse(data);
      if (stat_Data1 != false) {
        let pair = stat_Data1["pair"]
        let percentage_change =
          ((stat_Data1["h"] - stat_Data1["l"]) / stat_Data1["l"]) * 100;
        if (isNaN(percentage_change)) {
          percentage_change = 0;
        }
        let statPairsArray = [];
        statPairsArray[pair] = [];
        statPairsArray[pair]["volume"] =
          stat_Data1["v"] != null ? stat_Data1["v"] : 0;
        statPairsArray[pair]["change"] = percentage_change;

        if (stat_Data1["p"]) {
          statPairsArray[pair]["price"] = stat_Data1["p"];
        } else {
          statPairsArray[pair]["price"] = 0;
        }
        console.log("statPairsArray", statPairsArray)
        props.saveStatData({ prop: "sidePairStat", value: statPairsArray });

      }
    })

  };

  //
  const connectSocket = () => {

    let selectedPair = params.pair;
    setSelectedPair(selectedPair);

    socket.emit("currentPair", {
      pair: selectedPair,
      member: getToken(AUTH_TOKEN_KEY),
      accessToken: getToken(AUTH_TOKEN_KEY),
    });

    getOpenOrderFromStat();
    completeOrderListFromSocket();
    getStatData(); // seprate fxn (angular twice repeat)


  }

  const getOpenOrderFromStat = () => {

  }
  const completeOrderListFromSocket = () => {

  }


  const setCurrency = () => {
    let currencies = params.pair;
    let result = currencies.split("_");
    setBase(result[0].toUpperCase());
    setOther(result[1].toUpperCase());
  };

  return (
    <div fluid className="main_box">
      <HeaderExchange></HeaderExchange>

      <div className="mainBox">
        <div className="advance-trade">
          <Tradebar headerData={headerData} pair={params.pair}></Tradebar>
        </div>
        <div className="chart">
          <div className="boxc1">
            <div className="chartIn">
              <div className="boxcc1  box-bg">
                <Leftside pairList={props.pairList}></Leftside>
              </div>
              <div className="boxcc2">
                {/* <img className="graph" src={graph} /> */}
                <ExchangeGraph pair={params.pair} />
              </div>
            </div>
          </div>
          <div className="boxc2 box-bg pd-0">
            <History></History>
          </div>
        </div>
        <div className="orderbook ">
          <div className="box1  box-bg">
            <Order></Order>
          </div>
          <div className="box2 box-bg">
            <Trades></Trades>
          </div>
        </div>

        <div className="trade">
          <div className="boxt1 box-bg pd-0">
            <BuySell base={base} other={other}></BuySell>
          </div>
          <div className="boxt2 box-bg">
            <Assets></Assets>
          </div>
        </div>
      </div>
    </div>
  );
};

const mapStateToProps = state => {
  console.log("EXCHANGE REDUX", state)
  return {
    lastPrice: state.exchange.lastPrice, //Last Price
    statChange: state.exchange.statChange,//24H Change
    statChangeprcent: state.exchange.statChangeprcent,//24H Change percetage
    statHigh: state.exchange.statHigh, //24H High
    statLow: state.exchange.statLow, //24H Low
    statVolume: state.exchange.statVolume, //24H Volume
    pair1: state.exchange.pair1, //eg USDT
    statOpen: state.exchange.statOpen, // stat open
    pairList: state.exchange.pairList //pairs list
  };
};

const mapDispatchToProps = dispatch => {
  return {
    saveStatData: (data) => dispatch(saveStatData(data)),
    getPairList: () => dispatch(getPairList()),
    savePairList: (data) => dispatch(savePairList(data))
  };

};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Exchange);


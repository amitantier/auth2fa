import React, { useEffect } from "react";
import { Tabs, Tab } from "react-bootstrap";
import arrow from "../../../assets/images/arrow.svg";
import socket from "../../../socket/index";

function Order() {
  useEffect(() => {
    let data = "";
    // socket.emit("sellOrders", data);
    // socket.on("sellOrders", (data) => {
    //   // console.log("1", data);
    // });
    console.log(data);
  }, []);
  return (
    <Tabs
      defaultActiveKey="openorder"
      id="uncontrolled-tab-example "
      className="buysell-tab"
    >
      <Tab eventKey="openorder" title="" className="">
        <div className="table-responsive  buysell-table">
          <div className="bidorder-tbl bid_order_OverflowHdn">
            <div className="hdr-row">
              <span>
                <label>Price</label>
              </span>
              <span>
                <label>Amount(ETH)</label>
              </span>
              <span className="mb-hide">
                <label>Total(USDT)</label>
              </span>
            </div>
            <div className="bid-body">
              <div className="progress-container">
                <div className="row-content">
                  <span className="negative">2,503.63</span>
                  <span>0.7992</span>
                  <span className="mb-hide">2,000.909088 </span>
                </div>
                <div
                  className="progress-bar bid-bar"
                  style={{ transform: "translateX(-42.88%)", left: "100%" }}
                ></div>
              </div>
              <div className="progress-container">
                <div className="row-content">
                  <span className="negative">2,503.63</span>
                  <span>0.7992</span>
                  <span className="mb-hide">619.8487154</span>
                </div>
                <div
                  className="progress-bar bid-bar"
                  style={{ transform: "translateX(-67.12%)", left: "100%" }}
                ></div>
              </div>
              <div className="progress-container">
                <div className="row-content">
                  <span className="negative">2,503.63</span>
                  <span>0.24758</span>
                  <span className="mb-hide">2,000.909088</span>
                </div>
                <div
                  className="progress-bar bid-bar"
                  style={{ transform: "translateX(-42.88%)", left: "100%" }}
                ></div>
              </div>
              <div className="progress-container">
                <div className="row-content">
                  <span className="negative">2,503.63</span>
                  <span>7.47047</span>
                  <span className="mb-hide">619.8487154</span>
                </div>
                <div
                  className="progress-bar bid-bar"
                  style={{ transform: "translateX(-42.88%)", left: "100%" }}
                ></div>
              </div>
              <div className="progress-container">
                <div className="row-content">
                  <span className="negative">2,503.63</span>
                  <span>3.4115</span>
                  <span className="mb-hide">2,000.909088</span>
                </div>
                <div
                  className="progress-bar bid-bar"
                  style={{ transform: "translateX(-74.88%)", left: "100%" }}
                ></div>
              </div>

              <div className="progress-container">
                <div className="row-content">
                  <span className="negative">2,503.63</span>
                  <span>5.00</span>
                  <span className="mb-hide">619.8487154 </span>
                </div>
                <div
                  className="progress-bar bid-bar"
                  style={{ transform: "translateX(-42.88%)", left: "100%" }}
                ></div>
              </div>
            </div>
          </div>

          <div className="bidorder-tbl bid_order_OverflowHdn">
            <div className="order-value-table">
              <span className="positive">2502.96</span>
              <img src={arrow} />
              <span> $2502.96</span>
            </div>
            <div className="bid-body">
              <div className="progress-container">
                <div className="row-content">
                  <span className="positive">2,503.63</span>
                  <span>0.7992</span>
                  <span className="mb-hide">2,000.909088 </span>
                </div>
                <div
                  className="progress-bar ask-bar"
                  style={{ transform: "translateX(-42.88%)", left: "100%" }}
                ></div>
              </div>
              <div className="progress-container">
                <div className="row-content">
                  <span className="positive">2,503.63</span>
                  <span>0.7992</span>
                  <span className="mb-hide">619.8487154</span>
                </div>
                <div
                  className="progress-bar ask-bar"
                  style={{ transform: "translateX(-67.12%)", left: "100%" }}
                ></div>
              </div>
              <div className="progress-container">
                <div className="row-content">
                  <span className="positive">2,503.63</span>
                  <span>0.24758</span>
                  <span className="mb-hide">2,000.909088</span>
                </div>
                <div
                  className="progress-bar ask-bar"
                  style={{ transform: "translateX(-42.88%)", left: "100%" }}
                ></div>
              </div>
              <div className="progress-container">
                <div className="row-content">
                  <span className="positive">2,503.63</span>
                  <span>7.47047</span>
                  <span className="mb-hide">619.8487154</span>
                </div>
                <div
                  className="progress-bar ask-bar"
                  style={{ transform: "translateX(-42.88%)", left: "100%" }}
                ></div>
              </div>
              <div className="progress-container">
                <div className="row-content">
                  <span className="positive">2,503.63</span>
                  <span>3.4115</span>
                  <span className="mb-hide">2,000.909088</span>
                </div>
                <div
                  className="progress-bar ask-bar"
                  style={{ transform: "translateX(-74.88%)", left: "100%" }}
                ></div>
              </div>

              <div className="progress-container">
                <div className="row-content">
                  <span className="positive">2,503.63</span>
                  <span>5.00</span>
                  <span className="mb-hide">619.8487154 </span>
                </div>
                <div
                  className="progress-bar ask-bar"
                  style={{ transform: "translateX(-42.88%)", left: "100%" }}
                ></div>
              </div>
              <div className="progress-container">
                <div className="row-content">
                  <span className="positive">2,503.63</span>
                  <span>7.47047</span>
                  <span className="mb-hide">619.8487154</span>
                </div>
                <div
                  className="progress-bar ask-bar"
                  style={{ transform: "translateX(-42.88%)", left: "100%" }}
                ></div>
              </div>
            </div>
          </div>
        </div>
      </Tab>
      <Tab eventKey="openhistory" title="">
        <div className="table-responsive  buysell-table">
          <div className="bidorder-tbl bid_order_OverflowHdn">
            <div className="hdr-row">
              <span>
                <label>Price</label>
              </span>
              <span>
                <label>Amount(ETH)</label>
              </span>
              <span className="mb-hide">
                <label>Total(USDT)</label>
              </span>
            </div>
            <div className="bid-body">
              <div className="progress-container">
                <div className="row-content">
                  <span className="positive">2,503.63</span>
                  <span>0.7992</span>
                  <span className="mb-hide">2,000.909088 </span>
                </div>
                <div
                  className="progress-bar ask-bar"
                  style={{ transform: "translateX(-42.88%)", left: "100%" }}
                ></div>
              </div>
              <div className="progress-container">
                <div className="row-content">
                  <span className="positive">2,503.63</span>
                  <span>0.7992</span>
                  <span className="mb-hide">619.8487154</span>
                </div>
                <div
                  className="progress-bar ask-bar"
                  style={{ transform: "translateX(-67.12%)", left: "100%" }}
                ></div>
              </div>
              <div className="progress-container">
                <div className="row-content">
                  <span className="positive">2,503.63</span>
                  <span>0.24758</span>
                  <span className="mb-hide">2,000.909088</span>
                </div>
                <div
                  className="progress-bar ask-bar"
                  style={{ transform: "translateX(-42.88%)", left: "100%" }}
                ></div>
              </div>
              <div className="progress-container">
                <div className="row-content">
                  <span className="positive">2,503.63</span>
                  <span>7.47047</span>
                  <span className="mb-hide">619.8487154</span>
                </div>
                <div
                  className="progress-bar ask-bar"
                  style={{ transform: "translateX(-42.88%)", left: "100%" }}
                ></div>
              </div>
              <div className="progress-container">
                <div className="row-content">
                  <span className="positive">2,503.63</span>
                  <span>3.4115</span>
                  <span className="mb-hide">2,000.909088</span>
                </div>
                <div
                  className="progress-bar ask-bar"
                  style={{ transform: "translateX(-74.88%)", left: "100%" }}
                ></div>
              </div>

              <div className="progress-container">
                <div className="row-content">
                  <span className="positive">2,503.63</span>
                  <span>5.00</span>
                  <span className="mb-hide">619.8487154 </span>
                </div>
                <div
                  className="progress-bar ask-bar"
                  style={{ transform: "translateX(-42.88%)", left: "100%" }}
                ></div>
              </div>
            </div>
          </div>
        </div>
      </Tab>
      <Tab eventKey="tradehistory" title="">
        <div className="table-responsive  buysell-table">
          <div className="bidorder-tbl bid_order_OverflowHdn">
            <div className="hdr-row">
              <span>
                <label>Price</label>
              </span>
              <span>
                <label>Amount(ETH)</label>
              </span>
              <span className="mb-hide">
                <label>Total(USDT)</label>
              </span>
            </div>
            <div className="bid-body">
              <div className="progress-container">
                <div className="row-content">
                  <span className="negative">2,503.63</span>
                  <span>0.7992</span>
                  <span className="mb-hide">2,000.909088 </span>
                </div>
                <div
                  className="progress-bar bid-bar"
                  style={{ transform: "translateX(-42.88%)", left: "100%" }}
                ></div>
              </div>
              <div className="progress-container">
                <div className="row-content">
                  <span className="negative">2,503.63</span>
                  <span>0.7992</span>
                  <span className="mb-hide">619.8487154</span>
                </div>
                <div
                  className="progress-bar bid-bar"
                  style={{ transform: "translateX(-67.12%)", left: "100%" }}
                ></div>
              </div>
              <div className="progress-container">
                <div className="row-content">
                  <span className="negative">2,503.63</span>
                  <span>0.24758</span>
                  <span className="mb-hide">2,000.909088</span>
                </div>
                <div
                  className="progress-bar bid-bar"
                  style={{ transform: "translateX(-42.88%)", left: "100%" }}
                ></div>
              </div>
              <div className="progress-container">
                <div className="row-content">
                  <span className="negative">2,503.63</span>
                  <span>7.47047</span>
                  <span className="mb-hide">619.8487154</span>
                </div>
                <div
                  className="progress-bar bid-bar"
                  style={{ transform: "translateX(-42.88%)", left: "100%" }}
                ></div>
              </div>
              <div className="progress-container">
                <div className="row-content">
                  <span className="negative">2,503.63</span>
                  <span>3.4115</span>
                  <span className="mb-hide">2,000.909088</span>
                </div>
                <div
                  className="progress-bar bid-bar"
                  style={{ transform: "translateX(-74.88%)", left: "100%" }}
                ></div>
              </div>

              <div className="progress-container">
                <div className="row-content">
                  <span className="negative">2,503.63</span>
                  <span>5.00</span>
                  <span className="mb-hide">619.8487154 </span>
                </div>
                <div
                  className="progress-bar bid-bar"
                  style={{ transform: "translateX(-42.88%)", left: "100%" }}
                ></div>
              </div>
            </div>
          </div>
        </div>
      </Tab>
    </Tabs>
  );
}

export default Order;

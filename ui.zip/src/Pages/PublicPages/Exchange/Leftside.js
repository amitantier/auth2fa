import React, { useEffect, useState } from 'react'
import { Tabs, Tab, Form, Table } from 'react-bootstrap';
import ChangeVolumeTab from '../../../Components/LeftSideTab/ChangeVolumeTab';

function Leftside(props) {
  const [pairsTemp, setPairsTemp] = useState(props.pairList);
  const [dataSourceUSDT, setDataSourceUSDT] = useState([]);

  const [marketTab, setMarketTab] = useState(localStorage.getItem('marketTab'));

  useEffect(async () => {
    setDataSourceUSDT([]);
    let pairRawArray = []
    for (let element of props.pairList) {
      let pairArray = element['pair_key'].split('_')
      if (pairArray[0] == 'usdt') {
        pairRawArray.push(element)
      }
    }

    //order pair list by name
    let pairArray = pairRawArray.map(function (data, idx) {
      return { idx: idx, data: data }
    })

    pairArray.sort(function (a, b) {
      if (a.data.pairs.split('_')[1] < b.data.pairs.split('_')[1]) return -1;
      if (a.data.pairs.split('_')[1] > b.data.pairs.split('_')[1]) return 1;
      return a.idx - b.idx
    });

    let datasSourceUSDT = await pairArray.map(function (val) {
      return val.data
    });
    console.log("datasSourceUSDT", datasSourceUSDT)
    setDataSourceUSDT(datasSourceUSDT)




  }, [props.pairList]);

  return (
    <div>
      <Tabs defaultActiveKey="home" id="uncontrolled-tab-example" className="curr-tab left-tab">
        <Tab eventKey="star" title="" className="star-tab">

        </Tab>
        <Tab eventKey="home" title="USDT">
          <div className="inside_tab">
            <div className="search">
              <Form.Control type="text" placeholder="Search" />
              <i className="fa fa-search serch-icon"></i>
            </div>
            <ChangeVolumeTab></ChangeVolumeTab>
          </div>
          <div className="table-responsive change_table">
            <Table>
              <thead>
                <tr>
                  <th>Pair</th>
                  <th>Last Price</th>
                  <th>24h Change</th>
                </tr>
              </thead>
              {marketTab == "btc" && (
                <tbody>
                  <tr>
                    <td> <i className="fa fa-star-o"></i> BTC/USDT</td>
                    <td>55,444,05</td>
                    <td className="green-text">+1,129.22 </td>
                  </tr>
                  <tr>
                    <td> <i className="fa fa-star-o"></i> BTC/USDT</td>
                    <td>55,444,05</td>
                    <td className="green-text">+1,129.22 </td>
                  </tr>
                  <tr>
                    <td> <i className="fa fa-star-o"></i> BTC/USDT</td>
                    <td>55,444,05</td>
                    <td className="green-text">+1,129.22 </td>
                  </tr>
                  <tr>
                    <td> <i className="fa fa-star-o"></i> BTC/USDT</td>
                    <td>55,444,05</td>
                    <td className="green-text">+1,129.22 </td>
                  </tr>

                  <tr>
                    <td> <i className="fa fa-star-o"></i> BTC/USDT</td>
                    <td>55,444,05</td>
                    <td className="green-text">+1,129.22 </td>
                  </tr>
                  <tr>
                    <td> <i className="fa fa-star-o"></i> BTC/USDT</td>
                    <td>55,444,05</td>
                    <td className="green-text">+1,129.22 </td>
                  </tr>

                  <tr>
                    <td> <i className="fa fa-star-o"></i> BTC/USDT</td>
                    <td>55,444,05</td>
                    <td className="green-text">+1,129.22 </td>
                  </tr>
                  <tr>
                    <td> <i className="fa fa-star-o"></i> BTC/USDT</td>
                    <td>55,444,05</td>
                    <td className="green-text">+1,129.22 </td>
                  </tr>
                </tbody>
              )}
            </Table>
          </div>
        </Tab>
        <Tab eventKey="profile" title="BTC">

        </Tab>
        <Tab eventKey="contact" title="ALL">

        </Tab>
      </Tabs>

    </div>
  )
}

export default Leftside

import React from 'react'
import { Table } from 'react-bootstrap';

function Trades() {
    return (
        <div>
            <h5 className="table-heading">Trades</h5>
            <div className="table-responsive change_table">
                <Table>
                    <thead>
                        <tr>
                            <th>Price</th>
                            <th>Amount(ETH)</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td className="green-text"> 2,503.63</td>
                            <td>0.7992</td>
                            <td>10:10:15 </td>
                        </tr>
                        <tr>
                            <td className="green-text"> 2,503.63</td>
                            <td>0.24758</td>
                            <td>10:10:15 </td>
                        </tr>
                        <tr>
                            <td className="green-text"> 2,503.63</td>
                            <td>7.47047</td>
                            <td>10:10:15 </td>
                        </tr>
                        <tr>
                            <td className="negative"> 2,503.63</td>
                            <td>3.4115</td>
                            <td>10:10:15 </td>
                        </tr>
                        <tr>
                            <td className="negative"> 2,503.63</td>
                            <td>5.00</td>
                            <td>10:10:15 </td>
                        </tr>
                        <tr>
                            <td className="negative"> 2,503.63</td>
                            <td>3.4115</td>
                            <td>10:10:15 </td>
                        </tr>
                        <tr>
                            <td className="green-text"> 2,503.63</td>
                            <td>0.7992</td>
                            <td>10:10:15 </td>
                        </tr>
                        <tr>
                            <td className="green-text"> 2,503.63</td>
                            <td>0.24758</td>
                            <td>10:10:15 </td>
                        </tr>
                        <tr>
                            <td className="green-text"> 2,503.63</td>
                            <td>7.47047</td>
                            <td>10:10:15 </td>
                        </tr>
                        <tr>
                            <td className="negative"> 2,503.63</td>
                            <td>3.4115</td>
                            <td>10:10:15 </td>
                        </tr>
                        <tr>
                            <td className="negative"> 2,503.63</td>
                            <td>5.00</td>
                            <td>10:10:15 </td>
                        </tr>
                        <tr>
                            <td className="negative"> 2,503.63</td>
                            <td>3.4115</td>
                            <td>10:10:15 </td>
                        </tr>
                        <tr>
                            <td className="green-text"> 2,503.63</td>
                            <td>0.7992</td>
                            <td>10:10:15 </td>
                        </tr>
                        <tr>
                            <td className="green-text"> 2,503.63</td>
                            <td>0.24758</td>
                            <td>10:10:15 </td>
                        </tr>
                        <tr>
                            <td className="green-text"> 2,503.63</td>
                            <td>7.47047</td>
                            <td>10:10:15 </td>
                        </tr>
                        <tr>
                            <td className="negative"> 2,503.63</td>
                            <td>3.4115</td>
                            <td>10:10:15 </td>
                        </tr>
                        <tr>
                            <td className="negative"> 2,503.63</td>
                            <td>5.00</td>
                            <td>10:10:15 </td>
                        </tr>
                        <tr>
                            <td className="negative"> 2,503.63</td>
                            <td>3.4115</td>
                            <td>10:10:15 </td>
                        </tr>
                    </tbody>
                </Table>
            </div>
        </div>
    )
}

export default Trades

import React from "react";
import { Form, Table, Button } from "react-bootstrap";
import usdticon from "../../../assets/images/usdt-icon.png";
import ethicon from "../../../assets/images/eth-icon.png";
function Assets() {
  return (
    <div className="asset-col">
      <div className="asset-box">
        <h5 className="table-heading">Assets</h5>
        <div key={"custom-radio-buy"} className=" token_check assets-check">
          <Form.Check
            custom
            type={"checkbox"}
            id={"custom-tokens"}
            name="type"
            label={"Show All Tokens"}
          />
        </div>
      </div>
      <div className="table-responsive change_table mt-0">
        <Table>
          <thead>
            <tr>
              <th>Token</th>
              <th className="text-right">Balance</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                {" "}
                <img src={usdticon} /> USDT
              </td>
              <td className="text-right">0.00</td>
            </tr>
            <tr>
              <td>
                {" "}
                <img src={ethicon} /> ETH
              </td>
              <td className="text-right">0.00</td>
            </tr>
          </tbody>
        </Table>
      </div>
      <Button className="buy-btn deposit-btn">Deposit</Button>
    </div>
  );
}

export default Assets;

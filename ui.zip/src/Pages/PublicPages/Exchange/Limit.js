import React from "react";
import { useFormik } from "formik";
import { InputGroup, FormControl, Badge, Button, Form } from "react-bootstrap";
import usdticon from "../../../assets/images/usdt-icon.png";
import ethicon from "../../../assets/images/eth-icon.png";
import { AUTH_TOKEN_KEY } from "../../../constant";
import { getToken } from "../../../Helpers/storageHelper";

function Limit(props) {
  const formik = useFormik({
    enableReinitialize: true,
    initialValues: {
      price: "",
      units: "",
      total: "",
      slprice: "",
    },

    onSubmit: (values) => {
      values["tradeType"] = "LIMIT";
      delete values["total"];
      props.setBuySellData(values);
      formik.resetForm();
    },
  });
  return (
    <div className="limit-form">
      <Form onSubmit={formik.handleSubmit}>
        <label>Price</label>

        <InputGroup className="mb-1">
          <InputGroup.Prepend>
            <InputGroup.Text>
              <img src={usdticon} /> {props.base}
            </InputGroup.Text>
          </InputGroup.Prepend>
          <FormControl
            placeholder="Price"
            aria-label="5496.63"
            aria-describedby="basic-addon2"
            className="price-box"
            id="price"
            onChange={formik.handleChange}
            value={formik.values.price}
          />
          {/* <InputGroup.Append>
          <InputGroup.Text className="price">$2,496.63</InputGroup.Text>
        </InputGroup.Append> */}
        </InputGroup>
        <label>Amount</label>
        <InputGroup className="mb-1">
          <InputGroup.Prepend>
            <InputGroup.Text>
              <img src={ethicon} /> {props.other}
            </InputGroup.Text>
          </InputGroup.Prepend>
          <FormControl
            placeholder="Amount"
            aria-label="Enter Amount"
            aria-describedby="basic-addon2"
            id="units"
            onChange={formik.handleChange}
            value={formik.values.units}
          />
        </InputGroup>

        <label>Total</label>

        <InputGroup className="mb-1">
          <InputGroup.Prepend>
            <InputGroup.Text>
              <img src={usdticon} /> {props.base}
            </InputGroup.Text>
          </InputGroup.Prepend>
          <FormControl
            placeholder="Total"
            aria-label="Enter Amount"
            aria-describedby="basic-addon2"
            id="slprice"
            onChange={formik.handleChange}
            value={formik.values.total}
          />
        </InputGroup>
        <div className="range-box">
          <Badge variant="secondary">25%</Badge>
          <Badge variant="secondary">50%</Badge>
          <Badge variant="secondary">75%</Badge>
          <Badge variant="secondary">100%</Badge>
        </div>
        {getToken(AUTH_TOKEN_KEY) === null ? (
          <Button className="buy-btn" disabled>
            Login or Register now to trade
          </Button>
        ) : (
          <Button className="buy-btn" type="submit">
            Buy {props.other}
          </Button>
        )}
      </Form>
    </div>
  );
}

export default Limit;

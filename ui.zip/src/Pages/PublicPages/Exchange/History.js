import React from 'react'
import { Tabs, Tab, Table, Form } from 'react-bootstrap';

function Order() {
    return (
        <div className="order-col">

            <div key={'custom-radio-buy'} className="mb-3 token_check">
                <Form.Check
                    custom
                    type={'checkbox'}
                    id={'custom-checkbox'}

                    name="type"
                    label={'Show All Tokens'}
                />
            </div>
            <Tabs defaultActiveKey="openorder" id="uncontrolled-tab-example " className="order-tab">
                <Tab eventKey="openorder" title="Open Orders(0)">
                    <div className="table-responsive change_table order-table">
                        <Table>
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Pair</th>
                                    <th>Type</th>
                                    <th>Side</th>
                                    <th>Price</th>
                                    <th>Amount</th>
                                    <th>Filled</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colSpan="9" className="text-center no-order"> No Open Orders found</td>

                                </tr>

                            </tbody>
                        </Table>
                    </div>
                </Tab>
                <Tab eventKey="openhistory" title="Open History">
                    <div className="table-responsive change_table order-table">
                        <Table>
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Pair</th>
                                    <th>Type</th>
                                    <th>Side</th>
                                    <th>Price</th>
                                    <th>Amount</th>
                                    <th>Filled</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colSpan="9" className="text-center no-order"> No Open Orders found</td>

                                </tr>

                            </tbody>
                        </Table>
                    </div>
                </Tab>
                <Tab eventKey="tradehistory" title="Trade History" >
                    <div className="table-responsive change_table order-table">
                        <Table>
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Pair</th>
                                    <th>Type</th>
                                    <th>Side</th>
                                    <th>Price</th>
                                    <th>Amount</th>
                                    <th>Filled</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colSpan="9" className="text-center no-order"> No Open Orders found</td>

                                </tr>

                            </tbody>
                        </Table>
                    </div>
                </Tab>
                <Tab eventKey="funds" title="Funds" >
                    <div className="table-responsive change_table order-table">
                        <Table>
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Pair</th>
                                    <th>Type</th>
                                    <th>Side</th>
                                    <th>Price</th>
                                    <th>Amount</th>
                                    <th>Filled</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colSpan="9" className="text-center no-order"> No Open Orders found</td>

                                </tr>

                            </tbody>
                        </Table>
                    </div>
                </Tab>

            </Tabs>
        </div>
    )
}

export default Order

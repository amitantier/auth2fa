import React from "react";
import { useFormik } from "formik";
import { InputGroup, FormControl, Form, Button } from "react-bootstrap";
import usdticon from "../../../assets/images/usdt-icon.png";
import { AUTH_TOKEN_KEY } from "../../../constant";
import { getToken } from "../../../Helpers/storageHelper";

function Market(props) {
  const formik = useFormik({
    enableReinitialize: true,
    initialValues: {
      units: "",
    },

    onSubmit: (values) => {
      values["tradeType"] = "MARKET";
      props.setBuySellData(values);
      formik.resetForm();
    },
  });
  return (
    <div className="limit-form">
      <Form onSubmit={formik.handleSubmit}>
        <label>Amount</label>

        <InputGroup className="mb-1">
          <InputGroup.Prepend>
            <InputGroup.Text>
              <img src={usdticon} /> {props.other}
            </InputGroup.Text>
          </InputGroup.Prepend>
          <FormControl
            aria-describedby="basic-addon2"
            className="price-box"
            id="units"
            onChange={formik.handleChange}
            value={formik.values.units}
          />
        </InputGroup>

        {getToken(AUTH_TOKEN_KEY) === null ? (
          <Button className="buy-btn" disabled>
            Login or Register now to trade
          </Button>
        ) : (
          <Button className="buy-btn" type="submit">
            Buy {props.other}
          </Button>
        )}
      </Form>
    </div>
  );
}

export default Market;

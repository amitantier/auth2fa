import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import CustomScroll from "react-custom-scroll";
import { Tabs, Tab, Form } from "react-bootstrap";
import Limit from "./Limit";
import Market from "./Market";
import { placeOrder } from "../../../redux/actions/ExchangeActions";

const BuySell = (props) => {
  const dispatch = useDispatch();

  const [tab, setTab] = useState("BUY");
  const [buySellData, setBuySellData] = useState({});

  useEffect(() => {
    if (Object.keys(buySellData).length > 0) {
      placingBuySellOrder();
    }
  }, [buySellData]);

  const placingBuySellOrder = () => {
    let values = buySellData;
    values["orderType"] = tab;
    values["pairKey"] = props.pair;
    dispatch(placeOrder(values));
  };

  // Buy Sell Inputs html ///
  const buySellInputs = () => {
    return (
      <Tabs
        defaultActiveKey="limit"
        id="uncontrolled-tab-example"
        className="limit-market-tab"
      >
        <Tab eventKey="limit" title="Limit">
          <Limit
            base={props.base}
            other={props.other}
            setBuySellData={setBuySellData}
          ></Limit>
        </Tab>
        <Tab eventKey="market" title="Market">
          <Market other={props.other} setBuySellData={setBuySellData}></Market>
        </Tab>
      </Tabs>
    );
  };

  return (
    <div className="order-col">
      <Tabs
        defaultActiveKey="BUY"
        id="uncontrolled-tab-example "
        className="order-tab bg-none buy-sell-col"
        onSelect={(e) => setTab(e)}
      >
        <Tab eventKey="BUY" title="Buy" className="buy-tab">
          <a className="fees-text" href="#">
            Fees
          </a>
          {buySellInputs()}
        </Tab>

        <Tab eventKey="SELL" title="Sell" className="buy-tab">
          <a className="fees-text" href="#">
            Fees
          </a>
          {buySellInputs()}
        </Tab>
      </Tabs>
    </div>
  );
};

export default BuySell;

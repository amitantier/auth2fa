import React from "react";
import { Form } from "react-bootstrap";
import ButtonPrimary from "../../../components/common/ButtonPrimary/ButtonPrimary";
import CommonCont from "../../../components/CommonCont/CommonCont";
import CustomInput from "../../../components/common/CustomInput/CustomInput";
import "./SecurityVerification.scss";

function SecurityVerification() {
  return (
    <>
      <CommonCont
        heading="Security Verification"
        subheading="To open your account, please complete the following verification."
        className="securityCont_Style"
      >
        <Form className="commonForm_style">
          <CustomInput placeholder="E-mail verification code">
            <a className="showPassword">Send code</a>
            <p>Enter the 6 digit code received by your mail</p>
          </CustomInput>

          <CustomInput placeholder="Google verification code">
            <a className="showPassword">Paste</a>
            <p>Enter the 6 digit code from Google Authenticator.</p>
          </CustomInput>
          <ButtonPrimary buttontext="Submit" />
        </Form>
      </CommonCont>
    </>
  );
}

export default SecurityVerification;

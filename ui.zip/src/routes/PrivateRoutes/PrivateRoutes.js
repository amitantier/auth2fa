import React, { useEffect } from "react";
import { Route, Switch } from "react-router-dom";
import { withRouter } from "react-router";
import { rootName } from "../../constant";
import Wallet from "../../Pages/PrivatePages/Wallet/Wallet";
import NavbarAfterlogin from "../../components/common/NavbarAfterlogin/NavbarAfterlogin";
import Sidebar from "../../components/common/sidebar/Sidebar";
import { Container } from "react-bootstrap";
import DepositWallet from "../../Pages/PrivatePages/Wallet/DepositWallet";
import Setting from "../../Pages/PrivatePages/Setting/Setting";
import KycnotSubmit from "../../Pages/PrivatePages/Kyc/KycnotSubmit";
import KycProcess from "../../Pages/PrivatePages/Kyc";

import KycDetail from "../../Pages/PrivatePages/Kyc/KycDetail";
import KycSubmit from "../../Pages/PrivatePages/Kyc/KycSubmit";
import Swap from "../../Pages/PrivatePages/Swap/Swap";
import Profile from "../../Pages/PrivatePages/Profile/Profile";
import PasswordReset from "../../Pages/PrivatePages/Profile/PasswordReset";
import Authentication from "../../Pages/PrivatePages/Authentication/Authentication";
import EnableAuthentication from "../../Pages/PrivatePages/Authentication/EnableAuthentication/EnableAuthentication";
import AuthCode from "../../Pages/PrivatePages/Authentication/EnableAuthentication/AuthCode";
import DisableAuthentication from "../../Pages/PrivatePages/Authentication/DisableAuthentication/DisableAuthentication";
import DeviceManagement from "../../Pages/PrivatePages/DeviceManagement/DeviceManagement";
import KycdocUpload from "../../Pages/PrivatePages/Kyc/KycdocUpload";
import Footer from '../../components/common/Footer/Footer'

const PrivateRoutes = () => {
  useEffect(() => {
    const authPages = document.querySelector("body");
    document.body.classList.add("auth");
    return () => {
      authPages.classList.remove("auth");
    };
  }, []);
  return (
    <>
      <div className="privateAreaContent">
        <NavbarAfterlogin />
        <Container fluid className="afterAuth_cont">
          <Sidebar />
          <Container className="content_Cont">
            <Switch>
              <Route
                path={`${rootName}/auth/wallet`}
                component={Wallet}
                exact={true}
              />
              <Route
                path={`${rootName}/auth/deposit`}
                component={DepositWallet}
                exact={true}
              />
              <Route
                path={`${rootName}/auth/setting`}
                component={Setting}
                exact={true}
              />
              <Route
                path={`${rootName}/auth/kycprocess`}
                component={KycProcess}
                exact={true}
              />
              <Route
                path={`${rootName}/auth/kycnotsubmit`}
                component={KycnotSubmit}
                exact={true}
              />
              <Route
                path={`${rootName}/auth/kycdetail`}
                component={KycDetail}
                exact={true}
              />
              <Route
                path={`${rootName}/auth/kyc-upload`}
                component={KycdocUpload}
                exact={true}
              />
              <Route
                path={`${rootName}/auth/kycsubmited`}
                component={KycSubmit}
                exact={true}
              />
              <Route
                path={`${rootName}/auth/swap`}
                component={Swap}
                exact={true}
              />
              <Route
                path={`${rootName}/auth/profile`}
                component={Profile}
                exact={true}
              />
              <Route
                path={`${rootName}/auth/password-reset`}
                component={PasswordReset}
                exact={true}
              />
              <Route
                path={`${rootName}/auth/authentication`}
                component={Authentication}
                exact={true}
              />
              <Route
                path={`${rootName}/auth/enable-authentication`}
                component={EnableAuthentication}
                exact={true}
              />
              <Route
                path={`${rootName}/auth/authentication-code`}
                component={AuthCode}
                exact={true}
              />
              <Route
                path={`${rootName}/auth/disable-authentication`}
                component={DisableAuthentication}
                exact={true}
              />
              <Route
                path={`${rootName}/auth/device-management`}
                component={DeviceManagement}
                exact={true}
              />
            </Switch>
          </Container>
        </Container>
      </div>
      <Footer/>
    </>
  );
};

export default withRouter(PrivateRoutes);

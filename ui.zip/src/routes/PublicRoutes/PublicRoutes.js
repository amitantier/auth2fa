import React from "react";
import { Route, Switch } from "react-router-dom";
import { Container, Row } from "react-bootstrap";
import { withRouter } from "react-router";
import { rootName } from "../../constant";
import Login from "../../Pages/PublicPages/Login/Login";
import SecurityVerification from "../../Pages/PublicPages/SecurityVerification/SecurityVerification";
import "../../Pages/PublicPages/Login/Login.scss";
import NavbarTop from "../../components/common/navbarTop/NavbarTop";
import Footer from "../../components/common/Footer/Footer";
import SignUp from "../../Pages/PublicPages/SignUp/SignUp";
import VerifyMessage from '../../Pages/PublicPages/VerifyMessage';
import VerifyDevice from '../../Pages/PublicPages/VerifyDevice';
import GoogleAuth from "../../Pages/PublicPages/GoogleAuth/GoogleAuth";
import AuthenticationCode from "../../Pages/PublicPages/AuthenticationCode/AuthenticationCode";

const PublicRoutes = () => {
  return (
    <>
      <div className="publicAreaContent">
        <NavbarTop />
        <Container fluid className="containerFull_width">
          <Container>
            <Row className="commonRow_style">
              <Switch>
              <Route path={'/'} component={Login} exact={true} />
                <Route
                  path={`${rootName}/login`}
                  component={Login}
                  exact={true}
                ></Route>
                <Route
                  path={`${rootName}/signup`}
                  component={SignUp}
                  exact={true}
                ></Route>
                 <Route
                    path={`/verify-device/:hashCode`}
                    component={VerifyDevice}
                    exact={true}
                  />
                  <Route
                    path={`/verify-email`}
                    component={VerifyMessage}
                    exact={true}
                  />
                <Route
                  path={`${rootName}/google-authentication`}
                  component={GoogleAuth}
                  exact={true}
                ></Route>
                <Route
                  path={`${rootName}/authentication-code`}
                  component={AuthenticationCode}
                  exact={true}
                ></Route>
                <Route
                  path={`${rootName}/security-verification`}
                  component={SecurityVerification}
                  exact={true}
                ></Route>
              </Switch>
            </Row>
          </Container>
        </Container>
      </div>
      <Footer />
    </>
  );
};

export default withRouter(PublicRoutes);

import React, { useEffect } from "react";
import { Route, Redirect } from "react-router-dom";
import { connect } from "react-redux";
import { getToken } from "../../Helpers/storageHelper";
import { AUTH_TOKEN_KEY } from "../../constant";
import {check_ip_token,getUserProfile} from "../../redux/actions/SecurityActions"
import {removeToken} from '../../Helpers/storageHelper';
import { useHistory } from "react-router-dom";

const AuthGuard = ({ component: Component, ...rest },props) => {
  let history = useHistory();
  const { isUserFirstTimeLogin,check_ip_token,getUserProfile } = rest;
  var isAuthenticated = false;
  var tokens = getToken(AUTH_TOKEN_KEY);

  if (tokens !== null && tokens !== undefined) {


    if (isUserFirstTimeLogin == 0) {

      isAuthenticated = false;

    } else {
      // isUserFirstTimeLogin (1,2);
      isAuthenticated = true;
    }

  }

  useEffect(()=>{
    let emailData;
    // props.check_ip_token({ "issuer":""}).then((res)=>{
      getUserProfile().then((res)=>{
        emailData = res[0]?.email
      })
   //  console.log('getUserInfo',getUserInfo);
      // async function fetchMyAPI() {
      //   await getUserInfo().then((res)=>{

      //   })
      //   // response = await response.json()
      //   // dataSet(response)
      // }
  
      //fetchMyAPI()

    check_ip_token({token:tokens,email:emailData}).then((res)=>{
      removeToken(AUTH_TOKEN_KEY, '', 1);
     history.push(`/signIn`);
    })
    // props.get2FaImage({ "issuer":""}).then((res)=>{
    //   console.log('check_ip_token',rest)
 },[])

 
  return (
    <Route
      {...rest}
      render={props =>
        isAuthenticated ? (
          <Component {...props} />
        ) : (
          <Redirect
            to={{
              pathname: tokens == null || tokens == undefined ? '/signIn' : isUserFirstTimeLogin == 0 ? `/secure/authenticator` : isUserFirstTimeLogin == 1 ? `/auth/dashboard` : `/signIn`,
              state: {
                from: props.location
              }
            }}
          />
        )
      }
    />
  );
};

const mapStateToProps = state => {
  console.log("AUTH STATE", state)
  return {
    isUserFirstTimeLogin: state.persist.isUserFirstTimeLogin

  };
};

const mapDisptachToProps = dispatch => {
  return {
    getUserProfile:()=>dispatch(getUserProfile()),
    check_ip_token: (data) => dispatch(check_ip_token(data)),
  }
}

export default connect(
  mapStateToProps,
  mapDisptachToProps
)(AuthGuard);

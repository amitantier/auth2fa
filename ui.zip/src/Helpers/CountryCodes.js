const countryCodes = [
  {
    text: 'Afghanistan (+93)',
    code: '+93',
    value: 'AF',
    latitude: 33,
    longitude: 65
  },
  {
    text: 'Albania (+355)',
    code: '+355',
    value: 'AL',
    latitude: 41,
    longitude: 20
  },
  {
    text: 'Algeria (+213)',
    code: '+213',
    value: 'DZ',
    latitude: 28,
    longitude: 3
  },
  {
    text: 'AmericanSamoa (+1 684)',
    code: '+1 684',
    value: 'AS',
    latitude: -14.3333,
    longitude: -170
  },
  {
    text: 'Andorra (+376)',
    code: '+376',
    value: 'AD',
    latitude: 42.5,
    longitude: 1.6
  },
  {
    text: 'Angola (+244)',
    code: '+244',
    value: 'AO',
    latitude: -12.5,
    longitude: 18.5
  },
  {
    text: 'Anguilla (+1 264)',
    code: '+1 264',
    value: 'AI',
    latitude: 18.25,
    longitude: -63.1667
  },
  {
    text: 'Antarctica (+672)',
    code: '+672',
    value: 'AQ',
    latitude: -90,
    longitude: '0'
  },
  {
    text: 'Antigua and Barbuda (+1268)',
    code: '+1268',
    value: 'AG',
    latitude: 17.05,
    longitude: -61.8
  },
  {
    text: 'Argentina (+54)',
    code: '+54',
    value: 'AR',
    latitude: -34,
    longitude: -64
  },
  {
    text: 'Armenia (+374)',
    code: '+374',
    value: 'AM',
    latitude: 40,
    longitude: 45
  },
  {
    text: 'Aruba (+297)',
    code: '+297',
    value: 'AW',
    latitude: 12.5,
    longitude: -69.9667
  },
  {
    text: 'Australia (+61)',
    code: '+61',
    value: 'AU',
    latitude: -27,
    longitude: 133
  },
  {
    text: 'Austria (+43)',
    code: '+43',
    value: 'AT',
    latitude: 47.3333,
    longitude: 13.3333
  },
  {
    text: 'Azerbaijan (+994)',
    code: '+994',
    value: 'AZ',
    latitude: 40.5,
    longitude: 47.5
  },
  {
    text: 'Bahamas (+1 242)',
    code: '+1 242',
    value: 'BS',
    latitude: 24.25,
    longitude: -76
  },
  {
    text: 'Bahrain (+973)',
    code: '+973',
    value: 'BH',
    latitude: 26,
    longitude: 50.55
  },
  {
    text: 'Bangladesh (+880)',
    code: '+880',
    value: 'BD',
    latitude: 24,
    longitude: 90
  },
  {
    text: 'Barbados (+1 246)',
    code: '+1 246',
    value: 'BB',
    latitude: 13.1667,
    longitude: -59.5333
  },
  {
    text: 'Belarus (+375)',
    code: '+375',
    value: 'BY',
    latitude: 53,
    longitude: 28
  },
  {
    text: 'Belgium (+32)',
    code: '+32',
    value: 'BE',
    latitude: 50.8333,
    longitude: 4
  },
  {
    text: 'Belize (+501)',
    code: '+501',
    value: 'BZ',
    latitude: 17.25,
    longitude: -88.75
  },
  {
    text: 'Benin (+229)',
    code: '+229',
    value: 'BJ',
    latitude: 9.5,
    longitude: 2.25
  },
  {
    text: 'Bermuda (+1 441)',
    code: '+1 441',
    value: 'BM',
    latitude: 32.3333,
    longitude: -64.75
  },
  {
    text: 'Bhutan (+975)',
    code: '+975',
    value: 'BT',
    latitude: 27.5,
    longitude: 90.5
  },
  {
    text: 'Bolivia, Plurinational State of Bolivia (+591)',
    code: '+591',
    value: 'BO',
    latitude: -17,
    longitude: -65
  },
  {
    text: 'Bosnia and Herzegovina (+387)',
    code: '+387',
    value: 'BA',
    latitude: 44,
    longitude: 18
  },
  {
    text: 'Botswana (+267)',
    code: '+267',
    value: 'BW',
    latitude: -22,
    longitude: 24
  },
  {
    text: 'Bouvet Island (+55)',
    code: '+55',
    value: 'BV',
    latitude: -54.4333,
    longitude: 3.4
  },
  {
    text: 'Brazil (+55)',
    code: '+55',
    value: 'BR',
    latitude: -10,
    longitude: -55
  },
  {
    text: 'British Indian Ocean Territory (+246)',
    code: '+246',
    value: 'IO',
    latitude: -6,
    longitude: 71.5
  },
  {
    text: 'Brunei Darussalam (+673)',
    code: '+673',
    value: 'BN',
    latitude: 4.5,
    longitude: 114.6667
  },
  {
    text: 'Bulgaria (+359)',
    code: '+359',
    value: 'BG',
    latitude: 43,
    longitude: 25
  },
  {
    text: 'Burkina Faso (+226)',
    code: '+226',
    value: 'BF',
    latitude: 13,
    longitude: -2
  },
  {
    text: 'Burundi (+257)',
    code: '+257',
    value: 'BI',
    latitude: -3.5,
    longitude: 30
  },
  {
    text: 'Cambodia (+855)',
    code: '+855',
    value: 'KH',
    latitude: 13,
    longitude: 105
  },
  {
    text: 'Cameroon (+237)',
    code: '+237',
    value: 'CM',
    latitude: 6,
    longitude: 12
  },
  {
    text: 'Canada (+1)',
    code: '+1',
    value: 'CA',
    latitude: 60,
    longitude: -95
  },
  {
    text: 'Cape Verde (+238)',
    code: '+238',
    value: 'CV',
    latitude: 16,
    longitude: -24
  },
  {
    text: 'Cayman Islands (+1345)',
    code: '+1345',
    value: 'KY',
    latitude: 19.5,
    longitude: -80.5
  },
  {
    text: 'Central African Republic (+236)',
    code: '+236',
    value: 'CF',
    latitude: 7,
    longitude: 21
  },
  {
    text: 'Chad (+235)',
    code: '+235',
    value: 'TD',
    latitude: 15,
    longitude: 19
  },
  {
    text: 'Chile (+56)',
    code: '+56',
    value: 'CL',
    latitude: -30,
    longitude: -71
  },
  {
    text: 'China (+86)',
    code: '+86',
    value: 'CN',
    latitude: 35,
    longitude: 105
  },
  {
    text: 'Christmas Island (+61)',
    code: '+61',
    value: 'CX',
    latitude: -10.5,
    longitude: 105.6667
  },
  {
    text: 'Cocos (Keeling) Islands (+61)',
    code: '+61',
    value: 'CC',
    latitude: -12.5,
    longitude: 96.8333
  },
  {
    text: 'Colombia (+57)',
    code: '+57',
    value: 'CO',
    latitude: 4,
    longitude: -72
  },
  {
    text: 'Comoros (+269)',
    code: '+269',
    value: 'KM',
    latitude: -12.1667,
    longitude: 44.25
  },
  {
    text: 'Congo (+242)',
    code: '+242',
    value: 'CG',
    latitude: -1,
    longitude: 15
  },
  {
    text: 'Congo, The Democratic Republic of the (+243)',
    code: '+243',
    value: 'CD',
    latitude: '0',
    longitude: 25
  },
  {
    text: 'Cook Islands (+682)',
    code: '+682',
    value: 'CK',
    latitude: -21.2333,
    longitude: -159.7667
  },
  {
    text: 'Costa Rica (+506)',
    code: '+506',
    value: 'CR',
    latitude: 10,
    longitude: -84
  },
  {
    text: "Cote d'Ivoire (+225)",
    value: '+225',
    key: 'CI',
    latitude: 8,
    longitude: -5
  },
  {
    text: 'Croatia (+385)',
    code: '+385',
    value: 'HR',
    latitude: 45.1667,
    longitude: 15.5
  },
  {
    text: 'Cuba (+53)',
    code: '+53',
    value: 'CU',
    latitude: 21.5,
    longitude: -80
  },
  {
    text: 'Cyprus (+357)',
    code: '+357',
    value: 'CY',
    latitude: 35,
    longitude: 33
  },
  {
    text: 'Czech Republic (+420)',
    code: '+420',
    value: 'CZ',
    latitude: 49.75,
    longitude: 15.5
  },
  {
    text: 'Denmark (+45)',
    code: '+45',
    value: 'DK',
    latitude: 56,
    longitude: 10
  },
  {
    text: 'Djibouti (+253)',
    code: '+253',
    value: 'DJ',
    latitude: 11.5,
    longitude: 43
  },
  {
    text: 'Dominica (+1 767)',
    code: '+1 767',
    value: 'DM',
    latitude: 15.4167,
    longitude: -61.3333
  },
  {
    text: 'Dominican Republic (+1 849)',
    code: '+1 849',
    value: 'DO',
    latitude: 19,
    longitude: -70.6667
  },
  {
    text: 'Ecuador (+593)',
    code: '+593',
    value: 'EC',
    latitude: -2,
    longitude: -77.5
  },
  {
    text: 'Egypt (+20)',
    code: '+20',
    value: 'EG',
    latitude: 27,
    longitude: 30
  },
  {
    text: 'El Salvador (+503)',
    code: '+503',
    value: 'SV',
    latitude: 13.8333,
    longitude: -88.9167
  },
  {
    text: 'Equatorial Guinea (+240)',
    code: '+240',
    value: 'GQ',
    latitude: 2,
    longitude: 10
  },
  {
    text: 'Eritrea (+291)',
    code: '+291',
    value: 'ER',
    latitude: 15,
    longitude: 39
  },
  {
    text: 'Estonia (+372)',
    code: '+372',
    value: 'EE',
    latitude: 59,
    longitude: 26
  },
  {
    text: 'Ethiopia (+251)',
    code: '+251',
    value: 'ET',
    latitude: 8,
    longitude: 38
  },
  {
    text: 'Falkland Islands (Malvinas) (+500)',
    code: '+500',
    value: 'FK',
    latitude: -51.75,
    longitude: -59
  },
  {
    text: 'Faroe Islands (+298)',
    code: '+298',
    value: 'FO',
    latitude: 62,
    longitude: -7
  },
  {
    text: 'Fiji (+679)',
    code: '+679',
    value: 'FJ',
    latitude: -18,
    longitude: 175
  },
  {
    text: 'Finland (+358)',
    code: '+358',
    value: 'FI',
    latitude: 64,
    longitude: 26
  },
  {
    text: 'France (+33)',
    code: '+33',
    value: 'FR',
    latitude: 46,
    longitude: 2
  },
  {
    text: 'French Guiana (+594)',
    code: '+594',
    value: 'GF',
    latitude: 4,
    longitude: -53
  },
  {
    text: 'French Polynesia (+689)',
    code: '+689',
    value: 'PF',
    latitude: -15,
    longitude: -140
  },
  {
    text: 'French Southern and Antarctic Lands (+262)',
    code: '+262',
    value: 'TF',
    latitude: -43,
    longitude: 67
  },
  {
    text: 'Gabon (+241)',
    code: '+241',
    value: 'GA',
    latitude: -1,
    longitude: 11.75
  },
  {
    text: 'Gambia (+220)',
    code: '+220',
    value: 'GM',
    latitude: 13.4667,
    longitude: -16.5667
  },
  {
    text: 'Georgia (+995)',
    code: '+995',
    value: 'GE',
    latitude: 42,
    longitude: 43.5
  },
  {
    text: 'Germany (+49)',
    code: '+49',
    value: 'DE',
    latitude: 51,
    longitude: 9
  },
  {
    text: 'Ghana (+233)',
    code: '+233',
    value: 'GH',
    latitude: 8,
    longitude: -2
  },
  {
    text: 'Gibraltar (+350)',
    code: '+350',
    value: 'GI',
    latitude: 36.1833,
    longitude: -5.3667
  },
  {
    text: 'Greece (+30)',
    code: '+30',
    value: 'GR',
    latitude: 39,
    longitude: 22
  },
  {
    text: 'Greenland (+299)',
    code: '+299',
    value: 'GL',
    latitude: 72,
    longitude: -40
  },
  {
    text: 'Grenada (+1 473)',
    code: '+1 473',
    value: 'GD',
    latitude: 12.1167,
    longitude: -61.6667
  },
  {
    text: 'Guadeloupe (+590)',
    code: '+590',
    value: 'GP',
    latitude: 16.25,
    longitude: -61.5833
  },
  {
    text: 'Guam (+1 671)',
    code: '+1 671',
    value: 'GU',
    latitude: 13.4667,
    longitude: 144.7833
  },
  {
    text: 'Guatemala (+502)',
    code: '+502',
    value: 'GT',
    latitude: 15.5,
    longitude: -90.25
  },
  {
    text: 'Guernsey (+44)',
    code: '+44',
    value: 'GG',
    latitude: 49.5,
    longitude: -2.56
  },
  {
    text: 'Guinea (+224)',
    code: '+224',
    value: 'GN',
    latitude: 11,
    longitude: -10
  },
  {
    text: 'Guinea-Bissau (+245)',
    code: '+245',
    value: 'GW',
    latitude: 12,
    longitude: -15
  },
  {
    text: 'Guyana (+592)',
    code: '+592',
    value: 'GY',
    latitude: 5,
    longitude: -59
  },
  {
    text: 'Haiti (+509)',
    code: '+509',
    value: 'HT',
    latitude: 19,
    longitude: -72.4167
  },
  {
    text: 'Heard Island and McDonald Islands (+672)',
    code: '+672',
    value: 'HM',
    latitude: -53.1,
    longitude: 72.5167
  },
  {
    text: 'Holy See (Vatican City State) (+379)',
    code: '+379',
    value: 'VA',
    latitude: 41.9,
    longitude: 12.45
  },
  {
    text: 'Honduras (+504)',
    code: '+504',
    value: 'HN',
    latitude: 15,
    longitude: -86.5
  },
  {
    text: 'Hong Kong (+852)',
    code: '+852',
    value: 'HK',
    latitude: 22.25,
    longitude: 114.1667
  },
  {
    text: 'Hungary (+36)',
    code: '+36',
    value: 'HU',
    latitude: 47,
    longitude: 20
  },
  {
    text: 'Iceland (+354)',
    code: '+354',
    value: 'IS',
    latitude: 65,
    longitude: -18
  },
  {
    text: 'India (+91)',
    code: '+91',
    value: 'IN',
    latitude: 20,
    longitude: 77
  },
  {
    text: 'Indonesia (+62)',
    code: '+62',
    value: 'ID',
    latitude: -5,
    longitude: 120
  },
  {
    text: 'Iran, Islamic Republic of (+98)',
    code: '+98',
    value: 'IR',
    latitude: 32,
    longitude: 53
  },
  {
    text: 'Iraq (+964)',
    code: '+964',
    value: 'IQ',
    latitude: 33,
    longitude: 44
  },
  {
    text: 'Ireland (+353)',
    code: '+353',
    value: 'IE',
    latitude: 53,
    longitude: -8
  },
  {
    text: 'Isle of Man (+44)',
    code: '+44',
    value: 'IM',
    latitude: 54.23,
    longitude: -4.55
  },
  {
    text: 'Israel (+972)',
    code: '+972',
    value: 'IL',
    latitude: 31.5,
    longitude: 34.75
  },
  {
    text: 'Italy (+39)',
    code: '+39',
    value: 'IT',
    latitude: 42.8333,
    longitude: 12.8333
  },
  {
    text: 'Jamaica (+1 876)',
    code: '+1 876',
    value: 'JM',
    latitude: 18.25,
    longitude: -77.5
  },
  {
    text: 'Japan (+81)',
    code: '+81',
    value: 'JP',
    latitude: 36,
    longitude: 138
  },
  {
    text: 'Jersey (+44)',
    code: '+44',
    value: 'JE',
    latitude: 49.21,
    longitude: -2.13
  },
  {
    text: 'Jordan (+962)',
    code: '+962',
    value: 'JO',
    latitude: 31,
    longitude: 36
  },
  {
    text: 'Kazakhstan (+7)',
    code: '+7',
    value: 'KZ',
    latitude: 48,
    longitude: 68
  },
  {
    text: 'Kenya (+254)',
    code: '+254',
    value: 'KE',
    latitude: 1,
    longitude: 38
  },
  {
    text: 'Kiribati (+686)',
    code: '+686',
    value: 'KI',
    latitude: 1.4167,
    longitude: 173
  },
  {
    text: "Korea, Democratic People's Republic of (+850)",
    value: '+850',
    key: 'KP',
    latitude: 40,
    longitude: 127
  },
  {
    text: 'Korea, Republic of (+82)',
    code: '+82',
    value: 'KR',
    latitude: 37,
    longitude: 127.5
  },
  {
    text: 'Kuwait (+965)',
    code: '+965',
    value: 'KW',
    latitude: 29.3375,
    longitude: 47.6581
  },
  {
    text: 'Kyrgyzstan (+996)',
    code: '+996',
    value: 'KG',
    latitude: 41,
    longitude: 75
  },
  {
    text: "Lao People's Democratic Republic (+856)",
    value: '+856',
    key: 'LA',
    latitude: 18,
    longitude: 105
  },
  {
    text: 'Latvia (+371)',
    code: '+371',
    value: 'LV',
    latitude: 57,
    longitude: 25
  },
  {
    text: 'Lebanon (+961)',
    code: '+961',
    value: 'LB',
    latitude: 33.8333,
    longitude: 35.8333
  },
  {
    text: 'Lesotho (+266)',
    code: '+266',
    value: 'LS',
    latitude: -29.5,
    longitude: 28.5
  },
  {
    text: 'Liberia (+231)',
    code: '+231',
    value: 'LR',
    latitude: 6.5,
    longitude: -9.5
  },
  {
    text: 'Libyan Arab Jamahiriya (+218)',
    code: '+218',
    value: 'LY',
    latitude: 25,
    longitude: 17
  },
  {
    text: 'Liechtenstein (+423)',
    code: '+423',
    value: 'LI',
    latitude: 47.1667,
    longitude: 9.5333
  },
  {
    text: 'Lithuania (+370)',
    code: '+370',
    value: 'LT',
    latitude: 56,
    longitude: 24
  },
  {
    text: 'Luxembourg (+352)',
    code: '+352',
    value: 'LU',
    latitude: 49.75,
    longitude: 6.1667
  },
  {
    text: 'Macao (+853)',
    code: '+853',
    value: 'MO',
    latitude: 22.1667,
    longitude: 113.55
  },
  {
    text: 'Macedonia, The Former Yugoslav Republic of (+389)',
    code: '+389',
    value: 'MK',
    latitude: 41.8333,
    longitude: 22
  },
  {
    text: 'Madagascar (+261)',
    code: '+261',
    value: 'MG',
    latitude: -20,
    longitude: 47
  },
  {
    text: 'Malawi (+265)',
    code: '+265',
    value: 'MW',
    latitude: -13.5,
    longitude: 34
  },
  {
    text: 'Malaysia (+60)',
    code: '+60',
    value: 'MY',
    latitude: 2.5,
    longitude: 112.5
  },
  {
    text: 'Maldives (+960)',
    code: '+960',
    value: 'MV',
    latitude: 3.25,
    longitude: 73
  },
  {
    text: 'Mali (+223)',
    code: '+223',
    value: 'ML',
    latitude: 17,
    longitude: -4
  },
  {
    text: 'Malta (+356)',
    code: '+356',
    value: 'MT',
    latitude: 35.8333,
    longitude: 14.5833
  },
  {
    text: 'Marshall Islands (+692)',
    code: '+692',
    value: 'MH',
    latitude: 9,
    longitude: 168
  },
  {
    text: 'Martinique (+596)',
    code: '+596',
    value: 'MQ',
    latitude: 14.6667,
    longitude: -61
  },
  {
    text: 'Mauritania (+222)',
    code: '+222',
    value: 'MR',
    latitude: 20,
    longitude: -12
  },
  {
    text: 'Mauritius (+230)',
    code: '+230',
    value: 'MU',
    latitude: -20.2833,
    longitude: 57.55
  },
  {
    text: 'Mayotte (+262)',
    code: '+262',
    value: 'YT',
    latitude: -12.8333,
    longitude: 45.1667
  },
  {
    text: 'Mexico (+52)',
    code: '+52',
    value: 'MX',
    latitude: 23,
    longitude: -102
  },
  {
    text: 'Micronesia, Federated States of (+691)',
    code: '+691',
    value: 'FM',
    latitude: 6.9167,
    longitude: 158.25
  },
  {
    text: 'Moldova, Republic of (+373)',
    code: '+373',
    value: 'MD',
    latitude: 47,
    longitude: 29
  },
  {
    text: 'Monaco (+377)',
    code: '+377',
    value: 'MC',
    latitude: 43.7333,
    longitude: 7.4
  },
  {
    text: 'Mongolia (+976)',
    code: '+976',
    value: 'MN',
    latitude: 46,
    longitude: 105
  },
  {
    text: 'Montenegro (+382)',
    code: '+382',
    value: 'ME',
    latitude: 42,
    longitude: 19
  },
  {
    text: 'Montserrat (+1664)',
    code: '+1664',
    value: 'MS',
    latitude: 16.75,
    longitude: -62.2
  },
  {
    text: 'Morocco (+212)',
    code: '+212',
    value: 'MA',
    latitude: 32,
    longitude: -5
  },
  {
    text: 'Mozambique (+258)',
    code: '+258',
    value: 'MZ',
    latitude: -18.25,
    longitude: 35
  },
  {
    text: 'Myanmar (+95)',
    code: '+95',
    value: 'MM',
    latitude: 22,
    longitude: 98
  },
  {
    text: 'Namibia (+264)',
    code: '+264',
    value: 'NA',
    latitude: -22,
    longitude: 17
  },
  {
    text: 'Nauru (+674)',
    code: '+674',
    value: 'NR',
    latitude: -0.5333,
    longitude: 166.9167
  },
  {
    text: 'Nepal (+977)',
    code: '+977',
    value: 'NP',
    latitude: 28,
    longitude: 84
  },
  {
    text: 'Netherlands (+31)',
    code: '+31',
    value: 'NL',
    latitude: 52.5,
    longitude: 5.75
  },
  {
    text: 'Netherlands Antilles (+599)',
    code: '+599',
    value: 'AN',
    latitude: 12.25,
    longitude: -68.75
  },
  {
    text: 'New Caledonia (+687)',
    code: '+687',
    value: 'NC',
    latitude: -21.5,
    longitude: 165.5
  },
  {
    text: 'New Zealand (+64)',
    code: '+64',
    value: 'NZ',
    latitude: -41,
    longitude: 174
  },
  {
    text: 'Nicaragua (+505)',
    code: '+505',
    value: 'NI',
    latitude: 13,
    longitude: -85
  },
  {
    text: 'Niger (+227)',
    code: '+227',
    value: 'NE',
    latitude: 16,
    longitude: 8
  },
  {
    text: 'Nigeria (+234)',
    code: '+234',
    value: 'NG',
    latitude: 10,
    longitude: 8
  },
  {
    text: 'Niue (+683)',
    code: '+683',
    value: 'NU',
    latitude: -19.0333,
    longitude: -169.8667
  },
  {
    text: 'Norfolk Island (+672)',
    code: '+672',
    value: 'NF',
    latitude: -29.0333,
    longitude: 167.95
  },
  {
    text: 'Northern Mariana Islands (+1 670)',
    code: '+1 670',
    value: 'MP',
    latitude: 15.2,
    longitude: 145.75
  },
  {
    text: 'Norway (+47)',
    code: '+47',
    value: 'NO',
    latitude: 62,
    longitude: 10
  },
  {
    text: 'Oman (+968)',
    code: '+968',
    value: 'OM',
    latitude: 21,
    longitude: 57
  },
  {
    text: 'Pakistan (+92)',
    code: '+92',
    value: 'PK',
    latitude: 30,
    longitude: 70
  },
  {
    text: 'Palau (+680)',
    code: '+680',
    value: 'PW',
    latitude: 7.5,
    longitude: 134.5
  },
  {
    text: 'Palestinian Territory, Occupied (+970)',
    code: '+970',
    value: 'PS',
    latitude: 32,
    longitude: 35.25
  },
  {
    text: 'Panama (+507)',
    code: '+507',
    value: 'PA',
    latitude: 9,
    longitude: -80
  },
  {
    text: 'Papua New Guinea (+675)',
    code: '+675',
    value: 'PG',
    latitude: -6,
    longitude: 147
  },
  {
    text: 'Paraguay (+595)',
    code: '+595',
    value: 'PY',
    latitude: -23,
    longitude: -58
  },
  {
    text: 'Peru (+51)',
    code: '+51',
    value: 'PE',
    latitude: -10,
    longitude: -76
  },
  {
    text: 'Philippines (+63)',
    code: '+63',
    value: 'PH',
    latitude: 13,
    longitude: 122
  },
  {
    text: 'Pitcairn (+870)',
    code: '+870',
    value: 'PN',
    latitude: -24.7,
    longitude: -127.4
  },
  {
    text: 'Poland (+48)',
    code: '+48',
    value: 'PL',
    latitude: 52,
    longitude: 20
  },
  {
    text: 'Portugal (+351)',
    code: '+351',
    value: 'PT',
    latitude: 39.5,
    longitude: -8
  },
  {
    text: 'Puerto Rico (+1 939)',
    code: '+1 939',
    value: 'PR',
    latitude: 18.25,
    longitude: -66.5
  },
  {
    text: 'Qatar (+974)',
    code: '+974',
    value: 'QA',
    latitude: 25.5,
    longitude: 51.25
  },
  {
    text: 'Réunion (+262)',
    code: '+262',
    value: 'RE',
    latitude: -21.1,
    longitude: 55.6
  },
  {
    text: 'Romania (+40)',
    code: '+40',
    value: 'RO',
    latitude: 46,
    longitude: 25
  },
  {
    text: 'Russia (+7)',
    code: '+7',
    value: 'RU',
    latitude: 60,
    longitude: 100
  },
  {
    text: 'Rwanda (+250)',
    code: '+250',
    value: 'RW',
    latitude: -2,
    longitude: 30
  },
  {
    text: 'Saint Helena, Ascension and Tristan Da Cunha (+290)',
    code: '+290',
    value: 'SH',
    latitude: -15.9333,
    longitude: -5.7
  },
  {
    text: 'Saint Kitts and Nevis (+1 869)',
    code: '+1 869',
    value: 'KN',
    latitude: 17.3333,
    longitude: -62.75
  },
  {
    text: 'Saint Lucia (+1 758)',
    code: '+1 758',
    value: 'LC',
    latitude: 13.8833,
    longitude: -61.1333
  },
  {
    text: 'Saint Pierre and Miquelon (+508)',
    code: '+508',
    value: 'PM',
    latitude: 46.8333,
    longitude: -56.3333
  },
  {
    text: 'Saint Vincent and the Grenadines (+1 784)',
    code: '+1 784',
    value: 'VC',
    latitude: 13.25,
    longitude: -61.2
  },
  {
    text: 'Samoa (+685)',
    code: '+685',
    value: 'WS',
    latitude: -13.5833,
    longitude: -172.3333
  },
  {
    text: 'San Marino (+378)',
    code: '+378',
    value: 'SM',
    latitude: 43.7667,
    longitude: 12.4167
  },
  {
    text: 'Sao Tome and Principe (+239)',
    code: '+239',
    value: 'ST',
    latitude: 1,
    longitude: 7
  },
  {
    text: 'Saudi Arabia (+966)',
    code: '+966',
    value: 'SA',
    latitude: 25,
    longitude: 45
  },
  {
    text: 'Senegal (+221)',
    code: '+221',
    value: 'SN',
    latitude: 14,
    longitude: -14
  },
  {
    text: 'Serbia (+381)',
    code: '+381',
    value: 'RS',
    latitude: 44,
    longitude: 21
  },
  {
    text: 'Seychelles (+248)',
    code: '+248',
    value: 'SC',
    latitude: -4.5833,
    longitude: 55.6667
  },
  {
    text: 'Sierra Leone (+232)',
    code: '+232',
    value: 'SL',
    latitude: 8.5,
    longitude: -11.5
  },
  {
    text: 'Singapore (+65)',
    code: '+65',
    value: 'SG',
    latitude: 1.3667,
    longitude: 103.8
  },
  {
    text: 'Slovakia (+421)',
    code: '+421',
    value: 'SK',
    latitude: 48.6667,
    longitude: 19.5
  },
  {
    text: 'Slovenia (+386)',
    code: '+386',
    value: 'SI',
    latitude: 46,
    longitude: 15
  },
  {
    text: 'Solomon Islands (+677)',
    code: '+677',
    value: 'SB',
    latitude: -8,
    longitude: 159
  },
  {
    text: 'Somalia (+252)',
    code: '+252',
    value: 'SO',
    latitude: 10,
    longitude: 49
  },
  {
    text: 'South Africa (+27)',
    code: '+27',
    value: 'ZA',
    latitude: -29,
    longitude: 24
  },
  {
    text: 'South Georgia and the South Sandwich Islands (+500)',
    code: '+500',
    value: 'GS',
    latitude: -54.5,
    longitude: -37
  },
  {
    text: 'Spain (+34)',
    code: '+34',
    value: 'ES',
    latitude: 40,
    longitude: -4
  },
  {
    text: 'Sri Lanka (+94)',
    code: '+94',
    value: 'LK',
    latitude: 7,
    longitude: 81
  },
  {
    text: 'Sudan (+249)',
    code: '+249',
    value: 'SD',
    latitude: 15,
    longitude: 30
  },
  {
    text: 'Suritext (+597)',
    code: '+597',
    value: 'SR',
    latitude: 4,
    longitude: -56
  },
  {
    text: 'Svalbard and Jan Mayen (+47)',
    code: '+47',
    value: 'SJ',
    latitude: 78,
    longitude: 20
  },
  {
    text: 'Swaziland (+268)',
    code: '+268',
    value: 'SZ',
    latitude: -26.5,
    longitude: 31.5
  },
  {
    text: 'Sweden (+46)',
    code: '+46',
    value: 'SE',
    latitude: 62,
    longitude: 15
  },
  {
    text: 'Switzerland (+41)',
    code: '+41',
    value: 'CH',
    latitude: 47,
    longitude: 8
  },
  {
    text: 'Syrian Arab Republic (+963)',
    code: '+963',
    value: 'SY',
    latitude: 35,
    longitude: 38
  },
  {
    text: 'Taiwan (+886)',
    code: '+886',
    value: 'TW',
    latitude: 23.5,
    longitude: 121
  },
  {
    text: 'Tajikistan (+992)',
    code: '+992',
    value: 'TJ',
    latitude: 39,
    longitude: 71
  },
  {
    text: 'Tanzania, United Republic of (+255)',
    code: '+255',
    value: 'TZ',
    latitude: -6,
    longitude: 35
  },
  {
    text: 'Thailand (+66)',
    code: '+66',
    value: 'TH',
    latitude: 15,
    longitude: 100
  },
  {
    text: 'Timor-Leste (+670)',
    code: '+670',
    value: 'TL',
    latitude: -8.55,
    longitude: 125.5167
  },
  {
    text: 'Togo (+228)',
    code: '+228',
    value: 'TG',
    latitude: 8,
    longitude: 1.1667
  },
  {
    text: 'Tokelau (+690)',
    code: '+690',
    value: 'TK',
    latitude: -9,
    longitude: -172
  },
  {
    text: 'Tonga (+676)',
    code: '+676',
    value: 'TO',
    latitude: -20,
    longitude: -175
  },
  {
    text: 'Trinidad and Tobago (+1 868)',
    code: '+1 868',
    value: 'TT',
    latitude: 11,
    longitude: -61
  },
  {
    text: 'Tunisia (+216)',
    code: '+216',
    value: 'TN',
    latitude: 34,
    longitude: 9
  },
  {
    text: 'Turvalue (+90)',
    code: '+90',
    value: 'TR',
    latitude: 39,
    longitude: 35
  },
  {
    text: 'Turkmenistan (+993)',
    code: '+993',
    value: 'TM',
    latitude: 40,
    longitude: 60
  },
  {
    text: 'Turks and Caicos Islands (+1 649)',
    code: '+1 649',
    value: 'TC',
    latitude: 21.75,
    longitude: -71.5833
  },
  {
    text: 'Tuvalu (+688)',
    code: '+688',
    value: 'TV',
    latitude: -8,
    longitude: 178
  },
  {
    text: 'Uganda (+256)',
    code: '+256',
    value: 'UG',
    latitude: 1,
    longitude: 32
  },
  {
    text: 'Ukraine (+380)',
    code: '+380',
    value: 'UA',
    latitude: 49,
    longitude: 32
  },
  {
    text: 'United Arab Emirates (+971)',
    code: '+971',
    value: 'AE',
    latitude: 24,
    longitude: 54
  },
  {
    text: 'United Kingdom (+44)',
    code: '+44',
    value: 'GB',
    latitude: 54,
    longitude: -2
  },
  {
    text: 'United States (+1)',
    code: '+1',
    value: 'US',
    latitude: 38,
    longitude: -97
  },
  {
    text: 'United States Minor Outlying Islands (+1581)',
    code: '+1581',
    value: 'UM',
    latitude: 19.2833,
    longitude: 166.6
  },
  {
    text: 'Uruguay (+598)',
    code: '+598',
    value: 'UY',
    latitude: -33,
    longitude: -56
  },
  {
    text: 'Uzbekistan (+998)',
    code: '+998',
    value: 'UZ',
    latitude: 41,
    longitude: 64
  },
  {
    text: 'Vanuatu (+678)',
    code: '+678',
    value: 'VU',
    latitude: -16,
    longitude: 167
  },
  {
    text: 'Venezuela, Bolivarian Republic of (+58)',
    code: '+58',
    value: 'VE',
    latitude: 8,
    longitude: -66
  },
  {
    text: 'Viet Nam (+84)',
    code: '+84',
    value: 'VN',
    latitude: 16,
    longitude: 106
  },
  {
    text: 'Virgin Islands, British (+1 284)',
    code: '+1 284',
    value: 'VG',
    latitude: 18.5,
    longitude: -64.5
  },
  {
    text: 'Virgin Islands, U.S. (+1 340)',
    code: '+1 340',
    value: 'VI',
    latitude: 18.3333,
    longitude: -64.8333
  },
  {
    text: 'Wallis and Futuna (+681)',
    code: '+681',
    value: 'WF',
    latitude: -13.3,
    longitude: -176.2
  },
  {
    text: 'Western Sahara (+732)',
    code: '+732',
    value: 'EH',
    latitude: 24.5,
    longitude: -13
  },
  {
    text: 'Yemen (+967)',
    code: '+967',
    value: 'YE',
    latitude: 15,
    longitude: 48
  },
  {
    text: 'Zambia (+260)',
    code: '+260',
    value: 'ZM',
    latitude: -15,
    longitude: 30
  },
  {
    text: 'Zimbabwe (+263)',
    code: '+263',
    value: 'ZW',
    latitude: -20,
    longitude: 30
  }
];

export default countryCodes;

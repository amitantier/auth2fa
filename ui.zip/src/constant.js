export const rootName = "";
export const API_HOST = process.env.REACT_APP_API_URL;
export const CAPTCHA_KEY = process.env.REACT_APP_GOOGLE_CAPTCHA_KEY;
export const ENV_VAR = process.env.ENV_VAR;
export const EXCHANGE_LINK = process.env.REACT_APP_EXCHANGE_URL;
export const SOCKET_URL = process.env.REACT_APP_SOCKET_URL;
export const P2P_SOCKET_URL = process.env.REACT_APP_P2P_SOCKET_URL;
export const globalResErrMsg =
  "Woops something went wrong, Please try again.";
export const SUCCESS_200 = 200;
export const BAD_REQUEST = 400;
export const UNAUTHORISED = 401;
export const AUTH_TOKEN_KEY = "JwtToken";
export const PASSPORT_FRONT = 0;
export const PASSPORT_BACK = 4;
export const LICENSE_FRONT = 2;
export const LICENSE_BACK = 3;
export const NATIONAL_ID = 1;
export const KYC_SUBMITTED = 0;
export const KYC_APPROVED = 1;
export const KYC_DECLINED = 2;
export const KYC_RE_SUBMITTED = 3;
export const SMALLESTUNIT = 100000000;
export const totallimit = 10000000000000000;
export const txnWaiting = 0 //WAITING FOR ADMIN APPROVAL
export const txnUnconfirmed = 1 //UNCONFIRMED
export const txnCompleted = 2 //CONFIRMED
export const txnRjected = 3 //REJECTED BY ADMIN 
export const currencyDivison = 100000000;



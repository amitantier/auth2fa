import React from "react";
import { Nav, Navbar } from "react-bootstrap";
import { useHistory } from "react-router-dom";
import "./HeaderExchange.scss";
import moon from "../../assets/images/moon.png";
import headfone from "../../assets/images/headfone.svg";
import user from "../../assets/images/user.png";

function HeaderExchange() {
  const history = useHistory();
  return (
    <div>
      <Navbar bg="dark" expand="lg" className="exchange-header">
        <Navbar.Brand href="#home" className="header-logo"></Navbar.Brand>
        {/* <Navbar.Toggle aria-controls="basic-navbar-nav" /> */}

        <Nav className="ml-auto rightNavbar">
          <p className="link_signin">
            <img src={moon} />
          </p>
          <p className="link_signin">
            <img src={headfone} />
          </p>
          <p className="link_signin">
            <img src={user} />{" "}
            <span className="user-name" onClick={() => history.push("/")}>
              EXIT TRADING
            </span>
          </p>
        </Nav>
      </Navbar>
    </div>
  );
}

export default HeaderExchange;

import React from "react";
import { Col } from "react-bootstrap";
import "./CommonCont.scss";

function CommonCont(props) {
  return (
    <Col className={`commonCard_style ${props.className}`}>
      {props.heading ? <h2>{props.heading}</h2> : null}
      {props.subheading ? <p>{props.subheading}</p> : null}
      {props.children}
    </Col>
  );
}

export default CommonCont;


import { Form } from 'react-bootstrap';
import React, { useState } from 'react'

import './InputCustomStyle.scss';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const DobCustom = props => {

    return(
        <Form.Group className={`customInput ${props.className}`}  controlId={props.controlId}>
            <Form.Label>{props.label}</Form.Label>
            <DatePicker    showMonthDropdown
  showYearDropdown className="form-control" selected={props.startDate ? new Date(props.startDate):""} onChange={date => props.onChange(date)} />
    
            {props.children}                         
        </Form.Group>
    )
}
export default DobCustom

import { Button } from 'react-bootstrap';
// import './ButtonCustomStyle.scss'

const ButtonCustom = props => {
    return(
        <Button  
            disabled={props.disabled} 
            type={props.type} 
            variant="primary"  
            block 
            onClick={props.onClick} 
            className={`themeButton ${props.className}`}>
                {props.buttontext} 
            </Button>
    )
}
export default ButtonCustom
import React from "react";
import { Table } from "react-bootstrap";
import BitcoinIcon from "../../../theme/images/bitcoin.svg";
import UniswapIcon from "../../../theme/images/uniswap.svg";
import DotIcon from "../../../theme/images/dot.svg";
import TronIcon from "../../../theme/images/tron.svg";
import BnbIcon from "../../../theme/images/bnb.svg";
import GraphGreen from "../../../theme/images/graph_green.svg";
import PerfectScrollbar from "react-perfect-scrollbar";
import "react-perfect-scrollbar/dist/css/styles.css";
import "./CustomTable.scss";
import { Link } from "react-router-dom";

function CustomTable(props) {
  return (
    <PerfectScrollbar
      onScrollY={(container) =>
        console.log(`scrolled to: ${container.scrollTop}.`)
      }
    >
      <Table className={`customTable ${props.className}`}>
        <thead>
          <tr>
            <th>Asset Name</th>
            <th>Price</th>
            <th>24h Change</th>
            <th>30d Graph</th>
            <th>My Balance</th>
            <th>Value</th>
            <th className="linkTo_Wallet">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <img src={BitcoinIcon} className="coin_icon" />
              Bitcoin
            </td>
            <td>$38,135.00</td>
            <td className="inGreen">0.88%</td>
            <td>
              <img src={GraphGreen} />
            </td>
            <td>0.221746 BTC</td>
            <td>$38,135.00</td>
            <td className="linkTo_Wallet">
              <Link to="/auth/deposit">Deposit</Link>
              <Link to="/auth/deposit">Withdraw</Link>
            </td>
          </tr>
          <tr>
            <td>
              <img src={DotIcon} className="coin_icon" />
              Dot
            </td>
            <td>$38,135.00</td>
            <td className="inGreen">0.88%</td>
            <td>
              <img src={GraphGreen} />
            </td>
            <td>0.221746 BTC</td>
            <td>$38,135.00</td>
            <td className="linkTo_Wallet">
              <Link to="/auth/deposit">Deposit</Link>
              <Link to="/auth/deposit">Withdraw</Link>
            </td>
          </tr>
          <tr>
            <td>
              <img src={TronIcon} className="coin_icon" />
              Tron
            </td>
            <td>$38,135.00</td>
            <td className="inGreen">0.88%</td>
            <td>
              <img src={GraphGreen} />
            </td>
            <td>0.221746 BTC</td>
            <td>$38,135.00</td>
            <td className="linkTo_Wallet">
              <Link to="/auth/deposit">Deposit</Link>
              <Link to="/auth/deposit">Withdraw</Link>
            </td>
          </tr>
          <tr>
            <td>
              <img src={UniswapIcon} className="coin_icon" />
              Uniswap
            </td>
            <td>$38,135.00</td>
            <td className="inGreen">0.88%</td>
            <td>
              <img src={GraphGreen} />
            </td>
            <td>0.221746 BTC</td>
            <td>$38,135.00</td>
            <td className="linkTo_Wallet">
              <Link to="/auth/deposit">Deposit</Link>
              <Link to="/auth/deposit">Withdraw</Link>
            </td>
          </tr>
          <tr>
            <td>
              <img src={BnbIcon} className="coin_icon" />
              Bnb
            </td>
            <td>$38,135.00</td>
            <td className="inGreen">0.88%</td>
            <td>
              <img src={GraphGreen} />
            </td>
            <td>0.221746 BTC</td>
            <td>$38,135.00</td>
            <td className="linkTo_Wallet">
              <Link to="/auth/deposit">Deposit</Link>
              <Link to="/auth/deposit">Withdraw</Link>
            </td>
          </tr>
        </tbody>
        {/* NO RECORD FOUND */}
        {/* <tbody>
          <tr>
            <td colSpan="6" className="text-center noTransaction_found">
              No Transactions Found
            </td>
          </tr>
        </tbody> */}
      </Table>
    </PerfectScrollbar>
  );
}

export default CustomTable;

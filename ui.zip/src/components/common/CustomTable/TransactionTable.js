import React from "react";
import { Table } from "react-bootstrap";
import PerfectScrollbar from "react-perfect-scrollbar";
import "react-perfect-scrollbar/dist/css/styles.css";
import "./CustomTable.scss";

function TransactionTable(props) {
  return (
    <div className="tableOuter_Div deposit_Table">
      <PerfectScrollbar
        onScrollY={(container) =>
          console.log(`scrolled to: ${container.scrollTop}.`)
        }
      >
        <Table className={`customTable ${props.className}`}>
          <thead>
            <tr>
              <th>Time</th>
              <th>Type</th>
              <th>Asset</th>
              <th>Amount</th>
              <th>Destination</th>
              <th>TxID</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>21-Sep-2021</td>
              <td>Abcdef</td>
              <td>Bitcoin</td>
              <td>$38,135.00</td>
              <td>00vjhjhafrje46GHlkf</td>
              <td>000sshraTHV</td>
              <td>Done</td>
            </tr>
            <tr>
              <td>21-Sep-2021</td>
              <td>Abcdef</td>
              <td>Bitcoin</td>
              <td>$38,135.00</td>
              <td>00vjhjhafrje46GHlkf</td>
              <td>000sshraTHV</td>
              <td>Done</td>
            </tr>
            <tr>
              <td>21-Sep-2021</td>
              <td>Abcdef</td>
              <td>Bitcoin</td>
              <td>$38,135.00</td>
              <td>00vjhjhafrje46GHlkf</td>
              <td>000sshraTHV</td>
              <td>Done</td>
            </tr>
            <tr>
              <td>21-Sep-2021</td>
              <td>Abcdef</td>
              <td>Bitcoin</td>
              <td>$38,135.00</td>
              <td>00vjhjhafrje46GHlkf</td>
              <td>000sshraTHV</td>
              <td>Done</td>
            </tr>
            <tr>
              <td>21-Sep-2021</td>
              <td>Abcdef</td>
              <td>Bitcoin</td>
              <td>$38,135.00</td>
              <td>00vjhjhafrje46GHlkf</td>
              <td>000sshraTHV</td>
              <td>Done</td>
            </tr>
          </tbody>
          {/* NO RECORD FOUND */}
          {/* <tbody>
          <tr>
            <td colSpan="7" className="text-center noTransaction_found">
              No Transactions Found
            </td>
          </tr>
        </tbody> */}
        </Table>
      </PerfectScrollbar>
    </div>
  );
}

export default TransactionTable;

import React from "react";
import { Col } from "react-bootstrap";
import "./SettingCard.scss";

function SettingCard(props) {
  return (
    <>
      <Col
        className={`settingCard_Style  ${props.className}`}
        onClick={props.onClick} xs={12} sm={12} md={6}
      >
        <h3>
          <img src={props.icon} alt={props.alt} />
          {props.title}
          {props.iconsecond ? (
            <img
              src={props.iconsecond}
              alt={props.alt}
              className="securityIcon"
            />
          ) : null}
          {props.iconsecondLite ? (
            <img
              src={props.iconsecondLite}
              alt={props.alt}
              className="securityIcon_lite"
            />
          ) : null}
        </h3>
        <p>{props.text}</p>
        {props.children}
      </Col>
    </>
  );
}

export default SettingCard;

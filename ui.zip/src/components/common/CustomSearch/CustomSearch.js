import React from "react";
import { FormControl } from "react-bootstrap";
import "../CustomInput/CustomInput.scss";
import "./CustomSearch.scss";

function CustomSearch(props) {
  return (
    <FormControl
      type="search"
      placeholder={props.placeholder}
      aria-label="Search Token"
      className={`serchInput ${props.className}`}
    />
  );
}

export default CustomSearch;

import React, { useState, useRef } from "react";
import { Col, Overlay, Tooltip } from "react-bootstrap";
import MozillaIcon from "../../../theme/images/mozilla_icon.svg";
import "./DeviceCard.scss";

function DeviceCard(props) {
  const [show, setShow] = useState(false);
  const target = useRef(null);
  return (
    <Col className="deviceCard_Style" xs={12} sm={12} md={6} lg={4} xl={4}>
      <div className="imageDiv">
        <img src={props.icon} alt={props.alt} />
        <button ref={target} onClick={() => setShow(!show)}>
          {props.iconsecond ? (
            <img
              src={props.iconsecond}
              alt={props.alt}
              className="securityIcon"
            />
          ) : null}
          {props.iconsecondLite ? (
            <img
              src={props.iconsecondLite}
              alt={props.alt}
              className="securityIcon_lite"
            />
          ) : null}
        </button>

        <Overlay target={target.current} show={show} placement="bottom">
          {(props) => (
            <Tooltip
              id="overlay-example"
              {...props}
              className="customTooltip_Style"
            >
              <a>Rename</a>
              <a>Delete</a>
            </Tooltip>
          )}
        </Overlay>
      </div>
      <div className="deviceDetail">
        <p>
          {props.device} <span>This device</span>
        </p>
        <p>
          IP Address - {props.ip} | {props.location}
        </p>
        <p className="statusText">
          <img src={MozillaIcon} /> {props.browser} <span>{props.status}</span>
        </p>
      </div>
    </Col>
  );
}

export default DeviceCard;

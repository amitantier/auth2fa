import React from "react";
import { Navbar, Container, Nav, Badge } from "react-bootstrap";
import { NavLink, Link } from "react-router-dom";
import BitBubble_logo from "../../../theme/images/BitBubblePng.png";
import MObLogo from "../../../theme/images/MobLogo.svg";
import "./NavbarStyle.scss";

const NavbarTop = () => {
  return (
    <Navbar collapseOnSelect expand="lg" variant="dark">
      <Container fluid>
        <Navbar.Brand href="#home">
          <img className="fullscreenImg" src={BitBubble_logo} />
          <img src={MObLogo} className="mobLogo" />
        </Navbar.Brand>
        {/* <Navbar.Toggle aria-controls="responsive-navbar-nav" /> */}
        <div className="navTopDiv">
          <div className="ButtonsDiv">
            {/* <button >Login</button> */}
            <Link to="/login" className="LoginBtn commonBtns">
              Login
            </Link>
            <Link to="/signup" className="SignupBtn commonBtns">
              Signup
            </Link>
            {/* <button className="SignupBtn commonBtns">Signup</button> */}
          </div>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />

          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="me-auto"></Nav>
            <Nav>
              <NavLink
                to="/"
                eventKey={2}
                className="NavLinks content"
                href="#memes"
              >
                Exchange
              </NavLink>
              <NavLink
                to="/"
                eventKey={2}
                className="NavLinks content"
                href="#memes"
              >
                Markets
              </NavLink>
              <NavLink
                to="/"
                eventKey={2}
                className="NavLinks content"
                href="#memes"
              >
                Service Swap
              </NavLink>
              <NavLink
                to="/"
                eventKey={2}
                className="NavLinks content"
                href="#memes"
              >
                Merchant Solution
              </NavLink>
              <NavLink
                to="/"
                eventKey={2}
                className="NavLinks content"
                href="#memes"
              >
                Fiat on Ramp
              </NavLink>
            </Nav>
          </Navbar.Collapse>
        </div>
      </Container>
    </Navbar>
  );
};

export default NavbarTop;

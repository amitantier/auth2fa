import React from "react";
import { Form } from "react-bootstrap";
import "../CustomInput/CustomInput.scss";
import "./SelectPair.scss"

function SelectPair(props) {
  return (
    <Form.Group className="customSelect pairSelect ">
      {props.label ? <Form.Label>{props.label}</Form.Label> : null}
      <Form.Control as="select">
        <option>{props.placeholder}</option>
        <option>Pair 1</option>
        <option>Pair 2</option>
        <option>Pair 3</option>
        <option>Pair 4</option>
      </Form.Control>
      {props.children}
    </Form.Group>
  );
}

export default SelectPair;

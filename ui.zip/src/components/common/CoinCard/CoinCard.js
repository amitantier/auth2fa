import React from "react";
import { Row, Col, Card } from "react-bootstrap";
import { useHistory } from "react-router-dom";
import "./CoinCard.scss";

function CoinCard(props) {
  let history = useHistory();
  const redirect = () => {
    history.push("/auth/deposit");
  };
  return (
    <Card className="coinCard_style" onClick={redirect}>
      <Card.Body>
        <Row>
          <Col className="coinName_txt">
            <img src={props.icon} />
            {props.name}
          </Col>
          <Col className="text-right coinBalance_txt">
            {props.price}
            <span> {props.symbol}</span>
          </Col>
        </Row>
        <Row>
          <Col>
            <img src={props.graph} className="graphImg" />
          </Col>
        </Row>
        <Row className="coinChange_row">
          <Col className="coinChange_detail">{props.date}</Col>
          <Col className="text-right coinChange_detail">{props.lastchange}</Col>
          <Col xs={12} className="bottom_txt">
            {props.text}
          </Col>
        </Row>
      </Card.Body>
    </Card>
  );
}

export default CoinCard;

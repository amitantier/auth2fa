import { Navbar, Container, Nav, Badge, NavDropdown } from "react-bootstrap";
import { useEffect, useState } from "react";
import MobLogo from "../../../theme/images/MobLogo.svg";
import "./NavbarAfterlogin.scss";
import { AUTH_TOKEN_KEY } from '../../../constant';

import {removeToken} from '../../../Helpers/storageHelper';
import { useHistory } from "react-router-dom";


const NavbarAfterlogin = (props) => {
  const [day, setDay] = useState(false);
  const history = useHistory();

  useEffect(async () => {
    const theme = await localStorage.getItem("theme");
    if (theme === "dark") {
      setDay(true);
      document.body.classList.add("lightTheme");
      return;
    }
    document.body.classList.remove("lightTheme");
  }, []);

  async function toggleTheme() {
    const theme = await localStorage.getItem("theme");
    if (theme === "dark") {
      setDay(false);
      document.body.classList.remove("lightTheme");
      localStorage.removeItem("theme");
    } else {
      setDay(true);
      document.body.classList.add("lightTheme");
      localStorage.setItem("theme", "dark");
    }
  }
const loggoutUser = (e) =>{
e.preventDefault();
  localStorage.clear();
  setTimeout(() => {
    removeToken(AUTH_TOKEN_KEY, '', 1);
    history.push(`/signIn`);
  }, 400);

}

  return (
    <Navbar collapseOnSelect className="navAfter_login">
      <Container fluid>
        <div className="d-flex align-items-center">
          <img src={MobLogo} className="navafterLogin_logo" />
          {/* <p>Profile</p> */}
        </div>

        <div className="userDetail_div">
          <p href="#" className="wallet_Balance">
            0.0221556 BTC
            <span>Wallet Balance</span>
          </p>

          {day ? (
            <a className="moonIcon" onClick={toggleTheme}></a>
          ) : (
            <a className="sunIcon" onClick={toggleTheme}></a>
          )}

          <NavDropdown
            title="Adam"
            id="collasible-nav-dropdown"
            className="navDropdown_style"
          >
            <NavDropdown.Item href="/auth/profile">Profile</NavDropdown.Item>
            <NavDropdown.Item href="/auth/setting">Setting</NavDropdown.Item>
            <NavDropdown.Item href="/auth/kycdetail">Kyc</NavDropdown.Item>
            <NavDropdown.Item onClick={(e)=>{loggoutUser(e)}} href="#">Logout</NavDropdown.Item>
          </NavDropdown>
        </div>
      </Container>
    </Navbar>
  );
};

export default NavbarAfterlogin;

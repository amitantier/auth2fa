import React from "react";
import { Form } from "react-bootstrap";
import "../CustomInput/CustomInput.scss";
import "../PhoneInput/PhoneInput.scss";
import Select from "react-select";
import BitcoinIcon from "../../../theme/images/bitcoin.svg";
import UniswapIcon from "../../../theme/images/uniswap.svg";
import DotIcon from "../../../theme/images/dot.svg";
import TronIcon from "../../../theme/images/tron.svg";
import BnbIcon from "../../../theme/images/bnb.svg";
import "./CurrencyInput.scss";
const options = [
  {
    value: "btc",
    label: (
      <div>
        <img src={BitcoinIcon} className="optionIcon" />
        BTC
      </div>
    ),
  },
  {
    value: "tron",
    label: (
      <div>
        <img src={TronIcon} className="optionIcon" />
        TRON
      </div>
    ),
  },
  {
    value: "dot",
    label: (
      <div>
        <img src={DotIcon} className="optionIcon" />
        DOT
      </div>
    ),
  },
  {
    value: "uniswap",
    label: (
      <div>
        <img src={UniswapIcon} className="optionIcon" />
        UNI
      </div>
    ),
  },
  {
    value: "bnb",
    label: (
      <div>
        <img src={BnbIcon} className="optionIcon" />
        BNB
      </div>
    ),
  },
];
const CurrencyInput = (props) => {
  return (
    <Form.Group className={`customInput ${props.className}`}>
      {props.label ? <Form.Label>{props.label}</Form.Label> : null}
      <div className="comboFieldStyle currencyInput">
        <Form.Control
          type="text"
          name="phone"
          className="d-flex align-items-center"
          placeholder={props.placeholder}
        />
        <Select
          options={options}
          defaultValue={options[0]}
          classNamePrefix="react-select"
          placeholder="btc"
          label="deposit"
        />
      </div>
      {props.children}
    </Form.Group>
  );
};
export default CurrencyInput;

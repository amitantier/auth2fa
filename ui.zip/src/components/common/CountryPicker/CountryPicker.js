import React from "react";
import { Form } from "react-bootstrap";
import "../CustomInput/CustomInput.scss";
import "./CountryPicker.scss";

const CountryPicker = (props) => {
  return (
    <Form.Group className={`customSelect ${props.className}`}>
      <Form.Label>{props.label}</Form.Label>
      <Form.Control onChange={(e) => props.handleChange(e, props.name)} as="select" required={true}>
      {props.countryName && props.countryName.length > 0 && props.countryName.map((item)=>{
          return(
          <option selected={props.defaultValue === item.value ? true : false} value={item.value}>{item.label}</option>
          )
      })}
       {/* <option>{props.placeholder}</option> */}
      </Form.Control>
      {props.children}
    </Form.Group>
  );
};

export default CountryPicker;

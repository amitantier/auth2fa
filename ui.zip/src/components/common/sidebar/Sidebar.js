import React from "react";
import { Link } from "react-router-dom";
import SidebarLogo from "../../../theme/images/MobLogo.svg";

import "./SidebarStyle.scss";

function sidebar() {
  return (
    <div className="sidebar_Style">
      <ul>
        <li className="sidebar_Logo">
          <img src={SidebarLogo} />
        </li>
        <li>
          <Link to="/auth/exchange" className="exchangeIcon is_Active" />
        </li>
        <li>
          <Link to="/auth/wallet" className="walletIcon" />
        </li>
        <li>
          <Link to="/auth/swap" className="swapIcon" />
        </li>
        <li>
          <Link to="/auth/profile" className="userIcon" />
        </li>
        <li>
          <Link to="/auth/setting" className="settingIcon" />
        </li>
      </ul>
      <div className="sidebarCopyrightDiv">
        <p className="copyrightText">
          ©2021
          <br />
          Bitbubble
        </p>
      </div>
    </div>
  );
}

export default sidebar;

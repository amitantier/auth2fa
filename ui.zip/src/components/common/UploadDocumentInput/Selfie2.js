import React from "react";
import "./UploadDocumentInput.scss";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import Webcam from "react-webcam";
import ButtonCustom from '../../ButtonCustom/ButtonCustom'
import { saveKycFormData, uploadRawFileSelfie, removeKycDoc, removeSelfieDoc } from "../../../redux/actions/SecurityActions";


function TakeSelfie(props) {
    const [webcamEnabled, setWebcamEnabled] = React.useState(false)

    const videoConstraints = {
        width: 1280,
        height: 720,
        facingMode: "user"
    };

    const webcamRef = React.useRef(null);

    const capture = React.useCallback(
        () => {
            const imageSrc = webcamRef.current.getScreenshot();
            setWebcamEnabled(false);
            const base64 = imageSrc // Place your base64 url here.
            fetch(base64)
                .then(res => res.blob())
                .then(blob => {
                    const formData = new FormData();
                    const file = new File([blob], "selfie.jpeg");
                    formData.append("upload_file", file);
                    props.uploadRawFileSelfie(formData).then((res) => {
                        let fileId = res.data.data.fileId;
                        let filePath = res.data.data.fullS3FilePath
                        console.log(res.data.data.fullS3FilePath)
                        props.saveKycFormData({ prop: 'selfie', value: fileId });
                        props.saveKycFormData({ prop: 'kyc_selfie_path', value: filePath });
                        
                        props.setCheckSelfiImg(false);


                    }).catch((error) => {

                    })
                })
        },
        [webcamRef]
    );

    const onCamera = () => {
        setWebcamEnabled(true)
    }

    const onDeleteDoc = (id) => {
        let data = {
            fileId: id,
            isSelfie: true
        }
        props.removeSelfieDoc(data).then((res) => {
            props.saveKycFormData({ prop: "selfie", value: "" });
            props.saveKycFormData({ prop: 'kyc_selfie_path', value: "" });


        }).catch((error) => {

        })
    }

    return (
        <>
            <h2 className="upload_file__header">{props.label}</h2>
            
            {webcamEnabled ?
                <div className="upload_file">
                    <div className="upload_file__container">
                    {/* <input type="file" required={true}/> */}
                        <Webcam
                            audio={false}
                            height={720}
                            ref={webcamRef}
                            screenshotFormat="image/jpeg"
                            width={1280}
                            videoConstraints={videoConstraints}
                        />
                            <ButtonCustom
                                buttontext="Take photo"
                                className="btn_takePhoto"
                                onClick={() => capture()}
                            />
                      
                    </div>
                </div>
            :
            <div className="upload_file">
                <div className="upload_file__container">
                    <span onClick={() => { onCamera() }} className="upload_file__container">
                        <img src={props.icon} className="upload_doc" />
                        <img src={props.iconLight} className="upload_doc_light" />
                        {props.isDoc == "" && (

                            <h3>Take Selfie</h3>
                        )}
                        {props.isDoc != "" && (
                            <div className="document_upload_successfully">
                                <h3>Document uploaded successfully</h3>
                                <button type="button" className="document_remove" onClick={() => onDeleteDoc(props.isDoc)}>Remove</button>
                            </div>
                        )}
                    </span>
                </div>
            </div>
            }
        </>
    );
}

const mapStateToProps = state => {
    console.log("*****KYC FORM****", state)
    return {
        selfie: state.security.selfie,
        kyc_selfie_path: state.security.kyc_selfie_path
    };
};

const mapDispatchToProps = dispatch => {
    return {
        saveKycFormData: (data) => dispatch(saveKycFormData(data)),
        uploadRawFileSelfie: (data) => dispatch(uploadRawFileSelfie(data)),
        removeKycDoc: (data) => dispatch(removeKycDoc(data)),
        removeSelfieDoc: (data) => dispatch(removeSelfieDoc(data)),



    };
};
export default withRouter(connect(
    mapStateToProps,
    mapDispatchToProps
)(TakeSelfie));
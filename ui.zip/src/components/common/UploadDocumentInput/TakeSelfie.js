import React, { useState } from 'react'
import { Container, Row, Col } from 'react-bootstrap';
import 'react-multi-carousel/lib/styles.css';
// import './KycStyle.scss';
import ButtonCustom from '../../ButtonCustom/ButtonCustom'

import { withRouter } from "react-router";
import {connect } from "react-redux";
// import {removeKycDoc,saveKycFormData} from "../../../redux/actions/SecurityActions"
// import selfieIcon from '../../../assets/images/take_selfie_icon.png'
import Selfie from "../../../theme/images/selfie.svg";
import SelfieLite from "../../../theme/images/selfie_lite.svg";
import Webcam from "react-webcam";
import { saveKycFormData, uploadRawFileSelfie, removeKycDoc, removeSelfieDoc } from "../../../redux/actions/SecurityActions";



const TakeSelfie = props => {
    const [webcamEnabled, setWebcamEnabled] = useState(false)

    const videoConstraints = {
        width: 1280,
        height: 720,
        facingMode: "user"
    };

    const webcamRef = React.useRef(null);

    const capture = React.useCallback(
        () => {
            const imageSrc = webcamRef.current.getScreenshot();
            setWebcamEnabled(false);
            const base64 = imageSrc // Place your base64 url here.
            fetch(base64)
                .then(res => res.blob())
                .then(blob => {
                    const formData = new FormData();
                    const file = new File([blob], "selfie.jpeg");
                    formData.append("upload_file", file);
                    props.uploadRawFileSelfie(formData).then((res) => {
                        let fileId = res.data.data.fileId;
                        let filePath = res.data.data.fullS3FilePath
                        console.log(res.data.data.fullS3FilePath)
                        props.saveKycFormData({ prop: 'selfie', value: fileId });
                        props.saveKycFormData({ prop: 'kyc_selfie_path', value: filePath });




                    }).catch((error) => {

                    })
                })
        },
        [webcamRef]
    );

    const onCamera = () => {
        setWebcamEnabled(true)
    }

    const onDeleteDoc = (id) => {
        let data = {
            fileId: id,
            isSelfie: true
        }
        props.removeSelfieDoc(data).then((res) => {
            props.saveKycFormData({ prop: "selfie", value: "" });
            props.saveKycFormData({ prop: 'kyc_selfie_path', value: "" });


        }).catch((error) => {

        })
    }

    return (

        <>
            <Col className="take_selfi_section">
                <Row className="take_selfi_wrap">
                    <Col className="take_selfi_left">
                        <h2>Take a Selfie of yourself</h2>
                        <Col className="take_selfi_photoBox">

                            {!webcamEnabled && props.kyc_selfie_path !== "" && (
                                <img src={props.kyc_selfie_path} />
                            )}
                            {/* {!webcamEnabled && props.kyc_selfie_path == "" && (
                                <img src={selfieIcon} />
                            )} */}
                            {webcamEnabled && props.kyc_selfie_path == "" && (
                                <Webcam
                                    audio={false}
                                    height={720}
                                    ref={webcamRef}
                                    screenshotFormat="image/jpeg"
                                    width={1280}
                                    videoConstraints={videoConstraints}
                                />
                            )}
                        </Col>
                    </Col>
                    <Col className="take_selfi_right">
                        <p>Make sure that your face is well lit, clearly visible and occupies around half of the selfie </p>
                        {webcamEnabled && (
                            <ButtonCustom
                                buttontext="Take photo"
                                className="btn_takePhoto"
                                onClick={() => capture()}
                            />
                        )}
                        {!webcamEnabled && props.kyc_selfie_path == "" && (
                            <button
                                title="Open Camera"
                                className="btn_camera"
                                onClick={() => onCamera()}
                            >
                                <img src={Selfie} />
                            </button>
                        )}

                        {!webcamEnabled && props.kyc_selfie_path != "" && (

                            <ButtonCustom buttontext="Remove selfie" className="removeSelfie" onClick={() => onDeleteDoc(props.selfie)} />

                        )}

                    </Col>
                </Row>
            </Col>
        </>
    )

}


const mapStateToProps = state => {
    console.log("*****KYC FORM****", state)
    return {
        selfie: state.security.selfie,
        kyc_selfie_path: state.security.kyc_selfie_path
    };
};

const mapDispatchToProps = dispatch => {
    return {
        saveKycFormData: (data) => dispatch(saveKycFormData(data)),
        uploadRawFileSelfie: (data) => dispatch(uploadRawFileSelfie(data)),
        removeKycDoc: (data) => dispatch(removeKycDoc(data)),
        removeSelfieDoc: (data) => dispatch(removeSelfieDoc(data)),



    };
};
export default withRouter(connect(
    mapStateToProps,
    mapDispatchToProps
)(TakeSelfie));
import React from "react";
import "./UploadDocumentInput.scss";
import { withRouter } from "react-router";
import {connect } from "react-redux";
import {removeKycDoc,saveKycFormData} from "../../../redux/actions/SecurityActions"

function UploadDocumentInput(props) {
  const onDeleteDoc = (id)=>{
    let data = {
        fileId:id
    }
    props.removeKycDoc(data).then((res)=>{
     props.saveKycFormData({ prop: props.type, value: "" })

    }).catch((error)=>{
        
    })
 }
  return (
    <>
      <h2 className="upload_file__header">{props.label}</h2>
      <div className="upload_file">
        <div className="upload_file__container">
          <input type="file" onChange={(e)=>props.onChange(e)}  required={true}/>
          <span className="upload_file__container">
            <img src={props.icon} className="upload_doc" />
            <img src={props.iconLight} className="upload_doc_light" />
            {props.isDoc=="" &&(

            <h3>Select File</h3>
            )}
            {props.isDoc!="" &&(
            <div className="document_upload_successfully">
                <h3>Document uploaded successfully</h3>
                <button type="button" className="document_remove" onClick={()=>onDeleteDoc(props.isDoc)}>Remove</button>
            </div>
            )}
          </span>
        </div>
      </div>
    </>
  );
}

const mapStateToProps = state => {
  console.log("*****KYC FORM****", state)
  return {
      doc_type:state.security.doc_type,
      doc_front:state.security.doc_front,
      doc_back:state.security.doc_back,
      national_id:state.security.national_id,
  };
};

const mapDispatchToProps = dispatch => {
  return {
      removeKycDoc:(data)=>dispatch(removeKycDoc(data)),
      saveKycFormData: (data) => dispatch(saveKycFormData(data)),


  };
};
export default withRouter(connect(
  mapStateToProps,
  mapDispatchToProps
)(UploadDocumentInput));


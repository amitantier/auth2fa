import React from "react";
import { Link } from "react-router-dom";
import "./Footer.scss";
function Footer() {
  return (
    <div className="FooterOuter">
      <div className="footerDiv">
        <div className="copyrightDiv">
          <p className="copyrightText">©2021Bitbubble</p>
        </div>
        <div className="linksDiv">
          <Link to="/" className="linksText">
            Privacy Policy
          </Link>
          <span className="spaceLine">-</span>
          <Link to="/" className="linksText">
            Terms & Conditions
          </Link>
          <span className="spaceLine">-</span>
          <Link to="/" className="linksText">
            Faq
          </Link>
          <span className="spaceLine">-</span>
          <Link to="/" className="linksText">
            Contact us
          </Link>
        </div>
      </div>
    </div>
  );
}

export default Footer;

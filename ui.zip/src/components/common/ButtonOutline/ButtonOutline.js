import React from "react";

import "./ButtonOutline.scss";

function ButtonOutline(props) {
  return (
    <button
      disabled={props.disabled}
      type={props.type}
      block
      onClick={props.onClick}
      className={`outlineBtn_style ${props.className}`}
    >
      {props.buttontext}
      {props.icon ? <img src={props.icon} /> : null}
      {props.store ? (
        <p>
          <span className="small_txt">Available on the</span>
          <span className="big_txt">{props.store}</span>
        </p>
      ) : null}
    </button>
  );
}

export default ButtonOutline;

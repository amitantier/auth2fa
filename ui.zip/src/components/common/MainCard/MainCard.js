import React from "react";
import { Card } from "react-bootstrap";
import "./MainCard.scss";

function MainCard(props) {
  return (
    <Card className={`mainCard_style ${props.className}`}>
      <Card.Body className="cardBody_style">
        {props.title ? (
          <Card.Title className={`maintitle ${props.className}`}>
            {props.title}
          </Card.Title>
        ) : null}
        {props.children}
      </Card.Body>
    </Card>
  );
}

export default MainCard;

import React from "react";
import { Form } from "react-bootstrap";
import "../CustomInput/CustomInput.scss";
import "./PhoneInput.scss";
import Select from "react-select";

const PhoneInput = (props) => {
  return (
    <Form.Group className={`customInput ${props.className}`}>
      <Form.Label>{props.label}</Form.Label>
      <div className="comboFieldStyle">
        {/* {console.log('optionsoptions',props.options)} */}
        <Select
        options={props.options}
          name="phone_code"
          classNamePrefix="react-select"
          placeholder={props.defaultValue}
          onChange={(e) => props.handleChange(e, 'mobileCode')}

        />
        <Form.Control
          type="number"
          name="phone"
          min={1}
          value={props.value}
          onChange={(e) => {
            props.handleChange(e, props.name)
            props.checkMobileNo(e)
          }}
          placeholder="Phone Number*"
          className="d-flex align-items-center"
          required={true}
          // onBlur={(e) => {

          //   props.setPhoneNumber(e.target.value)
          //   props.checkMobileNo(e)
          
          // }}
        />
      </div>
      {props.children}
    </Form.Group>
  );
};

export default PhoneInput;

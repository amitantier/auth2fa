import { fetch } from './Fetch';
import { API_HOST } from '../constant';
//var CryptoJS = require("crypto-js");
// let result = CryptoJS.AES.encrypt(JSON.stringify(user), "testnet").toString();
// console.log("userdata",result)
const login = (user) => {
  return fetch('post', `${API_HOST}users/user/login`, user);
};

const verifyUsersEmail = (token) => {
  return fetch('post', `${API_HOST}users/user/verify-email`, token);
};

const verifyUserDevice = (token) => {
  return fetch('post', `${API_HOST}users/user/authneticateDevice`, token);
};

const userRegistrationApi = (token) => {
  return fetch('post', `${API_HOST}users/user/register`, token);
};

const getIp = () => {
  return fetch('get', 'https://jsonip.com');
};

const forgetPassword = (data) => {
  return fetch('post', `${API_HOST}users/user/forgotPassword`, data);
};

const resetPassword = (data) => {
  return fetch('post', `${API_HOST}users/user/forgotPasswordReset`, data);
};

const checkEmailExist = (data) => {
  return fetch('post', `${API_HOST}users/user/check_email_exist`, data);
};
const checkMobileExist = (data) => {
  return fetch('post', `${API_HOST}users/user/check_mobileNumber_exist`, data);
};
const resendVerificationMail = (data) => {
  return fetch('post', `${API_HOST}users/user/resend_verification_email`, data);
};

export const UserService = {
  login,
  getIp,
  forgetPassword,
  verifyUsersEmail,
  userRegistrationApi,
  resetPassword,
  checkEmailExist,
  checkMobileExist,
  verifyUserDevice,
  resendVerificationMail,
};

import { UserService } from "../../services/UserService";
import { actionTypes } from "../actions/RegisterActions";

const initialState = {
  email:"",
  captcha:""
};

const register = (state = initialState, action) => {
console.log("********",action)
  switch (action.type) {
    case actionTypes.REGISTER_FORM_UPDATE:
      return {
       
        ...state,[action.payload.prop]: action.payload.value
        
      };
 

    
    default:
      return state;
  }
}
export default register;

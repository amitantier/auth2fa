import { actionTypes } from "../actions/SecurityActions";

const initialState = {
    secret: "",
    qrImgUrl:"",
    //kyc form step1
    doc_type:"",
    doc_front:"",
    doc_back:"",
    national_id:"",
    //kyc form step2
    selfie:"",
    //kyc form step3
    firstName:"",
    middleName:"",
    lastName:"",
    panNo:"",
    country:"",
    zip:"",
    city:"",
    kyc_selfie_path:"",
    kyc_doc_path_front:"",
    kyc_doc_path_back:"",
    kyc_national_doc_path:"",
    //user-info
    user_info_status:{},
    userProfile:{}

};

const security = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.KYC_FORM_UPDATE:
      return {
       
        ...state,[action.payload.prop]: action.payload.value
        
      };
      
    
    case actionTypes.SAVE_GOOGLE_AUTH_DETAIL:
      return {
        ...state,
        secret: action.payload.secret,
        qrImgUrl: action.payload.qrImgUrl,

        
      };
      case actionTypes.SAVE_USER_INFO:
        return {
          ...state,
          user_info_status: action.payload,
  
          
        };
      
      case actionTypes.SAVE_USER_PROFILE:
      return {
        ...state,
        userProfile: action.payload,

        
      };
      case actionTypes.KYC_FORM_CLEAR:
        return {
          ...state,
          doc_type:"",
          doc_front:"",
          doc_back:"",
          national_id:"",
          selfie:"",

          firstName:"",
          middleName:"",
          lastName:"",
          panNo:"",
          country:"",
          zip:"",
          city:"",
          kyc_selfie_path:"",
          kyc_doc_path_back:"",
          kyc_doc_path_front:""
  
          
        };
      
   

    default:
      return state;
  }
};

export default security;

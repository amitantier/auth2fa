import { SecurityService } from "../../services/SecurityService";
import { startLoading, stopLoading } from "./LoadingActions";
import { toast } from "../../components/Toast/Toast";
import { AUTH_TOKEN_KEY } from "../../constant";
import { getToken } from "../../Helpers/storageHelper"



/** seting action types */
export const actionTypes = {
  SAVE_GOOGLE_AUTH_DETAIL: "SAVE_GOOGLE_AUTH_DETAIL",
  KYC_FORM_UPDATE: "KYC_FORM_UPDATE",
  KYC_FORM_CLEAR: "KYC_FORM_CLEAR",
  SAVE_USER_INFO: "SAVE_USER_INFO",

  SAVE_USER_PROFILE: "SAVE_USER_PROFILE"

};
export function saveUserInfo(data) {

  return {
    type: actionTypes.SAVE_USER_INFO,
    payload: data
  };
}


export function saveKycFormData(data) {

  return {
    type: actionTypes.KYC_FORM_UPDATE,
    payload: data
  };
}

export function clearKycFormData() {

  return {
    type: actionTypes.KYC_FORM_CLEAR,
  };
}
export function saveUserProfile(data) {

  return {
    type: actionTypes.SAVE_USER_PROFILE,
    payload: data
  };
}


export function saveGoogleAuthDetails(data) {
  return {
    type: actionTypes.SAVE_GOOGLE_AUTH_DETAIL,
    payload: data
  };
}


export function get2FaImage(data) {
  return (dispatch, getState) => new Promise((resolve, reject) => {
    dispatch(startLoading())
    SecurityService.get2FaImage(data, {
      jwt: getToken(AUTH_TOKEN_KEY)
    })
      .then((res) => {
        console.log("res.data", res.data.data)
        dispatch(saveGoogleAuthDetails(res.data.data))
        dispatch(stopLoading());
        resolve(res);
      })
      .catch((ex) => {
        toast.error(ex.data.message)
        dispatch(stopLoading());

        reject(ex);
      });

  });
}


export function google2faValidate(data) {
  return (dispatch, getState) => new Promise((resolve, reject) => {
    dispatch(startLoading())
    SecurityService.google2faValidate(data, {
      jwt: getToken(AUTH_TOKEN_KEY)
    })
      .then((res) => {
        console.log("res.data", res)
        toast.success(res.data.message);

        dispatch(stopLoading());
        resolve(res);
      })
      .catch((ex) => {
        toast.error(ex.data.message)
        dispatch(stopLoading());
        reject(ex);
      });

  });
}


export function google2faDisable(data) {
  return (dispatch, getState) => new Promise((resolve, reject) => {
    dispatch(startLoading())
    SecurityService.google2faDisable(data, {

      jwt: getToken(AUTH_TOKEN_KEY)
    })
      .then((res) => {
        console.log("res.data", res)
        toast.success(res.data.message);

        dispatch(stopLoading());
        resolve(res);
      })
      .catch((ex) => {
        toast.error(ex.data.message)
        dispatch(stopLoading());
        reject(ex);
      });

  });
}



export const uploadRawFile = file => {
  return (dispatch, getState) => {
    let state = getState();

    // dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.uploadRawFile(file, {
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
          dispatch(stopLoading());
          console.log("HEY RES", res);
          toast.success(res.data.message);
          resolve(res);
        })
        .catch((ex) => {
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};
export const uploadRawFileSelfie = file => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.uploadRawFile(file, {
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
          dispatch(stopLoading());
          console.log("HEY RES", res);
          toast.success(res.data.message);
          resolve(res);
        })
        .catch((ex) => {
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};


export const removeKycDoc = file => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.removeKycDoc(file, {
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
          dispatch(stopLoading());
          console.log("HEY RES", res);
          toast.success(res.data.message);
          resolve(res);
        })
        .catch((ex) => {
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};

export const removeSelfieDoc = file => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.removeSelfieDoc(file, {
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
          dispatch(stopLoading());
          console.log("HEY RES", res);
          toast.success(res.data.message);
          resolve(res);
        })
        .catch((ex) => {
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};



export const getUserKycDetails = data => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.getUserKycDetails({
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};




export const getFileById = data => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.getFileById(data, {
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};

//PROFILE
export const getUserProfile = () => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.getUserProfile({
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
          console.log("PPPPP", res.data.data[0])
          if(res.data.data.length) {
          dispatch(saveUserProfile(res.data.data[0]))
          }
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};


export const updateUserProfile = data => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.updateUserProfile(data, {
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
          toast.success(res.data.message);
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          toast.error(ex.data.message)
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};


export const getUserInfo = () => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.getUserInfo({
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
          dispatch(saveUserInfo(res.data.data))
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};
export const getUserTrustedDevice = () => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.getUserTrustedDevice({
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};





export const resetUserPassword = data => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.resetUserPassword(data, {
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
          toast.success(res.data.message);
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          toast.error(ex.data.message)
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};



export const updateUserKyc = data => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.updateUserKyc(data, {
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
          toast.success(res.data.message);
          setTimeout(() => {
            dispatch(stopLoading());
            resolve(res);
          }, 1000);

        })
        .catch((ex) => {
          toast.error(ex.data.message)
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};


export const addUserBank = data => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.addUserBank(data, {
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
          toast.success(res.data.message);
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          toast.error(ex.data.message)
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};


export const updateUserBank = (data, id) => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.updateUserBank(data, id, {
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
          toast.success(res.data.message);
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          toast.error(ex.data.message)
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};



export const getUserBank = () => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.getUserBank({
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          toast.error(ex.data.message)
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};



export const send2faEmailVerification = () => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.send2faEmailVerification({
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
          toast.success(res.data.message);
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          toast.error(ex.data.message)
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};




export const token_verification = (data) => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.token_verification(data, {
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
          toast.success(res.data.message);
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          toast.error(ex.data.message)
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};


export const token_verification_google = (data) => {
  return (dispatch, getState) => {
    let state = getState();

    dispatch(startLoading());
    return new Promise((resolve, reject) => {
      SecurityService.token_verification_google(data, {
        jwt: getToken(AUTH_TOKEN_KEY)
      })
        .then((res) => {
          toast.success(res.data.message);
          dispatch(stopLoading());
          resolve(res);
        })
        .catch((ex) => {
          toast.error(ex.data.message)
          dispatch(stopLoading());
          reject(ex);
        });
    });
  };
};


export function check_ip_token(data) {
  return (dispatch, getState) => new Promise((resolve, reject) => {
    dispatch(startLoading())
    SecurityService.check_ip_token(data, {
      jwt: getToken(AUTH_TOKEN_KEY)
    })
      .then((res) => {
        console.log("res.data", res.data.data)
        dispatch(saveGoogleAuthDetails(res.data.data))
        dispatch(stopLoading());
        resolve(res);
      })
      .catch((ex) => {
        toast.error(ex.data.message)
        dispatch(stopLoading());

        reject(ex);
      });

  });
}

import { justPairSwap } from "../../Helpers/Normailize";

/** seting action types */
export const actionTypes = {
  UPDATE_FIRST_TIME_LOGIN_STATE: "UPDATE_FIRST_TIME_LOGIN_STATE",
  SAVE_PAIR: "SAVE_PAIR",
};

/*
 * Action creators
 */

export function updateFirstTimeLoginState(data) {
  console.log('updateFirstTimeLoginState',data)
  return {
    type: actionTypes.UPDATE_FIRST_TIME_LOGIN_STATE,
    payload: data,
  };
}

export function savePairPersist(data) {
  return {
    type: actionTypes.SAVE_PAIR,
    payload: justPairSwap(data),
  };
}
